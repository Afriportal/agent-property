<?php $this->load->view('app/includes/head'); ?>
<!-- Stylesheet -->
<link href="<?= base_url('assets/app/css/fine-uploader-gallery.min.css'); ?>" rel="stylesheet">
</head>
<body>
    <div id="wrapper">
       <nav class="navbar navbar-default navbar-static-top m-b-0">
            <?php $this->load->view('app/includes/nav'); ?>
        </nav>
        <!-- End Top Navigation -->
        <!-- Left navbar-header -->
        <div class="navbar-default sidebar" role="navigation">
            <?php $this->load->view('app/includes/sidebar'); ?>
        </div>

        <div id="page-wrapper">
            <div class="container-fluid">
                <div class="row bg-title">
                    <div class="col-lg-3 col-md-4 col-sm-4 col-xs-12">
                        <h4 class="page-title">Post a new property</h4>
                    </div>
                    <div class="col-lg-9 col-sm-8 col-md-8 col-xs-12">
                        <ol class="breadcrumb">
                             <li><span class="label label-danger">Unverified</span><span class="label label-success hidden">Verified</span></li>
                             
                            <li class="active">You are signed in as a <a href="#"><span class="label label-success">Agent</span></a> </li>
                        </ol>
                    </div>
                    <!-- /.col-lg-12 -->
                </div>
                 <!-- .row -->
                <div class="row">
                    <div class="col-md-12">
                        <h3 class="box-title">Basic Information</h3>
                        <div class="white-box">
                            <?php $this->load->view('app/includes/msg_view'); ?>
                            
                            <?= form_open_multipart('create/process', 'class="pro-add-form"'); ?>
                                <div class="form-group">
                                    <label for="pname">Property Name</label>
                                    <input type="text" class="form-control" name="title" placeholder="Enter Property Title" required value="<?php if(isset($_POST['title'])) set_value('title'); ?>"> 
                                </div>
                                <div class="form-group">
                                    <label class="m-b-10">Purpose of Property Listing</label>
                                    <br>
                                    <div class="radio radio-info radio-inline">
                                        <input type="radio" name="property_type" value="for rent" checked="">
                                        <label for="radio1">For Rent </label>
                                    </div>
                                    <div class="radio radio-info radio-inline">
                                        <input type="radio" name="property_type" value="for sale">
                                        <label for="radio2"> For Sale </label>
                                    </div>
                                    <div class="radio radio-info radio-inline">
                                        <input type="radio" name="property_type" value="for lease">
                                        <label for="radio2"> For Lease </label>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="pname">Price of Property</label>
                                    <input type="text" class="form-control" name="price" placeholder="Enter the digit only"> 
                                </div>
                                <div class="form-group">
                                    <div class="row">
                                        <div class="col-sm-3">
                                            <label >Type of property *</label>
                                            <select class="selectpicker" required name="type_of_property" data-style="form-control" >
                                                <option value="">--Select an option--</option>
                                                <?php $types = explode(',', lang('type_of_property')); 
                                                    foreach( $types as $type ):
                                                ?>
                                                <option value="<?= trim($type); ?>"><?= ucwords(trim($type)); ?></option>
                                                <?php endforeach; ?>
                                            </select>
                                        </div>
                                        <div class="col-sm-3">
                                            <label >Payment Schedule</label>
                                            <select class="selectpicker" name="payment_schedule" data-style="form-control" >
                                                <option value="">--Select an option--</option>
                                                <?php $types = explode(',', lang('payment_schedule')); 
                                                    foreach( $types as $type ):
                                                ?>
                                                <option value="<?= trim($type); ?>"><?= ucwords(trim($type)); ?></option>
                                                <?php endforeach; ?>
                                            </select>
                                        </div>
                                        <div class="col-sm-3">
                                            <label >No. of Bedrooms</label>
                                            <select class="selectpicker" name="no_of_bedrooms" data-style="form-control" >
                                                <option value="">--Select an option</option>
                                                <?php $types = explode(',', lang('numbers')); 
                                                    foreach( $types as $type ):
                                                ?>
                                                <option value="<?= trim($type); ?>"><?= trim($type); ?></option>
                                                <?php endforeach; ?>
                                            </select>
                                        </div>
                                        <div class="col-sm-3">
                                            <label >No. of Bathrooms</label>
                                            <select class="selectpicker" name="no_of_bathrooms" data-style="form-control" >
                                                <option value="">--Select an option--</option>
                                                <?php $types = explode(',', lang('numbers')); 
                                                    foreach( $types as $type ):
                                                ?>
                                                <option value="<?= trim($type); ?>"><?= trim($type); ?></option>
                                                <?php endforeach; ?>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <br>
                                <!--section 2 -->
                            <h3 class="box-title">Property Information</h3>
                            <div class="white-box">
                                <div class="form-group">
                                    <label for="pdesc">Property Description</label>
                                    <textarea class="form-control" rows="5" name="property_description" value="<?php if(isset($_POST['property_description']))set_value('property_description'); ?>" placeholder="Detailed information about your property"></textarea>
                                </div>
                                
                                <div class="form-group">
                                    <div class="row">
                                        <div class="col-sm-4">
                                            <label>Age of the Building (optional)</label>
                                            <select class="selectpicker" name="building_age" data-style="form-control">
                                                <option value="">--Select an option--</option>
                                                <?php $types = explode(',', lang('numbers')); 
                                                    foreach( $types as $type ):
                                                ?>
                                                <option value="<?= trim($type); ?>"><?= trim($type); ?></option>
                                                <?php endforeach; ?>
                                            </select>
                                        </div>
                                        <div class="col-sm-4">
                                            <label>Number of toilets (optional)</label>
                                            <select class="selectpicker" name="no_of_toilets" data-style="form-control">
                                                <option value="">--Select an option--</option>
                                                <?php $types = explode(',', lang('numbers')); 
                                                    foreach( $types as $type ):
                                                ?>
                                                <option value="<?= trim($type); ?>"><?= trim($type); ?></option>
                                                <?php endforeach; ?>
                                            </select> 
                                        </div>
                                        <div class="col-sm-4">
                                            <label>Storey Building? (optional)</label>
                                            <select class="selectpicker" name="no_of_storey" data-style="form-control">
                                                <option value="">--Select an option--</option>
                                                <?php $types = explode(',', lang('numbers')); 
                                                    foreach( $types as $type ):
                                                ?>
                                                <option value="<?= trim($type); ?>"><?= trim($type); ?></option>
                                                <?php endforeach; ?>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label>Optional Property Features</label>
                                    <div class="row">
                                        <?php $features = explode(',', lang('property_features')); foreach( $features as $feature  ) : ?>
                                            <div class="col-md-3">
                                                <div class="checkbox checkbox-info checkbox-circle">
                                                    <input type="checkbox" name="property_features[]" value="<?= ucwords(trim($feature)); ?>">
                                                    <label for="<?= ucwords(trim($feature)); ?>"><?= ucwords(trim($feature)); ?></label>
                                                </div>
                                            </div>
                                        <?php endforeach; ?>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <div class="row">
                                        <div class="col-sm-3">
                                            <label >Property floor type</label>
                                            <select class="selectpicker" name="floor_type" data-style="form-control" >
                                                <option value="">--Floor Type --</option>
                                                <?php $types = explode(',', lang('floor_type')); 
                                                    foreach( $types as $type ):
                                                ?>
                                                <option value="<?= trim($type); ?>"><?= ucwords(trim($type)); ?></option>
                                                <?php endforeach; ?>
                                            </select>
                                        </div>
                                        <div class="col-sm-3">
                                            <label>Minimum Payment Period</label>
                                            <select class="selectpicker" name="payment_period" data-style="form-control" >
                                                <option value="">-- Minimum Payment Period --</option>
                                                <?php $types = explode(',', lang('payment_period')); 
                                                    foreach( $types as $type ):
                                                ?>
                                                <option value="<?= trim($type); ?>"><?= ucwords(trim($type)); ?></option>
                                                <?php endforeach; ?>
                                            </select>
                                        </div>
                                        <div class="col-sm-3">
                                            <label>Landlord Living in Premises</label>
                                            <select class="selectpicker" name="landlord" data-style="form-control" >
                                                <option value="">-- Landlord Living in Premises --</option>
                                                <?php $types = explode(',', lang('landlord')); 
                                                    foreach( $types as $type ):
                                                ?>
                                                <option value="<?= ucwords(trim($type)); ?>"><?= ucwords(trim($type)); ?></option>
                                                <?php endforeach; ?>
                                            </select>
                                        </div>
                                        <div class="col-sm-3">
                                            <label >State of Building</label>
                                            <select class="selectpicker" name="state_of_building" data-style="form-control" >
                                                <option value="">-- State of Building --</option>
                                                <?php $types = explode(',', lang('state_of_building')); 
                                                    foreach( $types as $type ):
                                                ?>
                                                <option value="<?= ucwords(trim($type)); ?>"><?= ucwords(trim($type)); ?></option>
                                                <?php endforeach; ?>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <br>
                               <!-- section 3 -->
                            <h3 class="box-title">Final Details/Image Upload</h3>
                            <div class="white-box">
                                <div class="form-group">
                                    <div class="row">
                                        <div class="col-sm-6">
                                            <label >Address</label>
                                            <input type="text" class="form-control" placeholder="Address of the property" name="address" value="<?php if(isset($_POST['address'])) set_value('address'); ?>"> 
                                        </div>
                                        <div class="col-sm-6">
                                            <label for="landmark">Landmark</label>
                                            <input type="text" class="form-control" placeholder="Where is the building close to?" value="<?php if(isset($_POST['landmark'])) set_value('landmark'); ?>" name="landmark"> 
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <div class="row">
                                        <div class="col-sm-6">
                                            <label >State where property is located</label>
                                            <select class="form-control" name="state">
                                                <option value="">--Select State--</option>
                                                <?php $types = explode(',', lang('states')); 
                                                        foreach( $types as $type ):
                                                    ?>
                                                    <option value="<?= trim($type); ?>"><?= ucwords(trim($type)); ?></option>
                                                <?php endforeach; ?>
                                            </select>
                                        </div>
                                        <div class="col-sm-6">
                                            <div class="form-group">
                                                <label>L.G.A.</label>
                                                <select class="form-control" name="lga" >
                                                    <option value="">--Choose L.G.A--</option>
                                                    <?php $types = explode(',', lang('lga')); 
                                                        foreach( $types as $type ):
                                                    ?>
                                                    <option value="<?= trim($type); ?>"><?= ucwords(trim($type)); ?></option>
                                                    <?php endforeach; ?>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-md-12">
                                        <div id="uploader"></div>
                                    </div>
                                </div> 
                                <br>
                                <!-- <div class="fallback">
                                    <input name="file" type="file" multiple />
                                </div> -->
                                <button type="submit" class="btn btn-success waves-effect waves-light m-r-10">Submit Property</button>
                            </div>
                            <?= form_close(); ?>
                        </div>
                    </div>
                </div>
                <!-- .row -->
                    </div>
            <!-- /.container-fluid -->
            <footer class="footer text-center"><?= lang('footer_text'); ?></footer>
        </div>
        <!-- /#page-wrapper -->
    </div>
    <!-- /#wrapper -->
    <!-- jQuery -->
    
    <script src="<?= base_url('assets/app/plugins/bower_components/jquery/dist/jquery.min.js'); ?>"></script>
    <!-- Bootstrap Core JavaScript -->
    <script src="<?= base_url('assets/app/bootstrap/dist/js/tether.min.js'); ?>"></script>
    <script src="<?= base_url('assets/app/bootstrap/dist/js/bootstrap.min.js'); ?>"></script>
    <script src="<?= base_url('assets/app/plugins/bower_components/bootstrap-extension/js/bootstrap-extension.min.js'); ?>"></script>
    <!-- Sidebar menu plugin JavaScript -->
    <script src="<?= base_url('assets/app/plugins/bower_components/sidebar-nav/dist/sidebar-nav.min.js'); ?>"></script>
    <!--Slimscroll JavaScript For custom scroll-->
    <script src="<?= base_url('assets/app/js/jquery.slimscroll.js'); ?>"></script>
    <!--Wave Effects -->
    <script src="<?= base_url('assets/app/js/waves.js'); ?>"></script>
    <!-- Custom Theme JavaScript -->
    <script src="<?= base_url('assets/app/js/custom.min.js'); ?>"></script>
    <script src="<?= base_url('assets/app/plugins/bower_components/bootstrap-select/bootstrap-select.min.js');?>" type="text/javascript"></script>
    <!-- Upload JS --> 

    <script type="text/javascript" src="<?= base_url(); ?>assets/app/js/fine-uploader.core.min.js"></script>
    <script type="text/javascript" src="<?= base_url(); ?>assets/app/js/fine-uploader.min.js"></script>

    <script type="text/javascript" src="<?= base_url(); ?>assets/app/js/fileinput/plugins/purify.min.js"></script>
    <script type="text/javascript" src="<?= base_url(); ?>assets/app/js/fileinput/plugins/sortable.min.js"></script>
    <script type="text/javascript" src="<?= base_url(); ?>assets/app/js/fileinput/fileinput.min.js"></script>
    <!-- /Upload JS -->

    <script type="text/javascript" src="<?= base_url(); ?>assets/app/js/uploader_bootstrap.js"></script>



   <!--file uploader template-->                                  
        <script type="text/template" id="qq-template">
        <div class="qq-uploader-selector qq-uploader qq-gallery" qq-drop-area-text="Drop files here">
            <div class="qq-total-progress-bar-container-selector qq-total-progress-bar-container">
                <div role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100" class="qq-total-progress-bar-selector qq-progress-bar qq-total-progress-bar"></div>
            </div>
            <div class="qq-upload-drop-area-selector qq-upload-drop-area" qq-hide-dropzone>
                <span class="qq-upload-drop-area-text-selector"></span>
            </div>
            <div class="qq-upload-button-selector qq-upload-button">
                <div>Add Property images</div>
            </div>
            <span class="qq-drop-processing-selector qq-drop-processing">
                <span>Processing dropped files...</span>
                <span class="qq-drop-processing-spinner-selector qq-drop-processing-spinner"></span>
            </span>
            <ul class="qq-upload-list-selector qq-upload-list" role="region" aria-live="polite" aria-relevant="additions removals">
                <li>
                    <span role="status" class="qq-upload-status-text-selector qq-upload-status-text"></span>
                    <div class="qq-progress-bar-container-selector qq-progress-bar-container">
                        <div role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100" class="qq-progress-bar-selector qq-progress-bar"></div>
                    </div>
                    <span class="qq-upload-spinner-selector qq-upload-spinner"></span>
                    <div class="qq-thumbnail-wrapper">
                        <img class="qq-thumbnail-selector" qq-max-size="120" qq-server-scale>
                    </div>
                    <button type="button" class="qq-upload-cancel-selector qq-upload-cancel">X</button>
                    <button type="button" class="qq-upload-retry-selector qq-upload-retry">
                        <span class="qq-btn qq-retry-icon" aria-label="Retry"></span>
                        Retry
                    </button>

                    <div class="qq-file-info">
                        <div class="qq-file-name">
                            <span class="qq-upload-file-selector qq-upload-file"></span>
                            <span class="qq-edit-filename-icon-selector qq-btn qq-edit-filename-icon" aria-label="Edit filename"></span>
                        </div>
                        <input class="qq-edit-filename-selector qq-edit-filename" tabindex="0" type="text">
                        <span class="qq-upload-size-selector qq-upload-size"></span>
                        <button type="button" class="qq-btn qq-upload-delete-selector qq-upload-delete">
                            <span class="qq-btn qq-delete-icon" aria-label="Delete"></span>
                        </button>
                        <button type="button" class="qq-btn qq-upload-pause-selector qq-upload-pause">
                            <span class="qq-btn qq-pause-icon" aria-label="Pause"></span>
                        </button>
                        <button type="button" class="qq-btn qq-upload-continue-selector qq-upload-continue">
                            <span class="qq-btn qq-continue-icon" aria-label="Continue"></span>
                        </button>
                    </div>
                </li>
            </ul>

            <dialog class="qq-alert-dialog-selector">
                <div class="qq-dialog-message-selector"></div>
                <div class="qq-dialog-buttons">
                    <button type="button" class="qq-cancel-button-selector">Close</button>
                </div>
            </dialog>

            <dialog class="qq-confirm-dialog-selector">
                <div class="qq-dialog-message-selector"></div>
                <div class="qq-dialog-buttons">
                    <button type="button" class="qq-cancel-button-selector">No</button>
                    <button type="button" class="qq-ok-button-selector">Yes</button>
                </div>
            </dialog>

            <dialog class="qq-prompt-dialog-selector">
                <div class="qq-dialog-message-selector"></div>
                <input type="text">
                <div class="qq-dialog-buttons">
                    <button type="button" class="qq-cancel-button-selector">Cancel</button>
                    <button type="button" class="qq-ok-button-selector">Ok</button>
                </div>
            </dialog>
        </div>
    </script>
    
       <script>
        var uploader = new qq.FineUploader({
            element: document.getElementById("uploader"),
            request: {
                endpoint: '/uploads'
            },
            deleteFile: {
                enabled: true,
                endpoint: '/uploads'
            },
            retry: {
               enableAuto: true
            }
        });
    </script> 
    <!-- <script>
    $("input[name='tch1']").TouchSpin();
    $("input[name='tch2']").TouchSpin();
    $("input[name='tch3']").TouchSpin();
    $("input[name='tch4']").TouchSpin();
    $("input[name='tch5']").TouchSpin();
    $('.dropify').dropify();
    </script> -->
</body>
</html>