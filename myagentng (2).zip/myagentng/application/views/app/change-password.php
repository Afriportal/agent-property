<?php $this->load->view('app/includes/head'); ?>
<!-- Stylesheet -->
</head>

<body>
    <div id="wrapper">
       <!-- Top Navigation -->
        <nav class="navbar navbar-default navbar-static-top m-b-0">
            <?php $this->load->view('app/includes/nav'); ?>
        </nav>
        <!-- End Top Navigation -->
        <!-- Left navbar-header -->
        <div class="navbar-default sidebar" role="navigation">
            <?php $this->load->view('app/includes/sidebar'); ?>
        </div>
        <!-- Left navbar-header end -->
        <div id="page-wrapper">
            <div class="container-fluid">
                <div class="row bg-title">
                    <div class="col-lg-3 col-md-4 col-sm-4 col-xs-12">
                        <h4 class="page-title">Change your password</h4>
                    </div>
                    <div class="col-lg-9 col-sm-8 col-md-8 col-xs-12">
                        <ol class="breadcrumb">
                           <li><span class="label label-danger">Unverified</span><span class="label label-success hidden">Verified</span></li>
                             <li class="active">You are signed in as an <a href="#"><span class="label label-success">Agent</span></a> </li>
                        </ol>
                    </div>
                    <!-- /.col-lg-12 -->
                </div>
                <div class="row">
                    <div class="col-md-6 col-md-offset-3">
                        <div class="white-box">
                            <div class="row">
                                <div class="col-sm-12 col-xs-12">
                                    <?php $this->load->view('app/includes/msg_view'); ?>
                                    <?= form_open($profile->user_type.'/change_password'); ?>
                                        <div class="form-group">
                                            <label for="current_password">Current Password</label>
                                            <input type="password" class="form-control" id="current_password" name="current_password" placeholder="Old Password">
                                        </div>
                                        <div class="form-group">
                                            <label for="new_password">New Password</label>
                                            <input type="password" class="form-control" id="new_password" name="new_password" placeholder="New Password">
                                        </div>
                                        <div class="form-group">
                                            <label for="password_confirm">Confirm New Password</label>
                                            <input type="password" class="form-control" id="password_confirm" name="password_confirm" placeholder="Confirm Password">
                                        </div>
                                        <button type="submit" class="btn btn-success waves-effect waves-light m-r-10">Change</button>
                                    <?= form_close(); ?>
                                </div>
                            </div>
                        </div>
                    </div>
                <!-- /.row -->
                    </div>
            </div>
            <!-- /.container-fluid -->
            <footer class="footer text-center"><?= lang('footer_text'); ?></footer>
        </div>
        <!-- /#page-wrapper -->
    </div>
    <!-- /#wrapper -->
    <!-- jQuery -->
    <script src="<?= base_url('assets/app/plugins/bower_components/jquery/dist/jquery.min.js'); ?>"></script>
    <!-- Bootstrap Core JavaScript -->
    <script src="<?= base_url('assets/app/bootstrap/dist/js/tether.min.js'); ?>"></script>
    <script src="<?= base_url('assets/app/bootstrap/dist/js/bootstrap.min.js'); ?>"></script>
    <script src="<?= base_url('assets/app/plugins/bower_components/bootstrap-extension/js/bootstrap-extension.min.js') ; ?>"></script>
    <!-- Menu Plugin JavaScript -->
    <script src="<?= base_url('assets/app/plugins/bower_components/sidebar-nav/dist/sidebar-nav.min.js'); ?>"></script>
    <!--slimscroll JavaScript -->
    <script src="<?= base_url('assets/app/js/jquery.slimscroll.js'); ?>"></script>
    <script src="<?= base_url('assets/app/plugins/bower_components/dropzone-master/dist/dropzone.js'); ?>"></script>
   
    <!-- Custom Theme JavaScript -->
    <script src="<?= base_url('assets/app/js/custom.min.js'); ?>"></script>
    <!--Style Switcher -->
    <script src="<?= base_url('assets/app/plugins/bower_components/styleswitcher/jQuery.style.switcher.js'); ?>"></script>
</body>
</html>