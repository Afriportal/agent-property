<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" type="image/png" sizes="16x16" href="../plugins/images/favicon.png">
    <title>Dashboard | Myagent.ng</title>
    <!-- Bootstrap Core CSS -->
    <link href="<?= base_url('assets/app/bootstrap/dist/css/bootstrap.min.css'); ?>" rel="stylesheet">
    <link href="<?= base_url('assets/app/plugins/bower_components/bootstrap-extension/css/bootstrap-extension.css'); ?>" rel="stylesheet">
    <!-- <link href="<?= base_url(); ?>assets/app/js/dump/core.css" rel="stylesheet" type="text/css"> -->
    <link href="<?= base_url(); ?>assets/app/js/dump/components1.css" rel="stylesheet" type="text/css">
    <!-- Menu CSS -->
    <link href="<?= base_url('assets/app/plugins/bower_components/sidebar-nav/dist/sidebar-nav.min.css'); ?>" rel="stylesheet">
    <link href="<?= base_url('assets/app/plugins/bower_components/toast-master/css/jquery.toast.css'); ?>" rel="stylesheet">
    <!-- animation CSS -->
    <link href="<?= base_url('assets/app/css/animate.css'); ?>" rel="stylesheet">
    <!-- Custom CSS -->
    <link href="<?= base_url('assets/app/css/style.css'); ?>" rel="stylesheet">
    <!-- color CSS -->
    <link href="<?= base_url('assets/app/css/colors/gray-dark.css'); ?>" id="theme" rel="stylesheet">

    <link href="<?= base_url('assets/app/plugins/bower_components/bootstrap-select/bootstrap-select.min.css'); ?>" rel="stylesheet" />


<link href="<?= base_url(); ?>assets/app/css/icons/icomoon/styles.css" rel="stylesheet" type="text/css">
    <link href="<?= base_url(); ?>assets/app/css/icons/fontawesome/styles.min.css" rel="stylesheet" type="text/css">
<!--<link href="assets/css/colors.css" rel="stylesheet" type="text/css"> -->
<!-- /global stylesheets -->

<!-- Core JS files -->
</head>
<body>
    <div id="wrapper">
       <?php
        if($this->session->userdata('user_type') == 'admin' ) :
           $this->load->view('app/includes/admin_sidebar');
        else :
       ?>
        <nav class="navbar navbar-default navbar-static-top m-b-0">
            <?php $this->load->view('app/includes/nav'); ?>
        </nav>
        <!-- End Top Navigation -->
        <!-- Left navbar-header -->
        <div class="navbar-default sidebar" role="navigation">
            <?php $this->load->view('app/includes/sidebar'); ?>
        </div>
        <?php endif; ?>

        <div id="page-wrapper">
            <div class="container-fluid">
                <div class="row bg-title">
                    <div class="col-lg-3 col-md-4 col-sm-4 col-xs-12">
                        <h4 class="page-title">Post a new property</h4>
                    </div>
                    <div class="col-lg-9 col-sm-8 col-md-8 col-xs-12">
                        <ol class="breadcrumb">
                             <li><span class="label label-danger">Unverified</span><span class="label label-success hidden">Verified</span></li>
                             
                            <li class="active">You are signed in as a <a href="#"><span class="label label-success">Agent</span></a> </li>
                        </ol>
                    </div>
                    <!-- /.col-lg-12 -->
                </div>
                 <!-- .row -->
                <div class="row">
                    <div class="col-md-12">
                        <?php $this->load->view('app/includes/msg_view'); ?>
                        <h3 class="box-title">Basic Information</h3>
                        <?= form_open_multipart(); ?>
                            <div class="white-box">                            
                                <div class="form-group">
                                    <label for="pname">Property Name</label>
                                    <input type="text" class="form-control" name="title" placeholder="Enter Property Title" required value="<?php if(isset($_POST['title'])) set_value('title'); ?>"> 
                                </div>
                                <div class="form-group">
                                    <label class="m-b-10">Purpose of Property Listing</label>
                                    <br>
                                    <div class="radio radio-info radio-inline">
                                        <input type="radio" name="property_type" value="for rent" checked="">
                                        <label for="radio1">For Rent </label>
                                    </div>
                                    <div class="radio radio-info radio-inline">
                                        <input type="radio" name="property_type" value="for sale">
                                        <label for="radio2"> For Sale </label>
                                    </div>
                                    <div class="radio radio-info radio-inline">
                                        <input type="radio" name="property_type" value="for lease">
                                        <label for="radio2"> For Lease </label>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="pname">Price of Property</label>
                                    <input type="text" class="form-control" name="price" placeholder="Enter the digit only"> 
                                </div>                                
                                <div class="row">
                                    <div class="col-sm-3">
                                        <div class="form-group">
                                            <label >Type of property *</label>
                                            <select class="selectpicker" required name="type_of_property" data-style="form-control" >
                                                <option value="">--Select an option--</option>
                                                <?php $types = explode(',', lang('type_of_property')); 
                                                    foreach( $types as $type ):
                                                ?>
                                                <option value="<?= trim($type); ?>"><?= ucwords(trim($type)); ?></option>
                                                <?php endforeach; ?>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-sm-3">
                                        <div class="form-group">
                                            <label >Payment Schedule</label>
                                            <select class="selectpicker" name="payment_schedule" data-style="form-control" >
                                                <option value="">--Select an option--</option>
                                                <?php $types = explode(',', lang('payment_schedule')); 
                                                    foreach( $types as $type ):
                                                ?>
                                                <option value="<?= trim($type); ?>"><?= ucwords(trim($type)); ?></option>
                                                <?php endforeach; ?>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-sm-3">
                                        <div class="form-group">
                                            <label >No. of Bedrooms</label>
                                            <select class="selectpicker" name="no_of_bedrooms" data-style="form-control" >
                                                <option value="">--Select an option</option>
                                                <?php $types = explode(',', lang('numbers')); 
                                                    foreach( $types as $type ):
                                                ?>
                                                <option value="<?= trim($type); ?>"><?= trim($type); ?></option>
                                                <?php endforeach; ?>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-sm-3">
                                        <div class="form-group">
                                            <label >No. of Bathrooms</label>
                                            <select class="selectpicker" name="no_of_bathrooms" data-style="form-control" >
                                                <option value="">--Select an option--</option>
                                                <?php $types = explode(',', lang('numbers')); 
                                                    foreach( $types as $type ):
                                                ?>
                                                <option value="<?= trim($type); ?>"><?= trim($type); ?></option>
                                                <?php endforeach; ?>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <br>
                            
                                <!--section 2 -->
                        <h3 class="box-title">Property Information</h3>
                            <div class="white-box">
                                <div class="form-group">
                                    <label for="pdesc">Property Description</label>
                                    <textarea class="form-control" rows="5" name="property_description" value="<?php if(isset($_POST['property_description']))set_value('property_description'); ?>" placeholder="Detailed information about your property"></textarea>
                                </div>                                
                                <div class="row">
                                    <div class="col-sm-4">
                                        <div class="form-group">
                                            <label>Age of the Building (optional)</label>
                                            <select class="selectpicker" name="building_age" data-style="form-control">
                                                <option value="">--Select an option--</option>
                                                <?php $types = explode(',', lang('numbers')); 
                                                    foreach( $types as $type ):
                                                ?>
                                                <option value="<?= trim($type); ?>"><?= trim($type); ?></option>
                                                <?php endforeach; ?>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-sm-4">
                                        <div class="form-group">
                                            <label>Number of toilets (optional)</label>
                                            <select class="selectpicker" name="no_of_toilets" data-style="form-control">
                                                <option value="">--Select an option--</option>
                                                <?php $types = explode(',', lang('numbers')); 
                                                    foreach( $types as $type ):
                                                ?>
                                                <option value="<?= trim($type); ?>"><?= trim($type); ?></option>
                                                <?php endforeach; ?>
                                            </select> 
                                        </div>
                                    </div>
                                    <div class="col-sm-4">
                                        <div class="form-group">
                                            <label>Storey Building? (optional)</label>
                                            <select class="selectpicker" name="no_of_storey" data-style="form-control">
                                                <option value="">--Select an option--</option>
                                                <?php $types = explode(',', lang('numbers')); 
                                                    foreach( $types as $type ):
                                                ?>
                                                <option value="<?= trim($type); ?>"><?= trim($type); ?></option>
                                                <?php endforeach; ?>
                                            </select>                                                
                                        </div>
                                    </div>
                                </div>
                                <label>Optional Property Features</label>
                                <div class="row">
                                    <?php $features = explode(',', lang('property_features')); foreach( $features as $feature  ) : ?>
                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <div class="checkbox checkbox-info checkbox-circle">
                                                    <input type="checkbox" name="property_features[]" value="<?= ucwords(trim($feature)); ?>">
                                                    <label for="<?= ucwords(trim($feature)); ?>"><?= ucwords(trim($feature)); ?></label>
                                                </div>
                                        </div>
                                    </div>
                                    <?php endforeach; ?>
                                </div>
                                <div class="row">
                                    <div class="col-sm-3">
                                        <div class="form-group">
                                            <label >Property floor type</label>
                                            <select class="selectpicker" name="floor_type" data-style="form-control" >
                                                <option value="">--Floor Type --</option>
                                                <?php $types = explode(',', lang('floor_type')); 
                                                    foreach( $types as $type ):
                                                ?>
                                                <option value="<?= trim($type); ?>"><?= ucwords(trim($type)); ?></option>
                                                <?php endforeach; ?>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-sm-3">
                                        <div class="gorm-group">
                                            <label>Minimum Payment Period</label>
                                            <select class="selectpicker" name="payment_period" data-style="form-control" >
                                                <option value="">-- Minimum Payment Period --</option>
                                                <?php $types = explode(',', lang('payment_period')); 
                                                    foreach( $types as $type ):
                                                ?>
                                                <option value="<?= trim($type); ?>"><?= ucwords(trim($type)); ?></option>
                                                <?php endforeach; ?>
                                            </select>                                                
                                        </div>
                                    </div>
                                    <div class="col-sm-3">
                                        <div class="form-group">
                                            <label>Landlord Living in Premises</label>
                                            <select class="selectpicker" name="landlord" data-style="form-control" >
                                                <option value="">-- Landlord Living in Premises --</option>
                                                <?php $types = explode(',', lang('landlord')); 
                                                    foreach( $types as $type ):
                                                ?>
                                                <option value="<?= ucwords(trim($type)); ?>"><?= ucwords(trim($type)); ?></option>
                                                <?php endforeach; ?>
                                            </select>                                                
                                        </div>
                                    </div>
                                    <div class="col-sm-3">
                                        <div class="form-group">
                                            <label >State of Building</label>
                                            <select class="selectpicker" name="state_of_building" data-style="form-control" >
                                                <option value="">-- State of Building --</option>
                                                <?php $types = explode(',', lang('state_of_building')); 
                                                    foreach( $types as $type ):
                                                ?>
                                                <option value="<?= ucwords(trim($type)); ?>"><?= ucwords(trim($type)); ?></option>
                                                <?php endforeach; ?>
                                            </select>                                                
                                        </div>
                                    </div>
                                </div>
                            </div><!-- / white-box -->
                            <br>
                               <!-- section 3 -->
                        <h3 class="box-title">Final Details/Image Upload</h3>
                            <div class="white-box">
                                <div class="row">
                                    <div class="col-sm-6">
                                        <div class="form-group">
                                            <label >Address</label>
                                            <input type="text" class="form-control" placeholder="Address of the property" name="address" value="<?php if(isset($_POST['address'])) set_value('address'); ?>"> 
                                        </div>
                                    </div>
                                    <div class="col-sm-6">
                                        <div class="form-group">
                                            <label for="landmark">Landmark</label>
                                            <input type="text" class="form-control" placeholder="Where is the building close to?" value="<?php if(isset($_POST['landmark'])) set_value('landmark'); ?>" name="landmark"> 
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-sm-6">
                                        <div class="form-group">
                                            <label>State where property is located</label>
                                            <select class="form-control" name="state">
                                                <option value="">--Select State--</option>
                                                <?php $types = explode(',', lang('states')); 
                                                        foreach( $types as $type ):
                                                    ?>
                                                    <option value="<?= trim($type); ?>"><?= ucwords(trim($type)); ?></option>
                                                <?php endforeach; ?>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-sm-6">
                                        <div class="form-group">
                                            <label>L.G.A.</label>
                                            <select class="form-control" name="lga" >
                                                <option value="">--Choose L.G.A--</option>
                                                <?php $types = explode(',', lang('lga')); 
                                                    foreach( $types as $type ):
                                                ?>
                                                <option value="<?= trim($type); ?>"><?= ucwords(trim($type)); ?></option>
                                                <?php endforeach; ?>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="white-box">                                
                                <div class="form-group">
                                    <label class="col-lg-2 control-label text-semibold">Property Image Upload:</label>
                                    <div class="col-lg-10">
                                        <input type="file" class="property_image" name="property_image_upload[]" multiple="multiple">
                                        <span class="help-block">Upload a compelling image. We recommend using at least a 2160x1080px (2:1 ratio) image that's no larger than <code>10MB</code>.</span>
                                    </div>
                                </div>
                            </div>
                            <br>
                                <button type="submit" class="btn btn-success waves-effect waves-light m-r-10">Submit Property</button>
                            <?= form_close(); ?>
                    </div> <!-- col-sm-12 -->
                </div><!-- row -->
            </div>
        </div>
            <!-- /.container-fluid -->
            <footer class="footer text-center"><?= lang('footer_text'); ?></footer>
    </div>
        <!-- /#page-wrapper -->
    <!-- jQuery -->
    <script type="text/javascript" src="<?= base_url(); ?>assets/app/js/dump/jquery.min.js"></script>
    <script type="text/javascript" src="<?= base_url(); ?>assets/app/js/dump/pace.min.js"></script>
    <script type="text/javascript" src="<?= base_url(); ?>assets/app/js/dump/bootstrap.min.js"></script>
    <script type="text/javascript" src="<?= base_url(); ?>assets/app/js/dump/blockui.min.js"></script>
    <!-- /core JS files -->
    <!-- Theme JS files -->  
    
    <script src="<?= base_url('assets/app/plugins/bower_components/jquery/dist/jquery.min.js'); ?>"></script>
    <!-- Bootstrap Core JavaScript -->
    <script src="<?= base_url('assets/app/bootstrap/dist/js/tether.min.js'); ?>"></script>
    <script src="<?= base_url('assets/app/bootstrap/dist/js/bootstrap.min.js'); ?>"></script>
    <!-- Sidebar menu plugin JavaScript -->
    <script src="<?= base_url('assets/app/plugins/bower_components/sidebar-nav/dist/sidebar-nav.min.js'); ?>"></script>
    <!--Slimscroll JavaScript For custom scroll-->
    <script src="<?= base_url('assets/app/js/jquery.slimscroll.js'); ?>"></script>
    <!--Wave Effects -->
    <script src="<?= base_url('assets/app/js/waves.js'); ?>"></script>
    <!-- Custom Theme JavaScript -->
    <script src="<?= base_url('assets/app/plugins/bower_components/bootstrap-select/bootstrap-select.min.js');?>" type="text/javascript"></script>
    <!-- Upload JS --> 

    <script src="<?= base_url('assets/app/js/custom.min.js'); ?>"></script>
    <script type="text/javascript" src="<?= base_url(); ?>assets/app/js/dump/plugins/purify.min.js"></script>
    <script type="text/javascript" src="<?= base_url(); ?>assets/app/js/dump/plugins/sortable.min.js"></script>
    <script type="text/javascript" src="<?= base_url(); ?>assets/app/js/dump/fileinput.min.js"></script>
    <script type="text/javascript" src="<?= base_url(); ?>assets/app/js/dump/uploader_bootstrap.js"></script>
    <script type="text/javascript" src="<?= base_url(); ?>assets/app/js/validate.min.js"></script>
    <!-- <script type="text/javascript" src="<?= base_url('assets/app/js/dump/dropzone.min.js'); ?>"></script>
    <script type="text/javascript" src="<?= base_url('assets/app/js/dump/uploader_dropzone.js'); ?>"></script> -->

<!--     <script type="text/javascript">
        
    init();
    function init() {
        var validator = $(".create_event").validate({
                ignore: 'input[type=hidden]', // ignore hidden fields
                errorClass: 'validation-error-label',
                successClass: 'validation-valid-label',
                highlight: function(element, errorClass) {
                    $(element).removeClass(errorClass);
                },
                unhighlight: function(element, errorClass) {
                    $(element).removeClass(errorClass);
                },
                // Different components require proper error label placement
                errorPlacement: function(error, element) {
                    // Styled checkboxes, radios, bootstrap switch
                    if (element.parents('div').hasClass("checker") || element.parents('div').hasClass("choice") || element.parent().hasClass('bootstrap-switch-container') ) {
                        if(element.parents('label').hasClass('checkbox-inline') || element.parents('label').hasClass('radio-inline')) {
                            error.appendTo( element.parent().parent().parent().parent() );
                        }
                         else {
                            error.appendTo( element.parent().parent().parent().parent().parent() );
                        }
                    }
                    // Unstyled checkboxes, radios
                    else if (element.parents('div').hasClass('checkbox') || element.parents('div').hasClass('radio')) {
                        error.appendTo( element.parent().parent().parent() );
                    }
                    // Input with icons and Select2
                    else if (element.parents('div').hasClass('has-feedback') || element.hasClass('select2-hidden-accessible')) {
                        // error.appendTo(element.parent());
                        // element.parent().parent().addClass('has-warning');
                    }
                    // Inline checkboxes, radios
                    else if (element.parents('label').hasClass('checkbox-inline') || element.parents('label').hasClass('radio-inline')) {
                        error.appendTo( element.parent().parent() );
                    }
                    // Input group, styled file input
                    else if (element.parent().hasClass('uploader') || element.parents().hasClass('input-group')) {
                        error.appendTo( element.parent().parent() );
                    }
                    else {
                        error.insertAfter(element);
                    }
                },
                validClass: "validation-valid-label",
                success: function(label) {
                    label.addClass("validation-valid-label").text("Success.")
                },
                rules: {
                    title: {
                        minlength: 3
                    },
                    event_address: {
                        minlength: 3
                    },
                    event_location: {
                        minlength: 3
                    },
                    event_description: {
                        minlength: 30
                    }
                },
                messages: {
                    thn_terms: {
                        required: "Accept our terms and condition to continue",

                    }
                }
            });
        }
    </script> -->
</body>
</html>