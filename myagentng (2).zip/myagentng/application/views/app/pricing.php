<?php $this->load->view('app/includes/head'); ?>
<!-- Stylesheet -->
</head>
<body>
    <div id="wrapper">
       <!-- Top Navigation -->
        <nav class="navbar navbar-default navbar-static-top m-b-0">
            <?php $this->load->view('app/includes/nav'); ?>
        </nav>
        <!-- End Top Navigation -->
        <!-- Left navbar-header -->
        <div class="navbar-default sidebar" role="navigation">
            <?php $this->load->view('app/includes/sidebar'); ?>
        </div>
        <!-- Left navbar-header end -->
        <!-- Page Content -->
        <div id="page-wrapper">
            <div class="container-fluid">
                <div class="row bg-title">
                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                        <h4 class="page-title">Choose your subscription plan</h4>
                    </div>
                    <!-- /.col-lg-12 -->
                </div>
                
                 <!-- .row -->
                <div class="row">
                    <div class="col-md-12">
                        <div class="white-box">
                            <div class="row pricing-plan">
                                <div class="col-md-4 col-xs-12 col-sm-6 no-padding">
                                    <div class="pricing-box">
                                        <?php
                                            $plan1 = explode(',', lang('plan1'));

                                        ?>

                                        <div class="pricing-body b-l">
                                            <div class="pricing-header">
                                                <h4 class="text-center"><?= $plan1[0]; ?></h4>
                                                <h2 class="text-center"><span class="price-sign">&#8358;</span><?= $plan1[1];?></h2>
                                                <p class="uppercase"><?= $plan1[2]; ?></p>
                                            </div>
                                            <div class="price-table-content">
                                                <div class="price-row"><i class="icon-user"></i><?= $plan1[3]; ?></div>
                                                <div class="price-row"><i class="icon-clock"></i><?= $plan1[4]; ?></div>
                                                <div class="price-row"><i class="icon-phone"></i><?= $plan1[5]; ?></div>
                                                <div class="price-row"><i class="icon-refresh"></i> <span style="font-size:20px;"><?= $plan1[6]; ?></span></div>
                                                <div class="price-row">
                                                    <button class="btn btn-success waves-effect waves-light m-t-20">Select Plan</button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-4 col-xs-12 col-sm-6 no-padding">
                                    <div class="pricing-box b-l">
                                        <?php
                                            $plan2 = explode(',', lang('plan2'));
                                        ?>
                                        <div class="pricing-body">
                                            <div class="pricing-header">
                                                <h4 class="text-center"><?= $plan2[0]; ?></h4>
                                                <h2 class="text-center"><span class="price-sign"></span><?= ngn($plan2[1]);?></h2>
                                                <p class="uppercase"><?= $plan2[2]; ?></p>
                                            </div>
                                            <div class="price-table-content">
                                                <div class="price-row"><i class="icon-user"></i><?= $plan2[3]; ?></div>
                                                <div class="price-row"><i class="icon-clock"></i><?= $plan2[4]; ?></div>
                                                <div class="price-row"><i class="icon-phone"></i><?= $plan2[5]; ?></div>
                                                <div class="price-row"><i class="icon-refresh"></i> <span style="font-size:20px;"><?= $plan2[6]; ?></span></div>
                                                <div class="price-row">
                                                    <button class="btn btn-success waves-effect waves-light m-t-20">Select Plan</button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-4 col-xs-12 col-sm-6 no-padding">
                                    <div class="pricing-box featured-plan">
                                        <?php
                                            $plan3 = explode(',', lang('plan3'));
                                        ?>
                                        <div class="pricing-body">
                                            <div class="pricing-header">
                                                <h4 class="price-lable text-white bg-warning"> Best</h4>
                                                <h4 class="text-center"><?= $plan3[0]; ?></h4>
                                                <h2 class="text-center"><span class="price-sign"></span><?= ngn($plan3[1]); ?></h2>
                                                <p class="uppercase"><?= $plan3[2]; ?></p>
                                            </div>
                                            <div class="price-table-content">
                                                <div class="price-row"><i class="icon-calender"></i><?= $plan3[3]; ?></div>
                                                <div class="price-row"><i class="icon-clock"></i><?= $plan3[4]; ?></div>
                                                <div class="price-row"><i class="icon-phone"></i>  <strong><?= $plan3[5]; ?></strong></div>
                                                <div class="price-row"><i class="icon-refresh"></i><?= $plan3[6];?></div>
                                                <div class="price-row">
                                                    <button class="btn btn-lg btn-info waves-effect waves-light m-t-20">Select Plan</button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- /.row -->
            </div>
             <footer class="footer text-center"><?= lang('footer_text'); ?></footer>
        </div>
        <!-- /#page-wrapper -->
    </div>
    <!-- /#wrapper -->
    <!-- jQuery -->
    <script src="<?= base_url('assets/app/plugins/bower_components/jquery/dist/jquery.min.js'); ?>"></script>
    <!-- Bootstrap Core JavaScript -->
    <script src="<?= base_url('assets/app/bootstrap/dist/js/tether.min.js'); ?>"></script>
    <script src="<?= base_url('assets/app/bootstrap/dist/js/bootstrap.min.js'); ?>"></script>
    <script src="<?= base_url('assets/app/plugins/bower_components/bootstrap-extension/js/bootstrap-extension.min.js'); ?>"></script>
    <!-- Sidebar menu plugin JavaScript -->
    <script src="<?= base_url('assets/app/plugins/bower_components/sidebar-nav/dist/sidebar-nav.min.js'); ?>"></script>
    <!-- bootstrap-select javascript -->
    <script src="<?= base_url('assets/app/plugins/bower_components/bootstrap-select/bootstrap-select.min.js'); ?>"></script>
    <!--Slimscroll JavaScript For custom scroll-->
    <script src="<?= base_url('assets/app/js/jquery.slimscroll.js'); ?>"></script>
    <!--Wave Effects -->
    <script src="<?= base_url('assets/app/js/waves.js'); ?>"></script>
    <!-- Custom Theme JavaScript -->
    <script src="<?= base_url('assets/app/js/custom.min.js'); ?>"></script>

    <script src="<?= base_url('assets/app/plugins/bower_components/jquery-sparkline/jquery.sparkline.min.js'); ?>"></script>
    <script src="<?= base_url('assets/app/plugins/bower_components/jquery-sparkline/jquery.charts-sparkline.js'); ?>"></script>
</body>
</html>


