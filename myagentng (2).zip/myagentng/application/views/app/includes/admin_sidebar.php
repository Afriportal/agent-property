<?php
// Count notification rows
$owners_count = $this->user_model->get_rows('users', 
                                        array('user_type' => 'owners' ));
$users_count = $this->user_model->get_rows('users', 
                                        array('user_type' => 'users' ));
$agents_count = $this->user_model->get_rows('users', 
                                        array('user_type' => 'agents' ));

?>
<nav class="navbar navbar-default navbar-static-top m-b-0">
            <div class="navbar-header">
                <a class="navbar-toggle hidden-sm hidden-md hidden-lg " href="javascript:void(0)" data-toggle="collapse" data-target=".navbar-collapse"><i class="ti-menu"></i></a>
                <div class="top-left-part">
                    <a class="logo" href="#">
                        <b><!--This is dark logo icon--><img src="<?= base_url('assets/app/plugins/images/pix.png'); ?>" alt="home" class="dark-logo" /></b>
                        <span class="hidden-xs"><!--This is dark logo text-->
                            <img src="<?= base_url('assets/app/plugins/images/myagent.png'); ?>" alt="home" class="dark-logo" />
                        </span>
                    </a>
                </div>
                <ul class="nav navbar-top-links navbar-left hidden-xs">
                    <li><a href="javascript:void(0)" class="open-close hidden-xs waves-effect waves-light"><i class="icon-arrow-left-circle ti-menu"></i></a></li>
                </ul>
            </div>
            <a class="dropdown-toggle waves-effect waves-light" data-toggle="dropdown" href="#"><i class="icon-envelope"></i>
          <div class="notify"><span class="heartbit"></span><span class="point"></span></div>
          </a>
        </nav>


        <!-- End Top Navigation -->
        <!-- Left navbar-header -->
        <div class="navbar-default sidebar" role="navigation">
            <div class="sidebar-nav navbar-collapse slimscrollsidebar">
                <div class="user-profile">
                    <div class="dropdown user-pro-body">
                        <div>
                            <img src="<?= base_url('assets/app/plugins/images/pix.png'); ?>" alt="user-img" class="img-circle">
                        </div>
                    </div>
                </div>
                <ul class="nav" id="side-menu">
                    <li class="sidebar-search hidden-sm hidden-md hidden-lg">
                        <!-- input-group -->
                        <div class="input-group custom-search-form">
                            <input type="text" class="form-control" placeholder="Search...">
                            <span class="input-group-btn">
                            <button class="btn btn-default" type="button"> <i class="fa fa-search"></i> </button>
                            </span> 
                        </div>
                        <!-- /input-group -->
                    </li>
                    <li><a href="<?= base_url('admin'); ?>" class="waves-effect "><i class="icon-home fa-fw"></i> <span class="hide-menu">Dashboard<span class="fa arrow"></span></span></a>
                    </li>
                    <li><a href="<?= base_url('admin/my_properties'); ?>" class="waves-effect "><i class="icon-key fa-fw"></i> <span class="hide-menu">My Properties<span class="fa arrow"></span></span></a>
                    </li>
                    <li><a href="<?= base_url('admin/profile'); ?>" class="waves-effect "><i class=" icon-user-follow fa-fw"></i> <span class="hide-menu">Profile Details<span class="fa arrow"></span></span></a>
                    </li>
                    <li><a href="<?= base_url('admin/favourited'); ?>" class="waves-effect "><i class="icon-like fa-fw"></i> <span class="hide-menu">Favourited Property<span class="fa arrow"></span></span></a>
                    </li>
                    <li><a href="<?= base_url('admin/owners'); ?>" class="waves-effect "><i class="icon-user-following fa-fw"></i> <span class="hide-menu">Home Owners <?php if($owners_count) : ?><span class="label label-info"> <?= $owners_count; ?></span><?php endif; ?><span class="fa arrow"></span></span></a>
                    </li>
                    <li><a href="<?= base_url('admin/users'); ?>" class="waves-effect "><i class="icon-people fa-fw"></i> <span class="hide-menu">Users <?php if($users_count) : ?><span class="label label-info"> <?= $users_count; ?></span><?php endif; ?><span class="fa arrow"></span></span></a>
                    </li>
                    <li><a href="<?= base_url('admin/agents'); ?>" class="waves-effect "><i class="icon-user-follow fa-fw"></i> <span class="hide-menu">Agents <?php if($agents_count) : ?><span class="label label-info"> <?= $agents_count; ?></span><?php endif; ?><span class="fa arrow"></span></span></a>
                    </li>
                    <li><a href="<?= base_url('create'); ?>" class="waves-effect "><i class="icon-list fa-fw"></i> <span class="hide-menu">Submit Property <span class="fa arrow"></span></span></a>
                    </li>
                    <li><a href="<?= base_url('admin/change_password'); ?>" class="waves-effect "><i class="icon-lock fa-fw"></i> <span class="hide-menu">Change Password<span class="fa arrow"></span></span></a>
                    </li>
                    <li><a href="#" class="waves-effect "><i class="icon-logout fa-fw"></i> <span class="hide-menu">Logout<span class="fa arrow"></span></span></a>
                    </li>
                </ul>
            </div>
        </div>