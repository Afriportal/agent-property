<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" type="image/png" sizes="16x16" href="../plugins/images/favicon.png">
    <title>Dashboard | Myagent.ng</title>
    <!-- Bootstrap Core CSS -->
    <link href="<?= base_url('assets/app/bootstrap/dist/css/bootstrap.min.css'); ?>" rel="stylesheet">
    <link href="<?= base_url('assets/app/plugins/bower_components/bootstrap-extension/css/bootstrap-extension.css'); ?>" rel="stylesheet">
    <!-- Menu CSS -->
    <link href="<?= base_url('assets/app/plugins/bower_components/sidebar-nav/dist/sidebar-nav.min.css'); ?>" rel="stylesheet">
    <link href="<?= base_url('assets/app/plugins/bower_components/toast-master/css/jquery.toast.css'); ?>" rel="stylesheet">
    <!-- animation CSS -->
    <link href="<?= base_url('assets/app/css/animate.css'); ?>" rel="stylesheet">
    <!-- Custom CSS -->
    <link href="<?= base_url('assets/app/css/style.css'); ?>" rel="stylesheet">
    <!-- color CSS -->
    <link href="<?= base_url('assets/app/css/colors/gray-dark.css'); ?>" id="theme" rel="stylesheet">

    <link href="<?= base_url('assets/app/plugins/bower_components/bootstrap-select/bootstrap-select.min.css'); ?>" rel="stylesheet" />