<?php $this->load->view('app/includes/admin_head'); ?>
</head>
<body>
    <div id="wrapper">
        <!-- Top Navigation -->
        <?php $this->load->view('app/includes/admin_sidebar'); ?>
        <!-- Left navbar-header end -->
        <!-- Page Content -->
        <div id="page-wrapper">
            <div class="container-fluid">
                <div class="row bg-title">
                    <div class="col-lg-3 col-md-4 col-sm-4 col-xs-12">
                        <h4 class="page-title">My Properties Overview</h4>
                    </div>
                    <div class="col-lg-9 col-sm-8 col-md-8 col-xs-12">
                        <ol class="breadcrumb">
                            <li><a href="#">Dashboard</a></li>
                            <li class="active">You are signed in as an <span class="label label-success">Admin</span> </li>
                        </ol>
                    </div>
                    <!-- /.col-lg-12 -->
                </div>
                        
                <!-- .row -->
                <div class="row">
                    <?php if( !empty($properties) ) : 
                        foreach( $properties as $property ): 
                            $src = !empty($property_image) ? base_url('assets/app/images/').$property_image->img_name : base_url('assets/app/images/my-properties-2.jpg');
                    ?>
                    <div class="col-sm-6 col-md-4 col-lg-4">
                        <div class="white-box pro-box p-0">

                            <div class="pro-list-img" style="background: url('../plugins/images/property/prop5.jpg') center center / cover no-repeat;"> <span class="pro-label-img"><img src="<?= $src; ?>" alt="heart"></span> </div>
                            <div class="pro-content-3-col">
                                <div class="pro-list-details">
                                    <h4>
                                        <a class="text-dark" href="javascript:void(0)"><?= $property->address; ?></a>
                                    </h4>
                                    <h4 class="text-danger"><?= ngn($property->price); ?></h4> 
                                </div>
                            </div>
                            <hr class="m-0"> <span class="label pro-col-label label-white text-dark"><?= ucwords($property->property_type);?></span>
                            <hr class="m-0">
                            <div class="pro-agent-col-3">
                               <a class="btn btn-block btn-info" href="<?= base_url( 'property/'. $property->pid .'/'. url_title(strtolower($property->title)) ); ?>">View Property Details</a>
                            </div>
                            <div class="clearfix"></div>
                            
                        </div>
                    </div>                   
                    <?php endforeach; 
                        else : 
                    ?>
                    <div class="col-sm-6 col-md-4 col-lg-4">
                        <div class="white-box pro-box p-0"><h3 class="text-center">You have no property posted on the platform.</h3></div>
                    </div>
                    <?php endif; ?>
                </div>
                <!-- /.row -->
                </div>
                <!-- /.row -->
            <!-- /.container-fluid -->
            </div>
            <footer class="footer text-center"> <?= lang('footer_text'); ?> </footer>
        </div>
        <!-- /#page-wrapper -->
    </div>
    <!-- /#wrapper -->
    <!-- jQuery -->
    <script src="<?= base_url('assets/app/plugins/bower_components/jquery/dist/jquery.min.js'); ?>"></script>
        <!-- Sweet-Alert  -->
    <script src="<?= base_url('assets/app/plugins/bower_components/sweetalert/sweetalert.min.js'); ?>"></script>
    <script src="<?= base_url('assets/app/plugins/bower_components/sweetalert/jquery.sweet-alert.custom.js'); ?>"></script>
    <!-- Bootstrap Core JavaScript -->
    <script src="<?= base_url('assets/app/bootstrap/dist/js/tether.min.js'); ?>"></script>
    <script src="<?= base_url('assets/app/bootstrap/dist/js/bootstrap.min.js'); ?>"></script>
    <script src="<?= base_url('assets/app/plugins/bower_components/bootstrap-extension/js/bootstrap-extension.min.js'); ?>"></script>
    <!-- Menu Plugin JavaScript -->
    <script src="<?= base_url('assets/app/plugins/bower_components/sidebar-nav/dist/sidebar-nav.min.js'); ?>"></script>
    <!--slimscroll JavaScript -->
    <script src="<?= base_url('assets/app/js/jquery.slimscroll.js'); ?>"></script>
    <!--Wave Effects -->
    <script src="<?= base_url('assets/app/js/waves.js'); ?>"></script>
    <!-- Custom Theme JavaScript -->
    <script src="<?= base_url('assets/app/js/custom.min.js'); ?>"></script>

</body>
</html>