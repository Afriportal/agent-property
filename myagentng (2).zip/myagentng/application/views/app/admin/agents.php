<?php $this->load->view('app/includes/admin_head'); ?>
</head>
<body>
    <div id="wrapper">
        <!-- Top Navigation -->
        <?php $this->load->view('app/includes/admin_sidebar'); ?>
        <!-- Left navbar-header end -->
        <!-- Page Content -->
        <div id="page-wrapper">
            <div class="container-fluid">
                <div class="row bg-title">
                    <div class="col-lg-3 col-md-4 col-sm-4 col-xs-12">
                        <h4 class="page-title">Agents' Profile details</h4>
                    </div>
                    <div class="col-lg-9 col-sm-8 col-md-8 col-xs-12">
                        <ol class="breadcrumb">
                            <li class="active">You are signed in as an <span class="label label-success">Admin</span> </li>
                        </ol>
                    </div>
                    <!-- /.col-lg-12 -->
                </div>
                <?php if(isset($agent) && !empty($agent) ) : ?>
                    <div class="row">
                        <div class="col-md-4 col-xs-12">
                            <div class="white-box">
                                <div class="user-bg"> 
                                    <div class="overlay-box">
                                        <div class="user-content">
                                            <a href="javascript:void(0)"><img src="<?= base_url('assets/app/images/') . $agent->avatar ; ?>" class="thumb-lg img-circle" alt="<?= $agent->name ; ?>"></a>
                                            <h5 class="text-white"><?= $agent->email; ?></h5>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-8 col-xs-12">
                            <div class="white-box">
                                <ul class="nav customtab nav-tabs" role="tablist">
                                    <li role="presentation" class="nav-item"><a href="#profile" class="nav-link" aria-controls="profile" role="tab" data-toggle="tab" aria-expanded="false"><span class="visible-xs"><i class="fa fa-user"></i></span> <span class="hidden-xs">Profile</span></a></li>
                                    <li role="presentation" class="nav-item"><a href="#messages" class="nav-link" aria-controls="messages" role="tab" data-toggle="tab" aria-expanded="false"><span class="visible-xs"><i class="fa fa-cog"></i></span> <span class="hidden-xs">Message user</span></a></li>
                                </ul>
                                <div class="tab-content">
                                    <div class="tab-pane active" id="profile">
                                        <div class="row">
                                            <div class="col-md-4 col-xs-6 b-r"> <strong>Full Name</strong>
                                                <br>
                                                <p class="text-muted"><?= ucwords($agent->name); ?></p>
                                            </div>
                                            <div class="col-md-4 col-xs-6 b-r"> <strong> Current Subscription</strong>
                                                <br>
                                                <span class="label label-success">Premium</span>
                                            </div>
                                            <div class="col-md-4 col-xs-6 b-r"> 
                                                <button class="btn btn-danger delete-account" data-id="<?= $agent->id; ?>">Delete Account</button>
                                            </div>
                                        </div>
                                        <hr>
                                        <h3>About Me</h3>
                                        <p class="m-t-30"><?= $agent->about; ?></p>
                                    </div>
                                    <div class="tab-pane" id="messages">                                           
                                        <?= form_open('admin/send_message', 'class="form-horizontal form-material"'); ?>
                                            <div class="form-group">
                                                <label class="col-md-12">Message</label>
                                                <div class="col-md-12">
                                                    <textarea rows="5" name="message" class="form-control form-control-line"></textarea>
                                                </div>
                                            </div>
                                            <input type="hidden" name="receiver" value="<?= $agent->id; ?>">
                                            <input type="hidden" name="user_type" value="<?= $agent->user_type; ?>">
                                            <div class="form-group">
                                                <div class="col-sm-12">
                                                    <button type="submit" class="btn btn-success">Send</button>
                                                </div>
                                            </div>
                                        <?= form_close(); ?>
                                        <!-- Loop out all the preiviously sent messages -->
                                        <?php // receiver , //sender
                                            $messages = $this->user_model->fetch_messages( $agent->id, $this->session->userdata('user_id')); 
                                            if( empty( $messages ) ) : 
                                                echo '<h3 class="text-center text text-danger">You have no message with this user</h3>';
                                            else :
                                                echo '<ul>';
                                                foreach( $messages as $message ) :
                                        ?>
                                                    <li>
                                                        <h2><small><?= date('h:ia - l, dS F, Y', strtotime($message->datetime)); ?></small></h2>
                                                        <p class="m-t-40">
                                                            <?= ucfirst($message->message); ?>
                                                        </p>
                                                    </li>

                                        <?php
                                            endforeach;
                                            echo '</ul>';
                                        endif; 
                                        ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php else : ?>
                <div class="col-sm-12">
                    <div class="white-box">
                        <p class="text-muted m-b-30">Export data to Copy, CSV, Excel, PDF & Print</p>
                        <div class="table-responsive">
                            <table id="example23" class="display nowrap" cellspacing="0" width="100%">
                                <thead>
                                    <tr>
                                        <th>Full Name</th>
                                        <th>Date Registered</th>
                                        <th>Listings</th>
                                        <th>Subscription</th>
                                        <th>Profile</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach( $agents as $agent ) : ?>
                                    <tr>
                                        <td><?= ucwords($agent->name); ?></td>
                                        <td><?= date('l, dS F, Y', strtotime($agent->date_registered)); ?></td>
                                        <td><?= $this->agent_model->get_rows('property', 
                                                array('id' => $agent->id )) ?>
                                        </td>
                                        <td><span class="label label-info">Standard</span></td>
                                        <td><a href="<?= base_url('admin/agents/'. $agent->id ); ?>">View User Detail</a></td>
                                    </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
            </div>
            <!-- /.row -->
        </div>
    </div>

   <!-- /#wrapper -->
    <!-- jQuery -->
    <script src="<?= base_url('assets/app/plugins/bower_components/jquery/dist/jquery.min.js'); ?>"></script>
    <!-- Bootstrap Core JavaScript -->
    <script src="<?= base_url('assets/app/bootstrap/dist/js/tether.min.js'); ?>"></script>
    <script src="<?= base_url('assets/app/bootstrap/dist/js/bootstrap.min.js'); ?>"></script>
    <script src="<?= base_url('assets/app/plugins/bower_components/bootstrap-extension/js/bootstrap-extension.min.js'); ?>"></script>
    <!-- Menu Plugin JavaScript -->
    <script src="<?= base_url('assets/app/plugins/bower_components/sidebar-nav/dist/sidebar-nav.min.js'); ?>"></script>
    <!--slimscroll JavaScript -->
    <script src="<?= base_url('assets/app/js/jquery.slimscroll.js'); ?>"></script>
    <!--Wave Effects -->
    <script src="<?= base_url('assets/app/js/waves.js'); ?>"></script>
    <!-- Custom Theme JavaScript -->
    <script src="<?= base_url('assets/app/js/custom.min.js'); ?>"></script>
    <script src="<?= base_url('assets/app/plugins/bower_components/datatables/jquery.dataTables.min.js'); ?>"></script>
    <!-- start - This is for export functionality only -->
    <!-- Data-Table-JS -->
    <script src="<?= base_url('assets/app/plugins/datatable/jquery.dataTables.min.js'); ?>"></script>
    <script src="<?= base_url('assets/app/plugins/datatable/dataTables.bootstrap.min.js');?>"></script>
    <script src="<?= base_url('assets/app/plugins/datatable/dataTables.select.min.js'); ?>"></script>
    <script src="<?= base_url('assets/app/plugins/datatable/dataTables.buttons.min.js'); ?>"></script>
    <script src="<?= base_url('assets/app/plugins/datatable/buttons.flash.min.js');?>"></script>
    <script src="<?= base_url('assets/app/plugins/datatable/jszip.min.js'); ?>"></script>
    <script src="<?= base_url('assets/app/plugins/datatable/vfs_fonts.js'); ?>"></script>
    <script src="<?= base_url('assets/app/plugins/datatable/buttons.html5.min.js'); ?>"></script>
    <script src="<?= base_url('assets/app/plugins/datatable/buttons.print.min.js'); ?>"></script>
    <script src="<?= base_url('assets/app/plugins/datatable/datatable-custom.js'); ?>"></script>
    <!-- end - This is for export functionality only -->
    <script>
    $(document).ready(function() {
        $('#myTable').DataTable();
        $(document).ready(function() {
            var table = $('#example').DataTable({
                "columnDefs": [{
                    "visible": false,
                    "targets": 2
                }],
                "order": [
                    [2, 'asc']
                ],
                "displayLength": 25,
                "drawCallback": function(settings) {
                    var api = this.api();
                    var rows = api.rows({
                        page: 'current'
                    }).nodes();
                    var last = null;

                    api.column(2, {
                        page: 'current'
                    }).data().each(function(group, i) {
                        if (last !== group) {
                            $(rows).eq(i).before(
                                '<tr class="group"><td colspan="5">' + group + '</td></tr>'
                            );

                            last = group;
                        }
                    });
                }
            });

            // Order by the grouping
            $('#example tbody').on('click', 'tr.group', function() {
                var currentOrder = table.order()[0];
                if (currentOrder[0] === 2 && currentOrder[1] === 'asc') {
                    table.order([2, 'desc']).draw();
                } else {
                    table.order([2, 'asc']).draw();
                }
            });
        });
    });
    $('#example23').DataTable({
        dom: 'Bfrtip',
        buttons: [
            'copy', 'csv', 'excel', 'pdf', 'print'
        ]
    });
    </script>
</body>

</html>
