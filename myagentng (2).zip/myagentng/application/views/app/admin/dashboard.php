<?php $this->load->view('app/includes/admin_head'); ?>
</head>
<body>
    <div id="wrapper">
        <!-- Top Navigation -->
        <?php $this->load->view('app/includes/admin_sidebar'); ?>
        <!-- Left navbar-header end -->
        <!-- Page Content -->
        <div id="page-wrapper">
            <div class="container-fluid">
                <div class="row bg-title">
                    <div class="col-lg-3 col-md-4 col-sm-4 col-xs-12">
                        <h4 class="page-title">Dashboard</h4>
                    </div>
                    <div class="col-lg-9 col-sm-8 col-md-8 col-xs-12">
                        <ol class="breadcrumb">
                            <li><a href="#">Dashboard</a></li>
                            <li class="active">You are signed in as an <span class="label label-success">Admin</span></li>
                        </ol>
                    </div>
                    <!-- /.col-lg-12 -->
                </div>
                <!--.Alert -->
                <div class="row">
                    <div class="col-md-12">
                        <div class="alert alert-success alert-dismissable">
                            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                            A new verification document has been submitted by an agent. <a href="agent-profile.php">Click HERE</a> to view now. 
                        </div>
                    </div>
                </div>
                <!-- /.row -->
                <div class="row re">
                    <div class="col-lg-3 col-sm-6 col-xs-12">
                        <div class="white-box">
                            <h3 class="box-title"><a href="<?= base_url('admin/properties'); ?>">All Properties</a></h3>
                            <ul class="list-inline two-part">
                                <li><i class="ti-home text-info"></i></li>
                                <li class="text-right"><span class="counter"><a href="<?= base_url('admin/properties'); ?>"><?= $all_properties; ?></a></span></li>
                            </ul>
                        </div>                        
                    </div>
                    <div class="col-lg-3 col-sm-6 col-xs-12">
                        <div class="white-box">
                            <h3 class="box-title"><a href="<?= base_url('admin/properties/?type=for sale'); ?>">Properties for Sale</a></h3>
                            <ul class="list-inline two-part">
                                <li><i class="icon-tag text-purple"></i></li>
                                <li class="text-right"><span class="counter"><a href="<?= base_url('admin/properties/?type=for sale'); ?>"><?= $for_sale; ?></a></span></li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-lg-3 col-sm-6 col-xs-12">
                        <div class="white-box">
                            <h3 class="box-title"><a href="<?= base_url('admin/properties/?type=for rent'); ?>">Properties for Rent</a></h3>
                            <ul class="list-inline two-part">
                                <li><i class="icon-basket text-danger"></i></li>
                                <li class="text-right"><span class="counter"><a href="<?= base_url('admin/properties/?type=for rent'); ?>"><?= $for_rent; ?></a></span></li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-lg-3 col-sm-6 col-xs-12">
                        <div class="white-box">
                            <h3 class="box-title"><a href="<?= base_url('admin/properties/?type=short let'); ?>">Short Let Properties</a></h3>
                            <ul class="list-inline two-part">
                                <li><i class="ti-wallet text-success"></i></li>
                                <li class="text-right"><span class="counter"><a href="<?= base_url('admin/properties/?type=short let'); ?>"><?= $short_let; ?></a></span></li>
                            </ul>
                        </div>
                    </div>
                </div>
                <!-- /.row -->
                <!-- row -->
                <div class="row">
                <div class="col-md-12">
						<div class="box-widget widget-module">
							<div class="panel panel-default">
								<div class="panel-heading">
									<div class="panel-title">
										<h4>Recent Listing</h4>
									</div>
								</div>
								<div class="panel-body">
                                    <div class="table-responsive">
    									<div class="basic-datatable-block exportable-datatable-block">
    										<table id="exportable-data-table" class="display table table-bordered basic-data-table">
    											<thead>
    												<tr>
    													<th>Name</th>
    													<th>Property title</th>
                                                        <th>User Type</th>
    													<th>Type</th>
                                                        <th>Status</th>
    													<th>Date</th>
    													<th>Plan</th>
                                                        <th>Action</th>
    												</tr>
    											</thead>
    											<tbody>
    												
                                                    <?php foreach ($recents as $recent ) : 
                                                        // Get the user name
                                                        $user = $this->user_model->get_single( $recent->uid );
                                                        $plan = $this->user_model->get_subscription( $recent->id, $recent->uid );
                                                    ?>
                                                    <tr>
                                                        <td><?= ucwords($user->name) ; ?></td>
                                                        <td><a href="<?= base_url( 'admin/property_details/'. $recent->pid); ?>"><?= word_limiter(ucwords($recent->title), 10, '...'); ?></a></td>
                                                        <td><?= ucfirst($user->user_type); ?></td>
                                                        <td><?= ucwords($recent->property_type); ?></td>
                                                        <td><span class="label label-warning font-weight-100">pending</span></td>
                                                        <td><?= date('h:ia - l, dS F, Y', strtotime($recent->postdate)); ?></td>
                                                        <td>
                                                            <span class="label label-success font-weight-100">
                                                                <?= !empty($plan) ? $plan['plan_name'] : 'Free' ; ?>                                                           
                                                            </span>
                                                        </td>
                                                        <td>
                                                            <span class="label label-success" id="sa-approve" data-pid="<?= $recent->id; ?>" style="cursor:pointer">
                                                            <i class="fa fa-check"></i>
                                                            </span>
                                                            <span class="label label-danger" id="sa-warning" data-pid="<?= $recent->id; ?>" style="cursor:pointer">
                                                            <i class="fa fa-times"></i>
                                                            </span>
                                                        </td>
                                                    </tr>
                                                    <?php endforeach; ?>
    											</tbody>
    										</table>
    									</div><!-- borderd-table-block -->                                        
                                    </div>
                                </div>
                            </div>
                    </div>

                <!-- /.row -->
                </div>
                </div>
                <!-- /.row -->
            <!-- /.container-fluid -->
            </div>
            <footer class="footer text-center"> <?= lang('footer_text'); ?> </footer>
        </div>
        <!-- /#page-wrapper -->
    </div>
    <!-- jQuery -->
    <script src="<?= base_url('assets/app/plugins/bower_components/jquery/dist/jquery.min.js'); ?>"></script>
        <!-- Sweet-Alert  -->
    <script src="<?= base_url('assets/app/plugins/bower_components/sweetalert/sweetalert.min.js'); ?>"></script>
    <script src="<?= base_url('assets/app/plugins/bower_components/sweetalert/jquery.sweet-alert.custom.js'); ?>"></script>
    <!-- Bootstrap Core JavaScript -->
    <script src="<?= base_url('assets/app/bootstrap/dist/js/tether.min.js'); ?>"></script>
    <script src="<?= base_url('assets/app/bootstrap/dist/js/bootstrap.min.js'); ?>"></script>
    <script src="<?= base_url('assets/app/plugins/bower_components/bootstrap-extension/js/bootstrap-extension.min.js'); ?>"></script>
    <!-- Menu Plugin JavaScript -->
    <script src="<?= base_url('assets/app/plugins/bower_components/sidebar-nav/dist/sidebar-nav.min.js'); ?>"></script>
    <!--slimscroll JavaScript -->
    <script src="<?= base_url('assets/app/js/jquery.slimscroll.js'); ?>"></script>
    <!--Wave Effects -->
    <script src="<?= base_url('assets/app/js/waves.js'); ?>"></script>
    <!-- Custom Theme JavaScript -->
    <script src="<?= base_url('assets/app/js/custom.min.js'); ?>"></script>
	
	<!-- Data-Table-JS -->
	<script src="<?= base_url('assets/app/plugins/datatable/jquery.dataTables.min.js'); ?>"></script>
	<script src="<?= base_url('assets/app/plugins/datatable/dataTables.bootstrap.min.js');?>"></script>
	<script src="<?= base_url('assets/app/plugins/datatable/dataTables.select.min.js'); ?>"></script>
	<script src="<?= base_url('assets/app/plugins/datatable/dataTables.buttons.min.js');?>"></script>
	<script src="<?= base_url('assets/app/plugins/datatable/buttons.flash.min.js');?>"></script>
	<script src="<?= base_url('assets/app/plugins/datatable/jszip.min.js');?>"></script>
	<script src="<?= base_url('assets/app/plugins/datatable/vfs_fonts.js');?>"></script>
	<script src="<?= base_url('assets/app/plugins/datatable/buttons.html5.min.js');?>"></script>
	<script src="<?= base_url('assets/app/plugins/datatable/buttons.print.min.js');?>"></script>
	<script src="<?= base_url('assets/app/plugins/datatable/datatable-custom.js');?>"></script>
    
    </body>
</html>