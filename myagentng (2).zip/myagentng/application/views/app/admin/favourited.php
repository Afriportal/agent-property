<?php $this->load->view('app/includes/admin_head'); ?>
</head>
<body>
    <div id="wrapper">
        <!-- Top Navigation -->
        <?php $this->load->view('app/includes/admin_sidebar'); ?>
        <!-- Left navbar-header end -->
        <!-- Page Content -->
        <div id="page-wrapper">
            <div class="container-fluid">
                <div class="row bg-title">
                    <div class="col-lg-3 col-md-4 col-sm-4 col-xs-12">
                        <h4 class="page-title">Favourited Properties</h4>
                    </div>
                    <div class="col-lg-9 col-sm-8 col-md-8 col-xs-12">
                        <ol class="breadcrumb">
                            <li><a href="#">Dashboard</a></li>
                            <li class="active">You are signed in as an <span class="label label-success">Admin</span> </li>
                        </ol>
                    </div>
                    <!-- /.col-lg-12 -->
                </div>
                <!-- .row -->
                <div class="row">

                    <?php 
                    if( !empty($favourite) ) :
                        foreach( $favourite as $fav ) :?>
                        <div class="col-sm-6 col-md-3 col-lg-3">
                            <div class="white-box pro-box p-0">
                                <?php 
                                    $property_image = $this->property_model->fetch_featured_image( $fav->property_id );
                                    $src = !empty($property_image) ? base_url('assets/app/images/').$property_image->img_name : base_url('assets/app/images/my-properties-2.jpg'); 
                                    $property = $this->property_model->single_property($fav->property_id );
                                ?>
                                <div class="pro-list-img" style="background: url(<?= $src; ?>) center center / cover no-repeat;"> <span class="pro-label-img"><img src="<?= $src; ?>" alt="heart"></span> </div>
                                <div class="pro-content-3-col">
                                    <div class="pro-list-details">
                                        <h4>
                                            <a class="text-dark" href="javascript:void(0)"><?= $property['address']; ?></a>
                                        </h4>
                                        <h4 class="text-danger"><?= ngn($property['price']); ?></h4> 
                                    </div>
                                </div>
                                <hr class="m-0"> <span class="label pro-col-label label-white text-dark"><?= ucwords($property['property_type']); ?></span>
                                <div class="pro-list-info-3-col">
                                    <ul class="pro-info text-muted m-b-0">
                                        <a class="btn btn-block btn-info" href="<?= base_url( 'property/'. $property['pid'] .'/'. url_title(strtolower($property['title'])) ); ?>">View Favourite Details</a>
                                    </ul>
                                </div>
                                <div class="clearfix"></div>
                            </div>
                        </div>  
                        <?php 
                            endforeach;
                        else :
                         ?>  
                         <h3 class="text-title text-center"> You have not favourite any property yet.</h3>  
                        <?php endif; ?>   
                </div>
                    <!-- /.row -->
                <!-- /.row -->
                </div>
                <!-- /.row -->
            <!-- /.container-fluid -->
            </div>
            <footer class="footer text-center"> © 2017 myAgent.ng | Trademarks and brands are the property of their respective owners. </footer>
        </div>
        <!-- /#page-wrapper -->
    </div>
    <!-- /#wrapper -->
    <!-- jQuery -->
    <script src="<?= base_url('assets/app/plugins/bower_components/jquery/dist/jquery.min.js'); ?>"></script>
    <!-- Bootstrap Core JavaScript -->
    <script src="<?= base_url('assets/app/bootstrap/dist/js/tether.min.js'); ?>"></script>
    <script src="<?= base_url('assets/app/bootstrap/dist/js/bootstrap.min.js'); ?>"></script>
    <script src="<?= base_url('assets/app/plugins/bower_components/bootstrap-extension/js/bootstrap-extension.min.js'); ?>"></script>
    <!-- Sidebar menu plugin JavaScript -->
    <script src="<?= base_url('assets/app/plugins/bower_components/sidebar-nav/dist/sidebar-nav.min.js'); ?>"></script>
    <!-- bootstrap-select javascript -->
    <script src="<?= base_url('assets/app/plugins/bower_components/bootstrap-select/bootstrap-select.min.js'); ?>"></script>
    <!--Slimscroll JavaScript For custom scroll-->
    <script src="<?= base_url('assets/app/js/jquery.slimscroll.js'); ?>"></script>
    <!--Wave Effects -->
    <script src="<?= base_url('assets/app/js/waves.js'); ?>"></script>
    <!-- Custom Theme JavaScript -->
    <script src="<?= base_url('assets/app/js/custom.min.js'); ?>"></script>

</body>
</html>