<?php $this->load->view('app/includes/admin_head'); ?>
</head>
<body>
    <div id="wrapper">
        <!-- Top Navigation -->
        <?php $this->load->view('app/includes/admin_sidebar'); ?>
        <!-- Left navbar-header end -->
        <!-- Page Content -->
        <div id="page-wrapper">
            <div class="container-fluid">
                <div class="row bg-title">
                    <div class="col-lg-3 col-md-4 col-sm-4 col-xs-12">
                        <h4 class="page-title">Property Details</h4>
                    </div>
                    <div class="col-lg-9 col-sm-8 col-md-8 col-xs-12">
                        <ol class="breadcrumb">
                            <li><a href="#">Dashboard</a></li>
                            <li class="active">You are signed in as an <span class="label label-success">Admin</span> </li>
                        </ol>
                    </div>
                    <!-- /.col-lg-12 -->
                </div>
                
                                <!-- .row -->
                <div class="row">
                    <div class="col-md-4 col-xs-12">
                        <div class="white-box">
                                    <!-- START carousel-->
                                <div class="panel panel-default">
                                    <div class="panel-wrapper p-b-10 collapse in">
                                        <div id="owl-demo" class="owl-carousel owl-theme">
                                            <div class="item"><img src="../plugins/images/img1.jpg" alt="Owl Image"></div>
                                            <div class="item"><img src="../plugins/images/img2.jpg" alt="Owl Image"></div>
                                            <div class="item"><img src="../plugins/images/img3.jpg" alt="Owl Image"></div>
                                        </div>
                                    </div>
                                </div>
                                
                                    <!-- END carousel-->
                            <div class="user-btm-box">
                                <!-- .row -->
                                <div class="row text-center m-t-10">
                                    <div class="col-md-6 b-r"><strong>Monthly</strong>
                                        <p>₦10,000</p>
                                    </div>
                                    <div class="col-md-6"><strong>Yearly</strong>
                                        <p>₦120,000</p>
                                    </div>
                                </div>
                                <!-- /.row -->
                                <hr>
                                <!-- .row -->
                                <div class="row text-center m-t-10">
                                    <div class="col-md-12"><strong>Location</strong>
                                        <p><?= ucwords($property['address']); ?></p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-8 col-xs-12">
                        <div class="white-box">
                            <div class="row">
                                <div class="col-md-3 col-xs-6 b-r"> <strong>Status</strong>
                                    <br>
                                    <p class="text-muted" id="apprv"><span class="label label-rouded label-danger "><?= $property['status'] ?></span></p>
                                    <p class="text-muted hidden" id="disapprv"><span class="label label-rouded label-success ">Approved</span></p>
                                </div>
                                <div class="col-md-3 col-xs-6 b-r"> <strong>Edit Property</strong>
                                    <br>
                                    <a href="" class="btn btn-block btn-info">Click to Edit</a>
                                </div>
                                <div class="col-md-3 col-xs-6 b-r"> <strong>Hide Property</strong>
                                    <br>
                                    <button class="btn btn-block btn-warning">Click to Hide</button>
                                </div>
                                <div class="col-md-3 col-xs-6"> <strong>Delete Property</strong>
                                    <br>
                                    <button class="btn btn-block btn-danger">Click to Delete</button>
                                </div>
                            </div>
                            <hr>
                                <h4><strong>Property Title</strong></h4>
                                <h5><?= ucwords($property['title']); ?></h5>
                            <hr>
                            <h4><strong>Property Description</strong></h4>
                            <p class="m-t-30"><?= $property['description']; ?></p>
                            <hr>
                            <h5><strong>Date Posted</strong></h5>
                                <h5><?= date('d/m/Y', strtotime($property['postdate'])); ?></h5>
                            <hr>
                            <h5><strong>Property Views</strong></h5>
                                <h5><?= $property['views']; ?></h5>
                        </div>
                    </div>
                </div>
                <!-- /.row -->
                
            </div>
            <!-- /.container-fluid -->
            <footer class="footer text-center"><?= lang('footer_text'); ?> </footer>
        </div>
        <!-- /#page-wrapper -->
    </div>
      <!-- /#wrapper -->
    <!-- jQuery -->
    <script src="<?= base_url('assets/app/plugins/bower_components/jquery/dist/jquery.min.js'); ?>"></script>
    <!-- Bootstrap Core JavaScript -->
    <script src="<?= base_url('assets/app/bootstrap/dist/js/tether.min.js'); ?>"></script>
    <script src="<?= base_url('assets/app/bootstrap/dist/js/bootstrap.min.js'); ?>"></script>
    <script src="<?= base_url('assets/app/plugins/bower_components/bootstrap-extension/js/bootstrap-extension.min.js') ; ?>"></script>
    <!-- Menu Plugin JavaScript -->
    <script src="<?= base_url('assets/app/plugins/bower_components/sidebar-nav/dist/sidebar-nav.min.js'); ?>"></script>
    <!--slimscroll JavaScript -->
    <script src="<?= base_url('assets/app/js/jquery.slimscroll.js'); ?>"></script>   
    <!-- Custom Theme JavaScript -->
    <script src="<?= base_url('assets/app/js/custom.min.js'); ?>"></script>
    <!--Style Switcher -->
    <script src="<?= base_url('assets/app/plugins/bower_components/styleswitcher/jQuery.style.switcher.js'); ?>"></script>
</body>

</html>
