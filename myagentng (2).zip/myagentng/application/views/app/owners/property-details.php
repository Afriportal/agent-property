<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" type="image/png" sizes="16x16" href="../plugins/images/favicon.png">
    <title>Dashboard | Myagent.ng</title>
    <!-- Bootstrap Core CSS -->
    <?php include'css.php'?>
        <link href="../plugins/bower_components/owl.carousel/owl.carousel.min.css" rel="stylesheet" type="text/css" />
    <link href="../plugins/bower_components/owl.carousel/owl.theme.default.css" rel="stylesheet" type="text/css" />
</head>

<body>
    <div id="wrapper">
       <?php include'top-nav.php'?> 
        <!-- End Top Navigation -->
        <?php include'sidebar.php'?>
        <!-- Page Content -->
        <div id="page-wrapper">
            <div class="container-fluid">
                <div class="row bg-title">
                    <div class="col-lg-3 col-md-4 col-sm-4 col-xs-12">
                        <h4 class="page-title">Property Details</h4>
                    </div>
                    <div class="col-lg-9 col-sm-8 col-md-8 col-xs-12">
                        <ol class="breadcrumb">
                            <li><a href="#">Dashboard</a></li>
                            <li class="active">You are signed in as an <a href="#"><span class="label label-success">Owner</span></a> </li>
                        </ol>
                    </div>
                    <!-- /.col-lg-12 -->
                </div>
                
                                <!-- .row -->
                <div class="row">
                    <div class="col-md-4 col-xs-12">
                        <div class="white-box">
                                    <!-- START carousel-->
                                <div class="panel panel-default">
                            <div class="panel-wrapper p-b-10 collapse in">
                                        <div id="owl-demo" class="owl-carousel owl-theme">
                                            <div class="item"><img src="../plugins/images/img1.jpg" alt="Owl Image"></div>
                                            <div class="item"><img src="../plugins/images/img2.jpg" alt="Owl Image"></div>
                                            <div class="item"><img src="../plugins/images/img3.jpg" alt="Owl Image"></div>
                                        </div>
                                    </div>
                                </div>
                                
                                    <!-- END carousel-->
                            <div class="user-btm-box">
                                <!-- .row -->
                                <div class="row text-center m-t-10">
                                    <div class="col-md-6 b-r"><strong>Monthly</strong>
                                        <p>₦10,000</p>
                                    </div>
                                    <div class="col-md-6"><strong>Yearly</strong>
                                        <p>₦120,000</p>
                                    </div>
                                </div>
                                <!-- /.row -->
                                <hr>
                                <!-- .row -->
                                <div class="row text-center m-t-10">
                                    <div class="col-md-12"><strong>Location</strong>
                                        <p>Moshood Adeniye Street, Portharcourt, Rivers State, Nigeria</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-8 col-xs-12">
                        <div class="white-box">
                            <div class="row">
                                <div class="col-md-3 col-xs-6 b-r"> <strong>Status</strong>
                                    <br>
                                    <p class="text-muted" id="apprv"><span class="label label-rouded label-danger ">Unapproved</span></p>
                                    <p class="text-muted hidden" id="disapprv"><span class="label label-rouded label-success ">Approved</span></p>
                                </div>
                                <div class="col-md-3 col-xs-6 b-r"> <strong>Edit Property</strong>
                                    <br>
                                    <a href="" class="btn btn-block btn-info">Click to Edit</a>
                                </div>
                                <div class="col-md-3 col-xs-6 b-r"> <strong>Hide Property</strong>
                                    <br>
                                    <button class="btn btn-block btn-warning">Click to Hide</button>
                                </div>
                                <div class="col-md-3 col-xs-6"> <strong>Delete Property</strong>
                                    <br>
                                    <button class="btn btn-block btn-danger">Click to Delete</button>
                                </div>
                            </div>
                            <hr>
                            <h4><strong>Property Title</strong></h4>
                            <h5>Two Storey building in Agip for sales</h5>
                            <hr>
                            <h4><strong>Property Description</strong></h4>
                            <p class="m-t-30">Donec pede justo, fringilla vel, aliquet nec, vulputate eget, arcu. In enim justo, rhoncus ut, imperdiet a, venenatis vitae, justo. Nullam dictum felis eu pede mollis pretium. Integer tincidunt.Cras dapibus. Vivamus elementum semper nisi. Aenean vulputate eleifend tellus. Aenean leo ligula, porttitor eu, consequat vitae, eleifend ac, enim.</p>
                            <hr>
                            <h5><strong>Date Posted</strong></h5>
                            <h5>12/01/2018</h5>    
                            <hr>
                            <h5><strong>Property Views</strong></h5>
                            <h5>356</h5>
                        </div>
                    </div>
                </div>
                <!-- /.row -->
                
            </div>
            <!-- /.container-fluid -->
            <footer class="footer text-center">© 2017 myAgent.ng | Trademarks and brands are the property of their respective owners. </footer>
        </div>
        <!-- /#page-wrapper -->
    </div>
    <!-- /#wrapper -->
    <!-- jQuery -->
    <script src="../plugins/bower_components/jquery/dist/jquery.min.js"></script>
    <!-- Bootstrap Core JavaScript -->
    <script src="../bootstrap/dist/js/tether.min.js"></script>
    <script src="../bootstrap/dist/js/bootstrap.min.js"></script>
    <script src="../plugins/bower_components/bootstrap-extension/js/bootstrap-extension.min.js"></script>
    <!-- Menu Plugin JavaScript -->
    <script src="../plugins/bower_components/sidebar-nav/dist/sidebar-nav.min.js"></script>
    <!-- jQuery for carousel -->
    <script src="../plugins/bower_components/owl.carousel/owl.carousel.min.js"></script>
    <script src="../plugins/bower_components/owl.carousel/owl.custom.js"></script>
    <script src="../plugins/bower_components/toast-master/js/jquery.toast.js"></script>
    <script src="../js/toastr.js"></script>
</body>

</html>
