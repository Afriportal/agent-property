<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" type="image/png" sizes="16x16" href="../plugins/images/favicon.png">
    <title>Dashboard | Myagent.ng</title>
    <!-- Bootstrap Core CSS -->
    <?php include'css.php'?>
</head>

<body>
    <div id="wrapper">
       <?php include'top-nav.php'?> 
        <!-- End Top Navigation -->
        <?php include'sidebar.php'?>
        <!-- Page Content -->
        <div id="page-wrapper">
            <div class="container-fluid">
                <div class="row bg-title">
                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                        <h4 class="page-title">Choose your subscription plan</h4>
                    </div>
                    <!-- /.col-lg-12 -->
                </div>
                
                 <!-- .row -->
                <div class="row">
                    <div class="col-md-12">
                        <div class="white-box">
                            <div class="row pricing-plan">
                                <div class="col-md-4 col-xs-12 col-sm-6 no-padding">
                                    <div class="pricing-box">
                                        <div class="pricing-body b-l">
                                            <div class="pricing-header">
                                                <h4 class="text-center">Partnership</h4>
                                                <h2 class="text-center"><span class="price-sign">&#8358;</span>2%</h2>
                                                <p class="uppercase">partnership fee</p>
                                            </div>
                                            <div class="price-table-content">
                                                <div class="price-row"><i class="icon-user"></i> per property posted</div>
                                                <div class="price-row"><i class="icon-clock"></i> Post Unlimited Property per Month</div>
                                                <div class="price-row"><i class="icon-phone"></i> Contact details hidden</div>
                                                <div class="price-row"><i class="icon-refresh"></i> <span style="font-size:29px;">2%</span> partnership fee</div>
                                                <div class="price-row">
                                                    <button class="btn btn-success waves-effect waves-light m-t-20">Select Plan</button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-4 col-xs-12 col-sm-6 no-padding">
                                    <div class="pricing-box b-l">
                                        <div class="pricing-body">
                                            <div class="pricing-header">
                                                <h4 class="text-center">Standard</h4>
                                                <h2 class="text-center"><span class="price-sign">&#8358;</span>5,000</h2>
                                                <p class="uppercase">per property</p>
                                            </div>
                                            <div class="price-table-content">
                                                <div class="price-row"><i class="icon-user"></i> Monthly</div>
                                                <div class="price-row"><i class="icon-clock"></i> Post One Property per Month</div>
                                                <div class="price-row"><i class="icon-phone"></i> Contact details hidden (by default)</div>
                                                <div class="price-row"><i class="icon-refresh"></i> Clients can request contact details</div>
                                                <div class="price-row">
                                                    <button class="btn btn-success waves-effect waves-light m-t-20">Select Plan</button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-4 col-xs-12 col-sm-6 no-padding">
                                    <div class="pricing-box featured-plan">
                                        <div class="pricing-body">
                                            <div class="pricing-header">
                                                <h4 class="price-lable text-white bg-warning"> Best</h4>
                                                <h4 class="text-center">Premium</h4>
                                                <h2 class="text-center"><span class="price-sign">&#8358;</span>20,000</h2>
                                                <p class="uppercase">...</p>
                                            </div>
                                            <div class="price-table-content">
                                                <div class="price-row"><i class="icon-calender"></i>  3 Months</div>
                                                <div class="price-row"><i class="icon-clock"></i>  Post Unlimited Property</div>
                                                <div class="price-row"><i class="icon-phone"></i>  <strong>Contact details visible</strong></div>
                                                <div class="price-row"><i class="icon-refresh"></i> Property featured on home page</div>
                                                <div class="price-row">
                                                    <button class="btn btn-lg btn-info waves-effect waves-light m-t-20">Select Plan</button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- /.row -->
            </div>
             <footer class="footer text-center">© 2017 myAgent.ng | Trademarks and brands are the property of their respective owners.</footer>

        </div>
        <!-- /#page-wrapper -->
    </div>
    <!-- /#wrapper -->
    <!-- jQuery -->
    <script src="../plugins/bower_components/jquery/dist/jquery.min.js"></script>
    <!-- Bootstrap Core JavaScript -->
    <script src="../bootstrap/dist/js/tether.min.js"></script>
    <script src="../bootstrap/dist/js/bootstrap.min.js"></script>
    <script src="../plugins/bower_components/bootstrap-extension/js/bootstrap-extension.min.js"></script>
    <!-- Menu Plugin JavaScript -->
    <script src="../plugins/bower_components/sidebar-nav/dist/sidebar-nav.min.js"></script>
    <!--slimscroll JavaScript -->
    <script src="../js/jquery.slimscroll.js"></script>
    <!--Wave Effects -->
    <script src="../js/waves.js"></script>
    <!-- Custom Theme JavaScript -->
    <script src="../js/custom.min.js"></script>
    <!-- Sparkline chart JavaScript -->
    <script src="../plugins/bower_components/jquery-sparkline/jquery.sparkline.min.js"></script>
    <script src="../plugins/bower_components/jquery-sparkline/jquery.charts-sparkline.js"></script>
</body>
</html>
