<!-- Left navbar-header -->
        <div class="navbar-default sidebar" role="navigation">
            <div class="sidebar-nav navbar-collapse slimscrollsidebar">
                <div class="user-profile">
                    <div class="dropdown user-pro-body">
                        <div>
                            <img src="../plugins/images/pix.png" alt="user-img" class="img-circle">
                        </div>
                    </div>
                </div>
                <ul class="nav" id="side-menu">
                    <li class="sidebar-search hidden-sm hidden-md hidden-lg">
                        <!-- input-group -->
                        <div class="input-group custom-search-form">
                            <input type="text" class="form-control" placeholder="Search...">
                            <span class="input-group-btn">
            <button class="btn btn-default" type="button"> <i class="fa fa-search"></i> </button>
            </span> </div>
                        <!-- /input-group -->
                    </li>
                    <li><a href="properties.php" class="waves-effect "><i class="icon-key fa-fw"></i> <span class="hide-menu">My Properties<span class="fa arrow"></span></span></a>
                    </li>
                    <li><a href="profile.php" class="waves-effect "><i class=" icon-user-follow fa-fw"></i> <span class="hide-menu">Profile Details<span class="fa arrow"></span></span></a>
                    </li>
                    <li><a href="favourited-property.php" class="waves-effect "><i class="icon-like fa-fw"></i> <span class="hide-menu">Favourited Property<span class="fa arrow"></span></span></a>
                    </li>
                    <li><a href="submit-property.php" class="waves-effect "><i class="icon-list fa-fw"></i> <span class="hide-menu">Submit Property <span class="fa arrow"></span></span></a>
                    </li>
                    <li><a href="notification.php" class="waves-effect "><i class="icon-bubbles fa-fw"></i> <span class="hide-menu">Notifications <span class="label label-success">2</span><span class="fa arrow"></span></span></a>
                    </li>
                    <li><a href="change-password.php" class="waves-effect "><i class="icon-lock fa-fw"></i> <span class="hide-menu">Change Password<span class="fa arrow"></span></span></a>
                    </li>
                    <li><a href="#" class="waves-effect "><i class="icon-logout fa-fw"></i> <span class="hide-menu">Logout<span class="fa arrow"></span></span></a>
                    </li>
                </ul>
            </div>
        </div>
        <!-- Left navbar-header end -->