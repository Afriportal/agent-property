<?php $this->load->view('app/includes/head'); ?>
<!-- Stylesheet -->
</head>
<body>
    <div id="wrapper">
       <!-- Top Navigation -->
        <nav class="navbar navbar-default navbar-static-top m-b-0">
            <?php $this->load->view('app/includes/nav'); ?>
        </nav>
        <!-- End Top Navigation -->
        <!-- Left navbar-header -->
        <div class="navbar-default sidebar" role="navigation">
            <?php $this->load->view('app/includes/sidebar'); ?>
        </div>
        <!-- Left navbar-header end -->
        <!-- Page Content -->
        <div id="page-wrapper">
            <div class="container-fluid">
                <div class="row bg-title">
                    <div class="col-lg-3 col-md-4 col-sm-4 col-xs-12">
                        <h4 class="page-title">Notifications</h4>
                    </div>
                    <div class="col-lg-9 col-sm-8 col-md-8 col-xs-12">
                        <ol class="breadcrumb">
                            <li><span class="label label-danger">Unverified</span><span class="label label-success hidden">Verified</span></li>
                            <li class="active">You are signed in as a <a href="#"><span class="label label-success">Agent</span></a> </li>
                        </ol>
                    </div>
                    <!-- /.col-lg-12 -->
                </div>
                <div class="row">
                    <div class="col-md-12">
                        <div class="white-box">
                        <!-- .timeline -->
                            <?php
                                if( !empty($notifications) ) :
                                // Let us update
                                $this->user_model->notification_read( $this->session->userdata('user_id') );
                            ?>
                                <div class="events-content">
                                    <ul>
                                        <?php foreach( $notifications as $notification ) : ?>
                                        <li>
                                            <h2><small><?= date('h:ia - l, dS F, Y', strtotime($notification->datetime)); ?></small></h2>
                                            <p class="m-t-40">
                                                <?= ucfirst($notification->message); ?>
                                            </p>
                                        </li>
                                        <hr class="m-t-40">
                                        <?php endforeach; ?>
                                    </ul>
                                </div>
                            <?php else : ?>
                                <div class="events-content">
                                    <h3 class="text-center">You have no new notification</h3>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>

            </div>
            <!-- /.container-fluid -->
             <footer class="footer text-center"><?= lang('footer_text'); ?></footer>
        </div>
        <!-- /#page-wrapper -->
    </div>
    <!-- /#wrapper -->
    <!-- jQuery -->
    <script src="<?= base_url('assets/app/plugins/bower_components/jquery/dist/jquery.min.js'); ?>"></script>
    <!-- Bootstrap Core JavaScript -->
    <script src="<?= base_url('assets/app/bootstrap/dist/js/tether.min.js'); ?>"></script>
    <script src="<?= base_url('assets/app/bootstrap/dist/js/bootstrap.min.js'); ?>"></script>
    <script src="<?= base_url('assets/app/plugins/bower_components/bootstrap-extension/js/bootstrap-extension.min.js'); ?>"></script>
    <!-- Sidebar menu plugin JavaScript -->
    <script src="<?= base_url('assets/app/plugins/bower_components/sidebar-nav/dist/sidebar-nav.min.js'); ?>"></script>
    <!-- bootstrap-select javascript -->
    <script src="<?= base_url('assets/app/plugins/bower_components/bootstrap-select/bootstrap-select.min.js'); ?>"></script>
    <!--Slimscroll JavaScript For custom scroll-->
    <script src="<?= base_url('assets/app/js/jquery.slimscroll.js'); ?>"></script>
    <!--Wave Effects -->
    <script src="<?= base_url('assets/app/js/waves.js'); ?>"></script>
    <!-- Custom Theme JavaScript -->
    <script src="<?= base_url('assets/app/js/custom.min.js'); ?>"></script>

</body>
</html>