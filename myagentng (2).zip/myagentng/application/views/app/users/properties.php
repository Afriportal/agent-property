<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" type="image/png" sizes="16x16" href="../plugins/images/favicon.png">
    <title>Dashboard | Myagent.ng</title>
    <!-- Bootstrap Core CSS -->
    <?php include'css.php'?>

</head>

<body>
    <div id="wrapper">
       <?php include'top-nav.php'?> 
        <!-- End Top Navigation -->
        <?php include'sidebar.php'?>
        <!-- Page Content -->
        <div id="page-wrapper">
            <div class="container-fluid">
                <div class="row bg-title">
                    <div class="col-lg-3 col-md-4 col-sm-4 col-xs-12">
                        <h4 class="page-title">My Properties Overview</h4>
                    </div>
                    <div class="col-lg-9 col-sm-8 col-md-8 col-xs-12">
                        <ol class="breadcrumb">
                            <li><a href="#">Dashboard</a></li>
                            <li class="active">You are signed in as a <a href="#"><span class="label label-success">User</span></a> </li>
                        </ol>
                    </div>
                    <!-- /.col-lg-12 -->
                </div>
                        
                <!-- .row -->
                <div class="row">
                    <div class="col-sm-6 col-md-4 col-lg-4">
                        <div class="white-box pro-box p-0">
                            <div class="pro-list-img" style="background: url('../plugins/images/property/prop5.jpg') center center / cover no-repeat;"> <span class="pro-label-img"><img src="../plugins/images/property/heart.png" alt="heart"></span> </div>
                            <div class="pro-content-3-col">
                                <div class="pro-list-details">
                                    <h4>
                                    <a class="text-dark" href="javascript:void(0)">10 Crescent street, Rumuola Junction</a>
                                </h4>
                                    <h4 class="text-danger"><small>&#8358;</small> 220,000</h4> </div>
                            </div>
                            <hr class="m-0"> <span class="label pro-col-label label-white text-dark">For Rent</span>
                             <div class="pro-list-info-3-col">
                                <ul class="pro-info text-muted m-b-0">
                                    <li> 
                                        <span>Listing Category:</span>
                                        <span class="label label-warning ">Partnership</span>
                                    </li>
                                </ul>
                            </div>
                            <hr class="m-0">
                            <div class="pro-agent-col-3">
                               <a href="property-details.php" class="btn btn-block btn-info">View Property Details</a>
                            </div>
                            <div class="clearfix"></div>
                        </div>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-4">
                        <div class="white-box pro-box p-0">
                            <div class="pro-list-img" style="background: url('../plugins/images/property/prop5.jpg') center center / cover no-repeat;"> <span class="pro-label-img"><img src="../plugins/images/property/heart.png" alt="heart"></span> </div>
                            <div class="pro-content-3-col">
                                <div class="pro-list-details">
                                    <h4>
                                    <a class="text-dark" href="javascript:void(0)">Johnson Allen avenue, Rumuokoro</a>
                                </h4>
                                    <h4 class="text-danger"><small>&#8358;</small> 220,000</h4> </div>
                            </div>
                            <hr class="m-0"> <span class="label pro-col-label label-white text-dark">Shortlet</span>
                             <div class="pro-list-info-3-col">
                                <ul class="pro-info text-muted m-b-0">
                                    <li> 
                                        <span>Listing Category:</span>
                                        <span class="label label-success ">Standard</span>
                                    </li>
                                </ul>
                            </div>
                            <hr class="m-0">
                            <div class="pro-agent-col-3">
                               <a href="property-details.php" class="btn btn-block btn-info">View Property Details</a>
                            </div>
                            <div class="clearfix"></div>
                        </div>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-4">
                        <div class="white-box pro-box p-0">
                            <div class="pro-list-img" style="background: url('../plugins/images/property/prop5.jpg') center center / cover no-repeat;"> <span class="pro-label-img"><img src="../plugins/images/property/heart.png" alt="heart"></span> </div>
                            <div class="pro-content-3-col">
                                <div class="pro-list-details">
                                    <h4>
                                    <a class="text-dark" href="javascript:void(0)">Johnson Allen avenue, Rumuokoro Off Rumuola Road, Portharcourt</a>
                                </h4>
                                    <h4 class="text-danger"><small>&#8358;</small> 220,000</h4> </div>
                            </div>
                            <hr class="m-0"> <span class="label pro-col-label label-white text-dark">For Sale</span>
                             <div class="pro-list-info-3-col">
                                <ul class="pro-info text-muted m-b-0">
                                    <li> 
                                        <span>Listing Category:</span>
                                        <span class="label label-info ">Premium</span>
                                    </li>
                                </ul>
                            </div>
                            <hr class="m-0">
                            <div class="pro-agent-col-3">
                               <a href="property-details.php" class="btn btn-block btn-info">View Property Details</a>
                            </div>
                            <div class="clearfix"></div>
                        </div>
                    </div>
                   
                </div>
                <!-- /.row -->
                </div>
                <!-- /.row -->
            <!-- /.container-fluid -->
            </div>
            <footer class="footer text-center"> © 2017 myAgent.ng | Trademarks and brands are the property of their respective owners. </footer>
        </div>
        <!-- /#page-wrapper -->
    </div>
    <!-- /#wrapper -->
    <!-- jQuery -->
    <script src="../plugins/bower_components/jquery/dist/jquery.min.js"></script>
    <!-- Bootstrap Core JavaScript -->
    <script src="../bootstrap/dist/js/tether.min.js"></script>
    <script src="../bootstrap/dist/js/bootstrap.min.js"></script>
    <script src="../plugins/bower_components/bootstrap-extension/js/bootstrap-extension.min.js"></script>
    <!-- Sidebar menu plugin JavaScript -->
    <script src="../plugins/bower_components/sidebar-nav/dist/sidebar-nav.min.js"></script>
    <!-- bootstrap-select javascript -->
    <script src="../plugins/bower_components/bootstrap-select/bootstrap-select.min.js"></script>
    <!--Slimscroll JavaScript For custom scroll-->
    <script src="../js/jquery.slimscroll.js"></script>
    <!--Wave Effects -->
    <script src="../js/waves.js"></script>
    <!-- Custom Theme JavaScript -->
    <script src="../js/custom.min.js"></script>

</body>
</html>