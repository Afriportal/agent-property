<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" type="image/png" sizes="16x16" href="../plugins/images/favicon.png">
    <title>Dashboard | Myagent.ng</title>
    <!-- Bootstrap Core CSS -->
    <?php include'css.php'?>
    <!-- Dropzone css -->
    <link rel="stylesheet" href="../plugins/bower_components/dropify/dist/css/dropify.min.css">
</head>

<body>
    <div id="wrapper">
       <?php include'top-nav.php'?> 
        <!-- End Top Navigation -->
        <?php include'sidebar.php'?>
        <!-- Page Content -->
        <div id="page-wrapper">
            <div class="container-fluid">
                <div class="row bg-title">
                    <div class="col-lg-3 col-md-4 col-sm-4 col-xs-12">
                        <h4 class="page-title">Post a new property</h4>
                    </div>
                    <div class="col-lg-9 col-sm-8 col-md-8 col-xs-12">
                        <ol class="breadcrumb">
                            <li><a href="#">Dashboard</a></li>
                            <li class="active">You are signed in as a <a href="#"><span class="label label-success">User</span></a> </li>
                        </ol>
                    </div>
                    <!-- /.col-lg-12 -->
                </div>
                 <!-- .row -->
                <div class="row">
                    <div class="col-md-12">
                        <div class="white-box">
                            <form class="pro-add-form">
                                <div class="form-group">
                                <h3 class="box-title">Basic Information</h3>
                                <hr>
                                    <label for="pname">Property Name</label>
                                    <input type="text" class="form-control" id="pname" placeholder="Enter Property Title"> 
                                </div>
                                <div class="form-group">
                                    <label class="m-b-10">Purpose of Property Listing</label>
                                    <br>
                                    <div class="radio radio-info radio-inline">
                                        <input type="radio" id="radio1" value="option1" name="ptype" checked="">
                                        <label for="radio1"> For Rent </label>
                                    </div>
                                    <div class="radio radio-info radio-inline">
                                        <input type="radio" id="radio2" value="option2" name="ptype">
                                        <label for="radio2"> For Sale </label>
                                    </div>
                                    <div class="radio radio-info radio-inline">
                                        <input type="radio" id="radio2" value="option2" name="ptype">
                                        <label for="radio2"> For Lease </label>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="pname">Price of Property</label>
                                    <input type="text" class="form-control" id="pname" placeholder="NGN"> 
                                </div>
                                <div class="form-group">
                                    <div class="row">
                                        <div class="col-sm-3">
                                            <label >Type of property *</label>
                                            <select class="selectpicker" data-style="form-control" >
                                                <option value="">-- Select Option --</option>
                                                <option value="">Halls</option>
                                                <option value="">Office space</option>
                                                <option value="">Shops</option>
                                                <option value="">Warehouses</option>
                                                <option value="">Farm tanks</option>
                                                <option value="">Workshops</option>
                                                <option value="">Barges</option>
                                                <option value="">Land</option>
                                                <option value="">Apartment</option>
                                                <option value="">House</option>
                                                <option value="">Commercial</option>
                                                <option value="">Detached Building</option>
                                                <option value="">Block of Flats</option>
                                                <option value="">High Rise Building</option>
                                                <option value="">Ground floor</option>
                                                <option value="">Apartment Building</option>
                                                <option value="">Bungalow</option>
                                            </select>
                                        </div>
                                        <div class="col-sm-3">
                                            <label >Payment Schedule</label>
                                            <select class="selectpicker" data-style="form-control" >
                                                <option value="">-- Select Option --</option>
                                                <option value="">Monthly</option>
                                                <option value="">Yearly</option>
                                                <option value="">One-time</option>
                                            </select>
                                        </div>
                                        <div class="col-sm-3">
                                            <label >No. of Bedrooms</label>
                                            <select class="selectpicker" data-style="form-control" >
                                                <option value="">-- Select Option --</option>
                                                <option value="">1</option>
                                                <option value="">2</option>
                                                <option value="">3</option>
                                                <option value="">4</option>
                                                <option value="">5</option>
                                                <option value="">6</option>
                                                <option value="">More</option>
                                            </select>
                                        </div>
                                        <div class="col-sm-3">
                                            <label >No. of Bathrooms</label>
                                            <select class="selectpicker" data-style="form-control" >
                                                <option value="">-- Select Option --</option>
                                                <option value="">1</option>
                                                <option value="">2</option>
                                                <option value="">3</option>
                                                <option value="">4</option>
                                                <option value="">5</option>
                                                <option value="">6</option>
                                                <option value="">More</option>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                                <!--section 2 -->
                                <h1 class="box-title">Property Information</h1>
                                <hr>
                                <div class="form-group">
                                    <label for="pdesc">Property Description</label>
                                    <textarea class="form-control" rows="5" id="pdesc" placeholder="Detailed information about your property"></textarea>
                                </div>
                                
                                <div class="form-group">
                                    <div class="row">
                                        <div class="col-sm-4">
                                            <label for="tch1">Building age (optional)</label>
                                            <input id="tch1" type="text" value="" name="tch1" data-bts-button-down-class="btn btn-default btn-outline" data-bts-button-up-class="btn btn-default btn-outline">
                                        </div>
                                        <div class="col-sm-4">
                                            <label for="tch2">No. of toilets (optional)</label>
                                            <input id="tch2" type="text" value="" name="tch2" data-bts-button-down-class="btn btn-default btn-outline" data-bts-button-up-class="btn btn-default btn-outline"> </div>
                                        <div class="col-sm-4">
                                            <label for="tch3">How many Storey Building? (optional)</label>
                                            <input id="tch3" type="text" value="" name="tch3" data-bts-button-down-class="btn btn-default btn-outline" data-bts-button-up-class="btn btn-default btn-outline"> </div>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label>Optional Property Features</label>
                                    <div class="row">
                                        <div class="col-sm-3">
                                            <div class="checkbox checkbox-info checkbox-circle">
                                                <input id="checkbox1" type="checkbox" >
                                                <label for="checkbox1"> Veranda </label>
                                            </div>
                                            <div class="checkbox checkbox-info checkbox-circle">
                                                <input id="checkbox2" type="checkbox" >
                                                <label for="checkbox2"> Balcony </label>
                                            </div>
                                            <div class="checkbox checkbox-info checkbox-circle">
                                                <input id="checkbox3" type="checkbox">
                                                <label for="checkbox3"> Store </label>
                                            </div>
                                        </div>
                                        <div class="col-sm-3">
                                            <div class="checkbox checkbox-info checkbox-circle">
                                                <input id="checkbox4" type="checkbox">
                                                <label for="checkbox4"> Double Window </label>
                                            </div>
                                            <div class="checkbox checkbox-info checkbox-circle">
                                                <input id="checkbox5" type="checkbox" >
                                                <label for="checkbox5"> Single Window </label>
                                            </div>
                                            <div class="checkbox checkbox-info checkbox-circle">
                                                <input id="checkbox6" type="checkbox">
                                                <label for="checkbox6"> Packing Space </label>
                                            </div>
                                        </div>
                                        <div class="col-sm-3">
                                            <div class="checkbox checkbox-info checkbox-circle">
                                                <input id="checkbox7" type="checkbox">
                                                <label for="checkbox7"> Negotiable</label>
                                            </div>
                                            <div class="checkbox checkbox-info checkbox-circle">
                                                <input id="checkbox8" type="checkbox">
                                                <label for="checkbox8"> Nearness to IOC </label>
                                            </div>
                                            <div class="checkbox checkbox-info checkbox-circle">
                                                <input id="checkbox9" type="checkbox" >
                                                <label for="checkbox9"> Nearness to Police Station </label>
                                            </div>
                                        </div>
                                        <div class="col-sm-3">
                                            <div class="checkbox checkbox-info checkbox-circle">
                                                <input id="checkbox10" type="checkbox">
                                                <label for="checkbox10"> Nearness to Water Body</label>
                                            </div>
                                            <div class="checkbox checkbox-info checkbox-circle">
                                                <input id="checkbox11" type="checkbox">
                                                <label for="checkbox11"> Nearness to Market </label>
                                            </div>
                                            <div class="checkbox checkbox-info checkbox-circle">
                                                <input id="checkbox12" type="checkbox" >
                                                <label for="checkbox12"> Nearness to Bus Stop </label>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <div class="row">
                                        <div class="col-sm-3">
                                            <label >Property floor type</label>
                                            <select class="selectpicker" data-style="form-control" >
                                                <option>-- Floor Type --</option>
                                                <option>Marble</option>
                                                <option>Terazzo</option>
                                                <option>Tiles</option>
                                                <option>Others</option>
                                            </select>
                                        </div>
                                        <div class="col-sm-3">
                                            <label >Minimum Payment Period</label>
                                            <select class="selectpicker" data-style="form-control" >
                                                <option>-- Minimum Payment Period --</option>
                                                <option>Less than One Year</option>
                                                <option>One Year</option>
                                                <option>Above One Year</option>
                                            </select>
                                        </div>
                                        <div class="col-sm-3">
                                            <label >Landlord Living in Premises</label>
                                            <select class="selectpicker" data-style="form-control" >
                                                <option>-- Landlord Living in Premises --</option>
                                                <option>Yes</option>
                                                <option>No</option>
                                            </select>
                                        </div>
                                        <div class="col-sm-3">
                                            <label >State of Building</label>
                                            <select class="selectpicker" data-style="form-control" >
                                                <option>-- State of Building --</option>
                                                <option>Newly Built</option>
                                                <option>Renovated</option>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="m-b-10">Security Post Available?</label>
                                    <br>
                                    <div class="radio radio-info radio-inline">
                                        <input type="radio" id="radio1" value="option1" name="ptype" checked="">
                                        <label for="radio1"> Yes </label>
                                    </div>
                                    <div class="radio radio-info radio-inline">
                                        <input type="radio" id="radio2" value="option2" name="ptype">
                                        <label for="radio2"> No </label>
                                    </div>
                                </div>
                               <!-- section 3 -->
                                <h1 class="box-title">Final Details</h1>
                                <hr>
                                <div class="form-group">
                                    <div class="row">
                                        <div class="col-sm-6">
                                            <label >Location</label>
                                            <input type="text" class="form-control" placeholder="Address of the property"> </div>
                                        <div class="col-sm-6">
                                            <label for="kitchen">Landmark</label>
                                            <input type="text" class="form-control" placeholder="Where is the building close to?"> 
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <div class="row">
                                        <div class="col-sm-6">
                                            <label >State where property is located</label>
                                            <select class="selectpicker form-control">
                                                <option>Rivers State</option>
                                            </select>
                                        </div>
                                        <div class="col-sm-6">
                                            <div class="form-group">
                                                <label>Location</label>
                                                <select class="form-control" >
                                                    <option>Choose City</option>
                                                    <option>Abua / Odual L.G.A</option>
                                                    <option>Ahoada East L.G.A</option>
                                                    <option>Ahoada West L.G.A</option>
                                                    <option>Akuku Toru L.G.A</option>
                                                    <option>Andoni L.G.A</option>
                                                    <option>Asari-Toru L.G.A</option>
                                                    <option>Bonny L.G.A</option>
                                                    <option>Degema L.G.A</option>
                                                    <option>Emohua L.G.A</option>
                                                    <option>Eleme L.G.A</option>
                                                    <option>Etche L.G.A</option>
                                                    <option>Gokona L.G.A</option>
                                                    <option>Ikwerre L.G.A</option>
                                                    <option>Khana L.G.A</option>
                                                    <option>Obia / Akpor L.G.A</option>
                                                    <option>Ogba / Egbema / Ndoni L.G.A</option>
                                                    <option>Ogu / Bolo L.G.A</option>
                                                    <option>Okrika L.G.A</option>
                                                    <option>Omumma L.G.A</option>
                                                    <option>Opobo / Nkoro L.G.A</option>
                                                    <option>Oyigbo L.G.A</option>
                                                    <option>Port-Harcourt L.G.A</option>
                                                    <option>Tai L.G.A</option>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <form action="#" class="dropzone dz-clickable">
                                    <div class="dz-default dz-message"><span>Drop files here to upload</span></div>
                                </form>
                                <form action="#" class="dropzone dz-clickable">
                                <div class="fallback">
                                    <input name="file" type="file" multiple />
                                </div>
                            </form>
                                <button type="submit" class="btn btn-success waves-effect waves-light m-r-10">Submit Property</button>
                            </form>
                        </div>
                    </div>
                </div>
                <!-- .row -->
                    </div>
            <!-- /.container-fluid -->
            <footer class="footer text-center">© 2017 myAgent.ng | Trademarks and brands are the property of their respective owners. </footer>
        </div>
        <!-- /#page-wrapper -->
    </div>
    <!-- /#wrapper -->
    <!-- jQuery -->
    <script src="../plugins/bower_components/jquery/dist/jquery.min.js"></script>
    <!-- Bootstrap Core JavaScript -->
    <script src="../bootstrap/dist/js/tether.min.js"></script>
    <script src="../bootstrap/dist/js/bootstrap.min.js"></script>
    <script src="../plugins/bower_components/bootstrap-extension/js/bootstrap-extension.min.js"></script>
    <!-- Sidebar menu plugin JavaScript -->
    <script src="../plugins/bower_components/sidebar-nav/dist/sidebar-nav.min.js"></script>
    <!--Slimscroll JavaScript For custom scroll-->
    <script src="../js/jquery.slimscroll.js"></script>
    <!--Wave Effects -->
    <script src="../js/waves.js"></script>
    <!-- Custom Theme JavaScript -->
    <script src="../js/custom.min.js"></script>
    <script src="../js/mask.js"></script>
    <script src="../plugins/bower_components/bootstrap-select/bootstrap-select.min.js" type="text/javascript"></script>
    <script src="../plugins/bower_components/bootstrap-touchspin/dist/jquery.bootstrap-touchspin.min.js" type="text/javascript"></script>
    <!-- jQuery file upload -->
    <script src="../plugins/bower_components/dropify/dist/js/dropify.min.js"></script>
    <script>
    $("input[name='tch1']").TouchSpin();
    $("input[name='tch2']").TouchSpin();
    $("input[name='tch3']").TouchSpin();
    $("input[name='tch4']").TouchSpin();
    $("input[name='tch5']").TouchSpin();
    $('.dropify').dropify();
    </script>
</body>
</html>