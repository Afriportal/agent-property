<?php $this->load->view('landing/includes/header'); ?>
<!-- Styles -->
</head>
<body>
<!-- Top header start -->
<?php $this->load->view('landing/includes/top_head'); ?>
<!-- Main header end -->

<!-- Sub banner start -->
<div class="sub-banner2">
    <div class="overlay">
        <div class="container">
            <div class="breadcrumb-area-1">
                <h1>Properties for Sale</h1>
                <ul class="breadcrumbs">
                    <li><a href="<?= base_url(); ?>">Home</a></li>
                    <li class="active">For Sale</li>
                </ul>
            </div>
        </div>
    </div>
</div>
<!-- Sub Banner end -->

<!-- Properties section body start -->
<div class="properties-section-body content-area">
    <div class="container">
        <div class="row">
            <div class="col-lg-8 col-md-8 col-xs-12">
                <!-- Option bar start -->
                <div class="option-bar">
                    <div class="row">
                        <div class="col-lg-6 col-md-5 col-sm-5 col-xs-2">
                            <h4>
                                <span class="heading-icon">
                                    <i class="fa fa-th-list"></i>
                                </span>
                                <span class="hidden-xs">Properties for sale</span>
                            </h4>
                        </div>
                        <div class="col-lg-6 col-md-7 col-sm-7 col-xs-10 cod-pad">
                            <div class="sorting-options">
                                <select class="sorting">
                                    <option value="<?= base_url(current_url())?>">New To Old</option>
                                    <option>Old To New</option>
                                    <option>Properties (High To Low)</option>
                                    <option>Properties (Low To High)</option>
                                </select>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- Option bar end -->

                <div class="clearfix"></div>
                <?php 
                    if( !empty( $properties ) ) :
                        foreach($properties as $property ) :
                        $property_image = $this->property_model->fetch_featured_image( $property->pid ); 
                        $src = !empty($property_image) ? base_url('assets/app/images/').$property_image->img_name : base_url('assets/app/images/myagentng.jpg'); 

                    ?>
                    <!-- Property start -->
                    <div class="property clearfix wow fadeInUp delay-03s">
                        <div class="col-lg-5 col-md-5 col-sm-5 col-xs-12 col-pad">
                            <a href="<?= base_url( 'property/'. $property->pid .'/'. url_title(strtolower($property->title)) ); ?>" class="property-img">
                                <div class="property-tag button alt featured">Featured</div>
                                <div class="property-tag button sale"><?= ucwords($property->property_type); ?></div>
                                <div class="property-price"><span><?= ngn($property->price); ?></span></div>
                                <img src="<?= $src; ?>" alt="<?= $property->title; ?>" class="img-responsive">
                            </a>
                        </div>
                        <div class="col-lg-7 col-md-7 col-sm-7 col-xs-12 property-content ">
                            <!-- title -->
                            <h1 class="title">
                                <a href="<?= base_url( 'property/'. $property->pid .'/'. url_title(strtolower($property->title)) ); ?>"><?= word_limiter(ucwords($property->title), 9, '...'); ?></a>
                            </h1>
                            <!-- Property address -->
                            <h3 class="property-address">
                                <a href="<?= base_url( 'property/'. $property->pid .'/'. url_title(strtolower($property->title)) ); ?>"><i class="fa fa-map-marker"></i><?= ucwords($property->address); ?></a>
                            </h3>
                            <!-- Facilities List -->
                            <ul class="facilities-list clearfix">
                                <?php if(!empty($property->bedrooms)) : ?>
                                    <li>
                                        <i class="flaticon-bed"></i><?php echo $property->bedrooms; ?> Bedroom(s)
                                    </li>
                                <?php endif;?>
                                <?php if(!empty($property->bathrooms)) : ?>
                                    <li>
                                        <i class="flaticon-holidays"></i><?php echo $property->bathrooms; ?> Bathroom(s)
                                    </li>
                                <?php endif; ?>
                                <?php if(!empty($property->building_age)) : ?>
                                    <li>
                                        <i class="fa fa-check-square"></i><?php echo $property->building_age; ?> years(s)
                                    </li>
                                <?php endif; ?>
                            </ul>
                            <!-- Property footer -->
                            <div class="property-footer">
                                <span class="left"><i class="fa fa-calendar-o icon"></i>&nbsp;<?= ago($property->postdate); ?></span>
                                <?php
                                    $fav = ($this->property_model->is_favourited($this->session->userdata('user_id'), $property->id )) ? 'fa-heart' : 'fa-heart-o';
                                ?>
                                <span class="right">
                                    <?php
                                    // echo $property->id;                                                    
                                        if( $this->session->userdata('logged_in') ) {
                                            if($this->property_model->is_favourited($this->session->userdata('user_id'), $property->id ) ) { 
                                    ?>
                                                <a href="#" class="fav" data-action="unfavpost" data-pid="<?= $property->id; ?>"><i class="fa fa-heart"></i></a>
                                            <?php } else { ?>
                                                <a href="#" class="fav" data-action="favpost" data-pid="<?= $property->id; ?>"><i class="fa fa-heart-o"></i></a>
                                           <?php }
                                        }else{ ?>
                                            <a href="#" class="login"><i class="fa fa-heart-o"></i></a>
                                        <?php } 
                                    ?>
                                    <a href="#"><i class="fa fa-share-alt"></i></a>                                               
                                </span>
                            </div>
                        </div>
                    </div>
                    <!-- Property end -->
                    <?php endforeach;?>
                <?php else : ?>
                    <h2><strong>No result found for the query.</strong></h2>
                <?php endif; ?>
                <!-- Page navigation start -->
                <!-- <nav aria-label="Page navigation">
                    <ul class="pagination">
                        <li>
                            <a href="#" aria-label="Previous">
                                <span aria-hidden="true">Previous</span>
                            </a>
                        </li>
                        <li class="active"><a href="#">1 <span class="sr-only">(current)</span></a></li>
                        <li><a href="#">2</a></li>
                        <li>
                            <a href="#" aria-label="Next">
                                <span aria-hidden="true">Next</span>
                            </a>
                        </li>
                    </ul>
                </nav> -->

                <div class="clearfix"></div>
                    <div class="row">
                        <div class="col-md-12">
                            <!-- Pagination --> 
                            <div class="pagination-container margin-top-20 margin-bottom-40">                   
                                <?php echo $pagination ?> 
                            </div>
                        </div>
                    </div>
                <!-- Page navigation end-->
            </div>

            <!--Sidebar-->
            <?php $this->load->view('landing/includes/sidebar'); ?>
            <!--End of sidebar-->
        </div>
    </div>
</div>
<!-- Properties section body end -->


<!-- Testimonial section end -->
<div class="clearfix"></div>

<!-- Counters strat -->
<?php $this->load->view('landing/includes/counter'); ?>
<!-- Counters end -->

<!-- Partners block start -->
<?php $this->load->view('landing/includes/partners'); ?>
<!-- Partners block end -->
<!-- Footer start -->
<?php $this->load->view('landing/includes/footer'); ?>
<!-- Footer end -->
<!-- Copy right start -->
<div class="copy-right">
    <div class="container">
        <?= lang('footer_text'); ?>
    </div>
</div>
<!-- Copy end right-->

<script type="text/javascript" src="<?= base_url('assets/landing/js/jquery-2.2.0.min.js'); ?>"></script>
<script type="text/javascript" src="<?= base_url('assets/landing/js/bootstrap.min.js'); ?>"></script>
<script type="text/javascript" src="<?= base_url('assets/landing/js/bootstrap-submenu.js'); ?>"></script>
<script type="text/javascript" src="<?= base_url('assets/landing/js/rangeslider.js'); ?>"></script>
<script type="text/javascript" src="<?= base_url('assets/landing/js/jquery.mb.YTPlayer.js'); ?>"></script>
<script type="text/javascript" src="<?= base_url('assets/landing/js/wow.min.js'); ?>"></script>
<script type="text/javascript" src="<?= base_url('assets/landing/js/bootstrap-select.min.js'); ?>"></script>
<script type="text/javascript" src="<?= base_url('assets/landing/js/jquery.easing.1.3.js'); ?>"></script>
<script type="text/javascript" src="<?= base_url('assets/landing/js/jquery.scrollUp.js'); ?>"></script>
<script type="text/javascript" src="<?= base_url('assets/landing/js/jquery.mCustomScrollbar.concat.min.js'); ?>"></script>
<script type="text/javascript" src="<?= base_url('assets/landing/js/leaflet.js'); ?>"></script>
<script type="text/javascript" src="<?= base_url('assets/landing/js/leaflet-providers.js'); ?>"></script>
<script type="text/javascript" src="<?= base_url('assets/landing/js/leaflet.markercluster.js'); ?>"></script>
<script type="text/javascript" src="<?= base_url('assets/landing/js/dropzone.js'); ?>"></script>
<script type="text/javascript" src="<?= base_url('assets/landing/js/jquery.filterizr.js'); ?>"></script>
<script type="text/javascript" src="<?= base_url('assets/landing/js/maps.js'); ?>"></script>
<script type="text/javascript" src="<?= base_url('assets/landing/js/app.js'); ?>"></script>

<script>
$(document).ready(function() {
    $('.login').on('click', function(){
        swal({
            title: "Login",
            text: 'You need to login before favouriting',
            type: "info"
        }, function(isConfirm){
            window.location.href = "<?= base_url('login'); ?>";
        });
    });
    
    $('.fav').on('click', function(e) {
            e.preventDefault();
            thisClass = $(this);
            pid = $(this).attr('data-pid');
            action = $(this).attr('data-action');
            $.ajax({
                url: "<?php echo base_url('property/fav'); ?>",
                method: "POST",
                data: {pid:pid, action:action},
                success:function(data) {                    
                    if( data == true ){
                        if( action == 'favpost') {
                            thisClass.find("i").addClass('fa-heart');
                            thisClass.find("i").removeClass('fa-heart-o');
                            thisClass.attr('data-action', 'unfavpost');
                            swal({
                                title: "Success",
                                text: 'The property has been favourited, you can view it later on your dashboard',
                                type: "success"
                            });
                        }else {
                            thisClass.find("i").removeClass('fa-heart');
                            thisClass.find("i").addClass('fa-heart-o');
                            thisClass.attr('data-action', 'favpost');
                            swal({
                                title: "Success",
                                text: 'The property has been un-favourite.',
                                type: "info"
                            });
                        }
                    }else {
                        swal({
                            title: "Error",
                            text: 'Sorry there was an error performing that action, please try again, or refresh your browser.',
                            type: "error"
                        });
                    }
                }// success
            }); // ajax
    });
});
</script>
</body>

</html>