<?php $this->load->view('landing/includes/header'); ?>
<!-- Styles -->
</head>
<body>
<!-- Top header start -->
<?php $this->load->view('landing/includes/top_head'); ?>
<!-- Main header end -->

<!-- Sub banner start -->
<div class="sub-banner">
    <div class="overlay">
        <div class="container">
            <div class="breadcrumb-area">
                <h1>About Us</h1>
                <ul class="breadcrumbs">
                    <li><a href="index.php">Home</a></li>
                    <li class="active">About Us</li>
                </ul>
            </div>
        </div>
    </div>
</div>
<!-- Sub Banner end -->

<!-- About city estate start -->
<div class="about-city-estate">
    <div class="container">
        <div class="row">
            <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                <div class="car-detail-slider simple-slider">
                    <div id="carousel-custom" class="carousel slide" data-ride="carousel">
                        <div class="carousel-outer">
                            <!-- Wrapper for slides -->
                            <div class="carousel-inner">
                                <div class="item">
                                    <img src="img/properties/properties-1.jpg" class="img-preview img-responsive" alt="properties-1">
                                </div>
                                <div class="item">
                                    <img src="img/properties/properties-2.jpg" class="img-preview img-responsive" alt="properties-2">
                                </div>
                                <div class="item">
                                    <img src="img/properties/properties-5.jpg" class="img-preview img-responsive" alt="properties-3">
                                </div>
                                <div class="item active left">
                                    <img src="img/properties/properties-8.jpg" class="img-preview img-responsive" alt="properties-8">
                                </div>
                                <div class="item next left">
                                    <img src="img/properties/properties-3.jpg" class="img-preview img-responsive" alt="properties-5">
                                </div>
                            </div>
                            <!-- Controls -->
                            <a class="left carousel-control" href="#carousel-custom" role="button" data-slide="prev">
                                    <span class="slider-mover-left no-bg" aria-hidden="true">
                                        <i class="fa fa-angle-left"></i>
                                    </span>
                                <span class="sr-only">Previous</span>
                            </a>
                            <a class="right carousel-control" href="#carousel-custom" role="button" data-slide="next">
                                    <span class="slider-mover-right no-bg" aria-hidden="true">
                                        <i class="fa fa-angle-right"></i>
                                    </span>
                                <span class="sr-only">Next</span>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                <div class="about-text">
                    <div class="main-title-2">
                        <h1><span>About</span> myagent.ng </h1>
                    </div>
                    <h3>Hi, we're Myagent.ng, it's nice to meet you!</h3>
                    <p>As Nigeria’s premier property portal, we're passionate about helping people find their desired homes. In addition, we provide Nigeria’s Real Estate Industry with a reliable transactional and marketing platform where home owners/ agents connect with home-buyers and renters searching for property online.</p>
                    
                    <p>We pride ourselves on delivering excellent user friendly experience and innovative search tools. We go the extra mile to ensure your security and that of your fund by providing only screened and traceable agents. So if you have any feedback you'd like to give us, we'd love to hear from you. Please get in touch!</p>
                    <p>And if you're passionate about helping others to find their perfect homes through technology, why not join our dynamic team and work with us?</p>
                    
                    <h4>Property Management</h4>
                    
                    <p>Beyond the purchase, sale and rental of your property, we wish to also bear your burden in its management. We are experts in Marketing and Finance, Tenancy and Occupancy, Facility Maintenance, Administration and Risk aspect of Property Management.</p>
                    
                    <h4>Recover Asset Value</h4>
                    
                    <p>The value of your property need not go down due to age and usage. Let us help you do something about it.</p>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- About city estate end -->


<!-- Testimonial section end -->
<div class="clearfix"></div>

<!-- Counters strat -->
<?php $this->load->view('landing/includes/counter'); ?>
<!-- Counters end -->

<!-- Partners block start -->
<?php $this->load->view('landing/includes/partner'); ?>
<!-- Partners block end -->
<!-- Footer start -->
<?php $this->load->view('landing/includes/footer'); ?>
<!-- Footer end -->
<!-- Copy right start -->
<div class="copy-right">
    <div class="container">
        <?= lang('footer_text'); ?>
    </div>
</div>
<!-- Copy end right-->

<script type="text/javascript" src="<?= base_url('assets/landing/js/jquery-2.2.0.min.js'); ?>"></script>
<script type="text/javascript" src="<?= base_url('assets/landing/js/bootstrap.min.js'); ?>"></script>
<script type="text/javascript" src="<?= base_url('assets/landing/js/bootstrap-submenu.js'); ?>"></script>
<script type="text/javascript" src="<?= base_url('assets/landing/js/rangeslider.js'); ?>"></script>
<script type="text/javascript" src="<?= base_url('assets/landing/js/jquery.mb.YTPlayer.js'); ?>"></script>
<script type="text/javascript" src="<?= base_url('assets/landing/js/wow.min.js'); ?>"></script>
<script type="text/javascript" src="<?= base_url('assets/landing/js/bootstrap-select.min.js'); ?>"></script>
<script type="text/javascript" src="<?= base_url('assets/landing/js/jquery.easing.1.3.js'); ?>"></script>
<script type="text/javascript" src="<?= base_url('assets/landing/js/jquery.scrollUp.js'); ?>"></script>
<script type="text/javascript" src="<?= base_url('assets/landing/js/jquery.mCustomScrollbar.concat.min.js'); ?>"></script>
<script type="text/javascript" src="<?= base_url('assets/landing/js/leaflet.js'); ?>"></script>
<script type="text/javascript" src="<?= base_url('assets/landing/js/leaflet-providers.js'); ?>"></script>
<script type="text/javascript" src="<?= base_url('assets/landing/js/leaflet.markercluster.js'); ?>"></script>
<script type="text/javascript" src="<?= base_url('assets/landing/js/dropzone.js'); ?>"></script>
<script type="text/javascript" src="<?= base_url('assets/landing/js/jquery.filterizr.js'); ?>"></script>
<script type="text/javascript" src="<?= base_url('assets/landing/js/maps.js'); ?>"></script>
<script type="text/javascript" src="<?= base_url('assets/landing/js/app.js'); ?>"></script>

<!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
<script type="text/javascript" src="<?= base_url('js/ie10-viewport-bug-workaround.js'); ?>"></script>
</body>

</html>