<?php $this->load->view('landing/includes/header'); ?>
<!-- Styles -->
</head>
<body>
<!-- Top header start -->
<?php $this->load->view('landing/includes/top_head'); ?>

<!-- Submit Property start -->
<div class="content-area submit-property">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="notification-box">
                    <h3 class="text-center">Submit a Property Request</h3>
                </div>
            </div>
            <div class="col-md-12">
                <div class="submit-address">
                    <form>
                        <div class="main-title-2">
                            <h1><span>Basic</span> Information</h1>
                        </div>

                        <div class="search-contents-sidebar">
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Choose Property Category </label>
                                        <select class="selectpicker search-fields">
                                            <option>-- Choose Category --</option>
                                            <option>For Sale</option>
                                            <option>For Rent</option>
                                            <option>Short Let</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Location</label>
                                        <select class="selectpicker search-fields">
                                            <option>-- Choose Property Location --</option>
                                            <option>Abua / Odual L.G.A</option>
                                            <option>Ahoada East L.G.A</option>
                                            <option>Ahoada West L.G.A</option>
                                            <option>Akuku Toru L.G.A</option>
                                            <option>Andoni L.G.A</option>
                                            <option>Asari-Toru L.G.A</option>
                                            <option>Bonny L.G.A</option>
                                            <option>Degema L.G.A</option>
                                            <option>Emohua L.G.A</option>
                                            <option>Eleme L.G.A</option>
                                            <option>Etche L.G.A</option>
                                            <option>Gokona L.G.A</option>
                                            <option>Ikwerre L.G.A</option>
                                            <option>Khana L.G.A</option>
                                            <option>Obia / Akpor L.G.A</option>
                                            <option>Ogba / Egbema / Ndoni L.G.A</option>
                                            <option>Ogu / Bolo L.G.A</option>
                                            <option>Okrika L.G.A</option>
                                            <option>Omumma L.G.A</option>
                                            <option>Opobo / Nkoro L.G.A</option>
                                            <option>Oyigbo L.G.A</option>
                                            <option>Port-Harcourt L.G.A</option>
                                            <option>Tai L.G.A</option>
                                        </select>
                                    </div>
                                </div>
                            </div>
                           <div class="row">
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label>Your Budget</label>
                                        <input type="text" class="input-text" name="price" placeholder="Enter Your Maximum Budget">
                                    </div>
                                </div>
                                
                               <div class="col-md-4">
                                    <div class="form-group">
                                        <label>Tell us who you are</label>
                                        <select class="selectpicker search-fields">
                                            <option>-- Agent or Individual --</option>
                                            <option>Agent</option>
                                            <option>Individual</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label>How Many BedRoom(s)</label>
                                        <select class="selectpicker search-fields">
                                            <option>1</option>
                                            <option>2</option>
                                            <option>3</option>
                                            <option>4</option>
                                            <option>5</option>
                                            <option>6</option>
                                            <option>7</option>
                                            <option>8</option>
                                            <option>9</option>
                                            <option>10</option>
                                        </select>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        
                    
                        <!--Toggle Button-->
                        <div class="col-md-12">
                            <a href="#section1" class="btn button-md button-theme" id="continue">Continue</a>
                        </div>
                        <!--End of Toggle Button-->
                        
                        

                        <!--Hidden div -->
                        <div class="continue-1" name="section1">

                            <div class="main-title-2">
                                <h1><span>Contact</span> Details</h1>
                            </div>
                                <div class="row">
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label>Name</label>
                                            <input type="text" class="input-text" name="name" placeholder="Name">
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label>Email</label>
                                            <input type="email" class="input-text" name="email" placeholder="Email">
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label>Phone (optional)</label>
                                            <input type="text" class="input-text" name="phone"  placeholder="Phone">
                                        </div>
                                    </div>
                                    <!--Additional Information-->
                                    <div class="row">
                                        <div class="container">
                                            <div class="form-group">
                                                <label>Additional Information</label>
                                                <textarea class="input-text" name="message" placeholder="Detailed Information about your property"></textarea>
                                            </div>
                                        </div>
                                    </div>
                                    <!--Terms and Conditions-->
                                    <!--<div class="col-md-12">
                                        <div class="form-group">
                                            <label>
                                              <input type="checkbox"> I have read and agree to the <a href="terms.php">terms and conditions</a>
                                            </label>
                                        </div>
                                    </div>-->
                                    <div class="col-md-12">
                                        <a href="#" class="btn button-md button-theme">Submit Request</a>
                                    </div>
                                </div>
                            </div><!--End of Hidden div-->
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Submit Property end -->



<!-- Testimonial section end -->
<div class="clearfix"></div>

<!-- Counters strat -->
<?php $this->load->view('landing/includes/counter'); ?>
<!-- Counters end -->
<!-- Partners block start -->
<?php $this->load->view('landing/includes/partners'); ?>
<!-- Partners block end -->
<!-- Footer start -->
<?php $this->load->view('landing/includes/footer'); ?>
<!-- Footer end -->
<!-- Copy right start -->
<div class="copy-right">
    <div class="container">
        <?= lang('footer_text'); ?>
    </div>
</div>
<!-- Copy end right-->

<script type="text/javascript" src="<?= base_url('assets/landing/js/jquery-2.2.0.min.js'); ?>"></script>
<script type="text/javascript" src="<?= base_url('assets/landing/js/bootstrap.min.js'); ?>"></script>
<script type="text/javascript" src="<?= base_url('assets/landing/js/bootstrap-submenu.js'); ?>"></script>
<script type="text/javascript" src="<?= base_url('assets/landing/js/rangeslider.js'); ?>"></script>
<script type="text/javascript" src="<?= base_url('assets/landing/js/jquery.mb.YTPlayer.js'); ?>"></script>
<script type="text/javascript" src="<?= base_url('assets/landing/js/wow.min.js'); ?>"></script>
<script type="text/javascript" src="<?= base_url('assets/landing/js/bootstrap-select.min.js'); ?>"></script>
<script type="text/javascript" src="<?= base_url('assets/landing/js/jquery.easing.1.3.js'); ?>"></script>
<script type="text/javascript" src="<?= base_url('assets/landing/js/jquery.scrollUp.js'); ?>"></script>
<script type="text/javascript" src="<?= base_url('assets/landing/js/jquery.mCustomScrollbar.concat.min.js'); ?>"></script>
<script type="text/javascript" src="<?= base_url('assets/landing/js/leaflet.js'); ?>"></script>
<script type="text/javascript" src="<?= base_url('assets/landing/js/leaflet-providers.js'); ?>"></script>
<script type="text/javascript" src="<?= base_url('assets/landing/js/leaflet.markercluster.js'); ?>"></script>
<script type="text/javascript" src="<?= base_url('assets/landing/js/dropzone.js'); ?>"></script>
<script type="text/javascript" src="<?= base_url('assets/landing/js/jquery.filterizr.js'); ?>"></script>
<script type="text/javascript" src="<?= base_url('assets/landing/js/maps.js'); ?>"></script>
<script type="text/javascript" src="<?= base_url('assets/landing/js/app.js'); ?>"></script>

<!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
<script type="text/javascript" src="js/ie10-viewport-bug-workaround.js"></script>
    <script>
    $( "#continue" ).click(function() {
  $( ".continue-1" ).show( "fast", function() {
    $( "#continue" ).hide(function(){
    },
    );
  });
});
            $( "#continue2" ).click(function() {
  $( ".continue-2" ).show( "fast", function() {
    $( "#continue2" ).hide(function(){
    },
    );
  });
});
    </script>
</body>

</html>
