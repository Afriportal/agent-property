<!DOCTYPE html>
<html lang="en">

<head>
    <title>Terms and Conditions | Real Estate Agents and Property Managers</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta charset="utf-8">
    <meta name="description" content="PLEASE READ THESE TERMS AND CONDITIONS CAREFULLY AS THEY CONTAIN IMPORTANT INFORMATION ABOUT YOUR RIGHTS AND OBLIGATIONS WHEN USING OUR PLATFORM, MYAGENT.NG">
    <meta name="keywords" content="Real Estate, Real Estate agent, Property Managers in nigeria, Property Managers, Property, estate, nigeria, Business ">
    <meta name="author" content="MyAgent">

    <!-- External CSS libraries -->
    <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="css/animate.min.css">
    <link rel="stylesheet" type="text/css" href="css/bootstrap-submenu.css">
    <link rel="stylesheet" type="text/css" href="css/bootstrap-select.min.css">
    <link rel="stylesheet" href="css/leaflet.css" type="text/css">
    <link rel="stylesheet" href="css/map.css" type="text/css">
    <link rel="stylesheet" type="text/css" href="fonts/font-awesome/css/font-awesome.min.css">
    <link rel="stylesheet" type="text/css" href="fonts/flaticon/font/flaticon.css">
    <link rel="stylesheet" type="text/css" href="fonts/linearicons/style.css">
    <link rel="stylesheet" type="text/css"  href="css/jquery.mCustomScrollbar.css">
    <link rel="stylesheet" type="text/css"  href="css/dropzone.css">

    <!-- Custom stylesheet -->
    <link rel="stylesheet" type="text/css" href="css/style.css">
    <link rel="stylesheet" type="text/css" id="style_sheet" href="css/skins/default.css">

    <!-- Favicon icon -->
    <link rel="shortcut icon" href="img/favicon.ico" type="image/x-icon" >

    <!-- Google fonts -->
    <link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700,800%7CPlayfair+Display:400,700%7CRoboto:100,300,400,400i,500,700">

    <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
    <link rel="stylesheet" type="text/css" href="css/ie10-viewport-bug-workaround.css">

    <!-- Just for debugging purposes. Don't actually copy these 2 lines! -->
    <!--[if lt IE 9]><script type="text/javascript" src="js/ie8-responsive-file-warning.js"></script><![endif]-->
    <script type="text/javascript" src="js/ie-emulation-modes-warning.js"></script>

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
    <script type="text/javascript" src="js/html5shiv.min.js"></script>
    <script type="text/javascript" src="js/respond.min.js"></script>
    <![endif]-->
</head>
<body>


<!-- Top header start -->
<header class="top-header hidden-xs" id="top">
    <div class="container">
        <div class="row">
            <div class="col-xs-12 col-sm-6 col-md-6 col-lg-6">
                <div class="list-inline">
                    <a href="tel:+234-818-2206-898"><i class="fa fa-phone"></i>+234-818-2206-898</a>
                    <a href="tel:info@myagent.ng"><i class="fa fa-envelope"></i>info@myagent.ng</a>
                </div>
            </div>
            <div class="col-xs-12 col-sm-6 col-md-6 col-lg-6">
                <ul class="top-social-media pull-right">
                    <li>
                        <a href="login.php" class="sign-in"><i class="fa fa-sign-in"></i> Login</a>
                    </li>
                    <li>
                        <a href="signup.php" class="sign-in"><i class="fa fa-user"></i> Register</a>
                    </li>
                </ul>
            </div>
        </div>
    </div>
</header>
<!-- Top header end -->

<!-- Main header start -->
<header class="main-header">
    <div class="container">
        <nav class="navbar navbar-default">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#app-navigation" aria-expanded="false">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a href="index.php" class="logo">
                   <img src="img/logos/logo.png" style="width:130px; height:30px" alt="logo">
                </a>
            </div>
            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="navbar-collapse collapse" role="navigation" aria-expanded="true" id="app-navigation">
                <ul class="nav navbar-nav">
                    <li class="active">
                        <a href="index.php">
                            Home
                        </a>
                    </li>
                    <li>
                        <a  href="short_let.php">
                            Short Let
                        </a>
                    </li>
                    <li>
                        <a  href="for_rent.php">
                            For Rent
                        </a>
                    </li>
                   <li>
                        <a  href="for_sale_list.php">
                            For Sale
                        </a>
                    </li>
                   
                </ul>
                <ul class="nav navbar-nav navbar-right rightside-navbar">
                    <li>
                        <a href="property_request.php" class="button" style="margin-right:20px;">
                            Property Request
                        </a>
                    </li>
                    <li>
                        <a href="login.php" class="button">
                            Submit Property
                        </a>
                    </li>
                </ul>
            </div>

            <!-- /.navbar-collapse -->
            <!-- /.container -->
        </nav>
    </div>
</header>
<!-- Main header end -->

<!-- Sub banner start -->
<div class="sub-banner">
    <div class="overlay">
        <div class="container">
            <div class="breadcrumb-area">
                <h1>Terms and Conditions</h1>
                <ul class="breadcrumbs">
                    <li><a href="index.php">Home</a></li>
                    <li class="active">T &amp; C</li>
                </ul>
            </div>
        </div>
    </div>
</div>
<!-- Sub Banner end -->

<!-- About city estate start -->
<div class="about-city-estate">
    <div class="container">
        <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                <div class="about-text">
                    <div class="main-title-2">
                        <h3>Terms and conditions of usage of www.myagent.ng </h3>
                    </div>
                    <h5>PLEASE READ THESE TERMS AND CONDITIONS CAREFULLY AS THEY CONTAIN IMPORTANT INFORMATION ABOUT YOUR RIGHTS AND OBLIGATIONS WHEN USING OUR PLATFORM, MYAGENT.NG.</h5>
                    <p>As Nigeria’s premier property portal, we're passionate about helping people find their desired homes. In addition, we provide Nigeria’s Real Estate Industry with a reliable transactional and marketing platform where home owners/ agents connect with home-buyers and renters searching for property online.</p>
                    
                    <p>We pride ourselves on delivering excellent user friendly experience and innovative search tools. We go the extra mile to ensure your security and that of your fund by providing only screened and traceable agents. So if you have any feedback you'd like to give us, we'd love to hear from you. Please get in touch!</p>
                    <p>And if you're passionate about helping others to find their perfect homes through technology, why not join our dynamic team and work with us?</p>
                    
                    <h4>1. INTRODUCTION</h4>
                    
                    <p>1.1. "We" are platform providing company duly registered in Nigeria Limited (Reg. No.: RC1131100) and our address is 70 AdaGeorge Road, Port Harcourt, Rivers State, Nigeria. Our phone number is +2348182206898, 08150847913.</p>
                    <p>1.2. We provided this website platform for the convenience of buyers, Sellers, Investors, tenants, landlords and browsers interested in immovable properties, apartments and office spaces. We collect content in the form of advertisements from licensed estate firms, and verified private sellers, subscribing estate agents, letting agents, developers as well as related parties, to display on our platform for marketing. </p>
                    <p>1.3. These terms and conditions are deemed to include our privacy policy and are collectively known as "these Terms".</p>
                    <p>1.4. When you use this Site, you agree to be bound by these terms and conditions. If you do not agree to be bound by these Terms, you may not use this Site.</p>
                    <p>1.5. Certain uses of this Site are prohibited and amount to a misuse of our systems and the Site.</p>
                    <p>1.6. You may print and keep a copy of these Terms. They are a legal agreement between us and can only be modified with our consent. We may change these Terms at our discretion by changing them on the Site. The then current version of these Terms will apply whenever you use this Site.</p>
                    <p>1.7. By viewing any pages that constitute this Site, a person becomes a ‘user’ and agrees to the terms and conditions of use.</p>
                    
                    <h4>2. PRIVACY</h4>
                    
                    <p>2.1. All communications from us will provide a clear hyperlink where you can reverse your permission or deregister. If you have any problem with this process please call Admin: +2348182206898, 08150847913   for assistance.</p>
                    <p>2.2. We intend using any personal or organizational particulars you submit to us via email, telephone, or the submission forms on this site only to respond to any specific request for information you have made on the site, and, with the exception of possible communication and use of this information in terms of 2.3 and 2.4 below.</p>
                    <p>2.3. If we offer or supply a service to you that is provided on our behalf by a third party we may have to pass your Information to them in order to deliver the service. By using this site you consent to us providing your Information to the third parties licensed by us to provide such services. We may also use third parties to provide services on our behalf which may include processing (but not using themselves) your Information. In any case, we will not pass your data to anyone who is not also registered with the Data Protection Act or is not subject to these or similar provisions in our contract with them, and we will not allow the third party to use your Information commercially without your consent.</p>
                    <p>2.4. As a result of your electronic or other communication with us, we may use the medium to send electronic messages or other communications to update you on our other services that may be useful to you. We may also use this information to compile profiles for statistical purposes and use such profiles in the course of our business, but these profiles or statistical data will never be able to be linked to your specific profile and contact details by any third party.</p>
                    <p>2.5. Like many websites, we use "cookies" to enable us personalize your visits to this website, simplify the signing-in procedure, keep track of your preferences and to track the usage of this website. Cookies are small pieces of information that are stored in the hard drive of your computer by your browser. Your browser will have the option to prevent websites using cookies, but please note that this may reduce the functionality of this Site and other websites.</p>
                    
                    <h4>3. COPYRIGHT</h4>
                    
                    <p>3.1. All the content on this web site, including any and all graphics, text, icons, hyperlinks, private information, designs, trademarks, software, databases and agreements, is the intellectual property of Ritz Associates Limited and is protected by local and international law dealing with copyright and intellectual property rights. </p>
                    <p>3.2. Without limitation to clause   3.1, the device is our registered trademark You may not use or copy it without our prior written consent.</p>
                    <p>3.3. All rights to this content are reserved, and such content may not be reproduced without the express permission in writing from us. To obtain permission for the use of any content on this site, please contact Admin on +2348182206898. -  or email: myagentn@gmail.com. All rights not specifically granted in terms of these terms and conditions or by special permission are reserved.</p>
                    <p>3.4. No business, person or web site may frame this site or any of the pages on this site in any way whatsoever without the permission in writing from us.</p>
                    
                    <h4>4. HYPERLINKS</h4>
                    
                    <p>4.1. No person, business or web site may link to any page on this site without first requesting permission to do so from us in writing. Such permission can be obtained from the Admin as referred to in 3.2 above. </p>
                    <p>4.2. This Site contains links to websites operated by third parties. We have no control over their individual content. We therefore make no warranties or representations as to the accuracy or completeness of any of the information appearing in relation to any linked websites. The links are for your convenience only. We do not recommend any products or services advertised on those websites. If you decide to access any third party website linked from this Site, you do so at your own risk. </p>
                    <p>4.3. Most of the details of the properties available on this Site are provided to us by third parties, private sellers and our affiliated estate agents for your information only. We cannot verify these details and therefore make no warranties or representations as to their accuracy or completeness. If you rely on these details, you do so at your own risk. However, we have put some systems in place to check fraud by being involved in all transaction till it’s conclusion. Please ensure we are copied in all communication at all times. We remain committed to help to reduce financial fraud as we hope to deal with mainly licensed agent and property owners. We also follow through all transactions to its logical end. </p>
                    
                    <h4>5. BLACKLISTING</h4>
                    
                    <p>5.1. We reserve the right to blacklist any user(s) from this site and/or restrict or block their access or use of any and all elements of our services, on a permanent or temporary basis at our sole discretion. Any such user shall be notified and must not then attempt to use this Site under any other name or through any other user. </p>
                    
                    <h4>6. DISCLAIMER</h4>
                    
                    <p>6.1. We, the owners and  designers of this platform and any of the client's, agents or representatives shall not be liable for any damage, loss or liability however arising from the use or inability to use this web site or the services, content or information provided on and through this web site.</p>
                    <p>6.2. We make no express or implied representations or warranties that the content and service available from this platform are free from errors or omissions or that the service will be 100% uninterrupted and error free. Users are encouraged to report any possible malfunctions and errors to complaints@myagent.ng. We shall not be liable if we cannot process your details due to circumstances beyond our reasonable control.</p>
                    <p>6.3. This platform is available via the internet for any user with access, to view 'as it is', and has not been compiled or designed to meet each user's individual requirements. We will not be held responsible for any inconvenience, loss or damage that a user may suffer as a result of failure to meet such requirements. Users are encouraged to give any feedback or comments on the site to the person mentioned in clause 3.2 above.</p>
                   
                    <h4>7. SECURITY</h4>
                    
                    <p>7.1. Any person that delivers or attempts to deliver any damaging code to this web Site, to gain unauthorized access to any page on this web site, to tamper with any of the content or pages that constitute this web site or duplicate such pages or content shall be prosecuted to the full extent of the law, and civil damages shall be claimed in the event that we suffer any damage or loss as a result of such actions.</p>
                    <p>7.2. Whilst we endeavour to ensure that any material available for downloading from this Site is not contaminated in any way, we do not warrant that such material will be free from infection, viruses and/or similar code.</p>
                    
                     <h4>8. DISPUTES</h4>
                    
                    <p>8.1. All disputes in terms of this agreement or relating to the use or inability to use this web site shall be settled by arbitration conducted in English. Such arbitration shall be held in Rivers State, Nigeria and the unsuccessful party shall pay all costs incurred by the successful party in attending and preparing for such arbitration.</p>
                    
                    <h4>9. WHOLE AGREEMENT</h4>
                    
                    <p>9.1. This agreement constitutes the whole agreement between us and the user, and no terms and conditions that are not expressly stated in this agreement may be implied by either party.</p>
                    <p>9.2. We reserve the right to change this agreement or any part thereof at any time without notice, such changes being deemed to come into effect as soon as they are incorporated in this agreement and viewable on the site</p>
                    
                    <h3>BENEFITS AND CONDITIONS OF BEING AN AGENT ON myagent.ng</h3>
                    
                    <p>Myagent.ng shall offer its service of client generation by referring clients to you or your company on a regular basis. </p>
                    <p>Myagent.ng shall provide you or your company with a free listing platform where you can also build your property portfolio. </p>
                    <p>Upon your receiving a client’s request from Myagent.ng, You or your company must properly meet the client’s desired request and provide adequate customer service to the said client while servicing the request.</p>
                    <p>If on Partnership Payment Option, you or your company agrees to remit 2% of the value of transaction within 24 hours of receiving the payments from clients referred by Myagent.ng. You or your company also agrees to inform Myagent.ng on any diversion of leads to another agent as well as informing Myagent.ng when the client shows interest in payment.</p>
                    <p>Otherwise, use any of our alternative payment plans:</p>
                    <p>One-off payment plan - Under this plan, subscribing clients remit 5000 NGN on any property posted on Myagent.ng on a monthly basis.</p>
                    <p>Premium payment plan - Under this plan, subscribing clients remit 20,000 NGN for Premium Option as the case maybe for the duration of their listing. </p>
                    <p>Please note that the value of transaction is the amount paid for the property for sale or rent and not whatever commission you get. Please ensure you are the direct or principal agent before posting on myagent.ng.</p>
                    <p>Also note that violation of any of the conditions stated will attract punitive measures which may include an immediate termination of our contract with you as well as the immediate withdrawal of all your properties from the platform and your account will be BLACKLISTED.</p>
                    <p>Call +2348182206898, 08150847913. or send a mail to info@myagent.ng for further clarification. If you agree to the above stated terms, kindly click the <a href="contract_form.php">link to fill the contract form.</a></p>
                    
                    <h4>Great Classifieds</h4>
                    
                    <p>Looking to buy, sell or lease? We connect you with people and properties, so you can find the freshest listings and best deals in the market. Why? We believe that the search for your next property should be an awesome experience.</p>
                    
                     <h4>Advertise</h4>
                    
                    <p>With high volumes of serious buyers and renters browsing our site, myagent.ng offers the ideal platform for you to list your property, whether as a licensed estate firm, private seller or as an agent.</p>
                    
                    <h4>Find Your Next Home</h4>
                    
                    <p>We put a lot of effort into making the search for your next home effortless and rewarding. From offering clearly displayed quality listings, to providing simple mechanisms for contacting the seller or agent, we aim to help you find the best property for your needs</p>
                    
                    
                </div>
            </div>
        </div>
    </div>
</div>
<!-- About city estate end -->


<!-- Testimonial section end -->
<div class="clearfix"></div>

<!-- Counters strat -->
<div class="counters">
    <div class="container">
        <div class="row">
            <div class="col-md-3 col-sm-6 bordered-right">
                <div class="counter-box">
                    <i class="flaticon-tag"></i>
                    <h1 class="counter">967</h1>
                    <p>Listings For Sale</p>
                </div>
            </div>
            <div class="col-md-3 col-sm-6 bordered-right">
                <div class="counter-box">
                    <i class="flaticon-symbol-1"></i>
                    <h1 class="counter">1276</h1>
                    <p>Listings For Rent</p>
                </div>
            </div>
            <div class="col-md-3 col-sm-6 bordered-right">
                <div class="counter-box">
                    <i class="flaticon-people"></i>
                    <h1 class="counter">396</h1>
                    <p>Agents</p>
                </div>
            </div>
            <div class="col-md-3 col-sm-6">
                <div class="counter-box">
                    <i class="flaticon-people-1"></i>
                    <h1 class="counter">177</h1>
                    <p>House Owners</p>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Counters end -->

<!-- Partners block start -->
<div class="partners-block">
    <div class="container">
        <h3>Brands & Partners</h3>
        <div class="row">
            <div class="col-md-12">
                <div class="carousel our-partners slide" id="ourPartners">
                    <div class="carousel-inner">
                        <div class="item active">
                            <div class="col-xs-12 col-sm-6 col-md-3">
                                <a href="#">
                                    <img src="img/brand/afri1.png" alt="">
                                </a>
                            </div>
                        </div>
                        <div class="item">
                            <div class="col-xs-12 col-sm-6 col-md-3">
                                <a href="#">
                                    <img src="img/brand/afri1.png" alt="">
                                </a>
                            </div>
                        </div>
                        <div class="item">
                            <div class="col-xs-12 col-sm-6 col-md-3">
                                <a href="#">
                                    <img src="img/brand/tuts.png" alt="">
                                </a>
                            </div>
                        </div>
                        <div class="item">
                            <div class="col-xs-12 col-sm-6 col-md-3">
                                <a href="#">
                                    <img src="img/brand/afri1.png" alt="">
                                </a>
                            </div>
                        </div>
                        <div class="item">
                            <div class="col-xs-12 col-sm-6 col-md-3">
                                <a href="#">
                                    <img src="img/brand/afri1.png" alt="">
                                </a>
                            </div>
                        </div>
                    </div>
                    <a class="left carousel-control" href="#ourPartners" data-slide="prev"><i class="fa fa-chevron-left icon-prev"></i></a>
                    <a class="right carousel-control" href="#ourPartners" data-slide="next"><i class="fa fa-chevron-right icon-next"></i></a>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Partners block end -->

<!-- Footer start -->
<footer class="main-footer clearfix">
    <div class="container">
        <!-- Footer top -->
        <div class="footer-top">
            <div class="row">
                <div class="col-lg-5 col-md-4 col-sm-3 col-xs-12">
                    <div class="logo-2">
                        <a href="index.html">
                            <img src="img/logos/logo.png" alt="footer-logo">
                        </a>
                    </div>
                </div>
                <div class="col-lg-4  col-md-4 col-sm-5 col-xs-12">
                    <form action="#" method="post">
                        <input type="text" class="form-contact" name="email" placeholder="Enter your email">
                        <button type="submit" name="submitNewsletter" class="btn btn-default button-small">
                            <i class="fa fa-paper-plane"></i>
                        </button>
                    </form>
                </div>
                <div class="col-lg-3 col-md-4 col-sm-4 col-xs-12">
                    <ul class="social-list clearfix">
                        <li><a href="#"><i class="fa fa-google-plus"></i></a></li>
                        <li><a href="#"><i class="fa fa-linkedin"></i></a></li>
                        <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                        <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                    </ul>
                </div>
            </div>
        </div>
        <!-- Footer info-->
        <div class="footer-info">
            <div class="row">
                <!-- About us -->
                <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
                    <div class="footer-item">
                        <div class="main-title-2">
                            <h1>Contact Us</h1>
                        </div>
                        <p>
                           We are the foremost real estate agency in the city of Rivers State, Nigeria.
                        </p>
                        <ul class="personal-info">
                            <li>
                                <i class="fa fa-map-marker"></i>
                                Address: 70 AdaGeorge Road, Port Harcourt, Rivers State.
                            </li>
                            <li>
                                <i class="fa fa-envelope"></i>
                                Email:<a href="mailto:sales@myagent.ng">info@myagent.ng</a>, <a href="mailto:sales@myagent.ng">complaints@myagent.ng</a>
                                
                            </li>
                            <li>
                                <i class="fa fa-phone"></i>
                                Phone: <a href="tel:+234 803-634-7071">+234-818-2206-898</a>
                            </li>
                            <li>
                                <i class="fa fa-phone-square"></i>
                                Mobile: <a href="tel:+234 803-634-7071">081-5084-7913 </a>
                            </li>
                        </ul>
                    </div>
                </div>
                <!-- Links -->
                <div class="col-lg-2 col-md-2 col-sm-6 col-xs-12">
                    <div class="footer-item">
                        <div class="main-title-2">
                            <h1>Links</h1>
                        </div>
                        <ul class="links">
                            <li>
                                <a href="index.php">Home</a>
                            </li>
                            <li>
                                <a href="about.php">About Us</a>
                            </li>
                            <li>
                                <a href="contact.php">Contact Us</a>
                            </li>
                            <li>
                                <a href="property_request.php">Property Request</a>
                            </li>
                        </ul>
                    </div>
                </div>
                <!-- Tags -->
                <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
                    <div class="footer-item tags-box">
                        <div class="main-title-2">
                            <h1>Tags</h1>
                        </div>
                        <ul class="tags">
                           <li><a href="#">Real Estate</a></li>
                            <li><a href="#">Property</a></li>
                            <li><a href="#">Rent</a></li>
                            <li><a href="#">Sale</a></li>
                            <li><a href="#">Land</a></li>
                            <li><a href="#">Building</a></li>
                            <li><a href="#">Flat</a></li>
                            <li><a href="#">Hall</a></li>
                            <li><a href="#">Bungalow</a></li>
                        </ul>
                    </div>
                </div>
                <!-- Recent cars -->
                <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
                    <div class="footer-item popular-posts">
                        <div class="main-title-2">
                            <h1>About Us</h1>
                        </div>
                        <p>
                           As Nigeria’s premier property portal, we're passionate about helping people find their desired homes. In addition, we provide Nigeria’s Real Estate Industry with a reliable transactional and marketing platform where home owners/ agents connect with home-buyers and renters searching for property online.
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</footer>
<!-- Footer end -->

<!-- Copy right start -->
<div class="copy-right">
    <div class="container">
        &copy;  2017 <a href="http://myagent.ng/" target="_blank">myAgent.ng</a> | Trademarks and brands are the property of their respective owners.
    </div>
</div>
<!-- Copy end right-->

<script type="text/javascript" src="js/jquery-2.2.0.min.js"></script>
<script type="text/javascript" src="js/bootstrap.min.js"></script>
<script type="text/javascript" src="js/bootstrap-submenu.js"></script>
<script type="text/javascript" src="js/rangeslider.js"></script>
<script type="text/javascript" src="js/jquery.mb.YTPlayer.js"></script>
<script type="text/javascript" src="js/wow.min.js"></script>
<script type="text/javascript" src="js/bootstrap-select.min.js"></script>
<script type="text/javascript" src="js/jquery.easing.1.3.js"></script>
<script type="text/javascript" src="js/jquery.scrollUp.js"></script>
<script type="text/javascript" src="js/jquery.mCustomScrollbar.concat.min.js"></script>
<script type="text/javascript" src="js/leaflet.js"></script>
<script type="text/javascript" src="js/leaflet-providers.js"></script>
<script type="text/javascript" src="js/leaflet.markercluster.js"></script>
<script type="text/javascript" src="js/dropzone.js"></script>
<script type="text/javascript" src="js/jquery.filterizr.js"></script>
<script type="text/javascript" src="js/maps.js"></script>
<script type="text/javascript" src="js/app.js"></script>

<!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
<script type="text/javascript" src="js/ie10-viewport-bug-workaround.js"></script>
<!-- Custom javascript -->
<script type="text/javascript" src="js/ie10-viewport-bug-workaround.js"></script>
</body>

</html>