<header class="top-header hidden-xs" id="top">
    <div class="container">
        <div class="row">
            <div class="col-xs-12 col-sm-6 col-md-6 col-lg-6">
                <div class="list-inline">
                    <a href="tel:+<?= lang('phone1'); ?>"><i class="fa fa-phone"></i>+<?= lang('phone1'); ?></a>
                    <a href="mailto:<?= lang('site_mail'); ?>"><i class="fa fa-envelope"></i><?= lang('site_mail');?></a>
                </div>
            </div>
            <div class="col-xs-12 col-sm-6 col-md-6 col-lg-6">
                <ul class="top-social-media pull-right">
                    <?php if($this->session->userdata('logged_in')) : ?>
                        <li><a href="<?= $profile->user_type == 'admin' ? base_url('admin') : base_url($profile->user_type); ?>" class="sign-in"><i class="fa fa-user">&nbsp;</i>Hello <?= empty($profile->name) ? ucwords($profile->email) : ucfirst($profile->name); ?></a></li>
                    <?php else : ?>
                    <li>
                        <a href="<?= base_url('login'); ?>" class="sign-in"><i class="fa fa-sign-in"></i> Login</a>
                    </li>
                    <li>
                        <a href="<?= base_url('register'); ?>" class="sign-in"><i class="fa fa-user"></i> Register</a>
                    </li>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
    </div>
</header>
<!-- Top header end -->

<!-- Main header start -->
<header class="main-header">
    <div class="container">
        <nav class="navbar navbar-default">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#app-navigation" aria-expanded="false">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a href="index.php" class="logo">
                   <img src="<?= base_url('assets/landing/img/logos/logo.png')?>" style="width:130px; height:30px" alt="logo">
                </a>
            </div>
            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="navbar-collapse collapse" role="navigation" aria-expanded="true" id="app-navigation">
                <ul class="nav navbar-nav">
                    <li <?php if($pg_name =='home') echo 'class="active"'?> >
                        <a href="<?= base_url(); ?>">
                            Home
                        </a>
                    </li>
                    <li <?php if($pg_name =='short_let') echo 'class="active"'?>>
                        <a  href="<?= base_url('short_let'); ?>">
                            Short Let
                        </a>
                    </li>
                    <li <?php if($pg_name =='for_rent') echo 'class="active"'?>>
                        <a  href="<?= base_url('for_rent'); ?>">
                            For Rent
                        </a>
                    </li>
                   <li <?php if($pg_name =='for_sale') echo 'class="active"'?>>
                        <a  href="<?= base_url('for_sale'); ?>">
                            For Sale
                        </a>
                    </li>
                   
                </ul>
                <ul class="nav navbar-nav navbar-right rightside-navbar">
                    <li>
                        <a href="<?= base_url('request'); ?>" class="button" style="margin-right:20px;">
                            Property Request
                        </a>
                    </li>
                    <li>
                        <a href="<?= base_url('create'); ?>" class="button">
                            Submit Property
                        </a>
                    </li>
                </ul>
            </div>
        </nav>
    </div>
</header>