<!DOCTYPE html>
<html lang="en">
<head>
    <title>Welcome to MyAgent.ng | Real Estate Agents and Property Managers</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta charset="utf-8">
    <meta name="description" content="We are a Real Estate Agents and Property Managers in Nigeria, with a strong base in the city of Port Harcourt">
    <meta name="keywords" content="<?= lang('site_keywords'); ?>">
    <meta name="author" content="MyAgent">

    <!-- External CSS libraries -->
    <link rel="stylesheet" type="text/css" href="<?= base_url('assets/landing/css/bootstrap.min.css'); ?>">
    <link rel="stylesheet" type="text/css" href="<?= base_url('assets/landing/css/animate.min.css'); ?>">
    <link rel="stylesheet" type="text/css" href="<?= base_url('assets/landing/css/bootstrap-submenu.css');?>">
    <link rel="stylesheet" type="text/css" href="<?= base_url('assets/landing/css/bootstrap-select.min.css');?>">
    <link rel="stylesheet" href="<?= base_url('assets/landing/css/leaflet.css');?>" type="text/css">
    <link rel="stylesheet" href="<?= base_url('assets/landing/css/map.css'); ?>" type="text/css">
    <link rel="stylesheet" type="text/css" href="<?= base_url('assets/landing/fonts/font-awesome/css/font-awesome.min.css'); ?>">
    <link rel="stylesheet" type="text/css" href="<?= base_url('assets/landing/fonts/flaticon/font/flaticon.css'); ?>">
    <link rel="stylesheet" type="text/css" href="<?= base_url('assets/landing/fonts/linearicons/style.css'); ?>">
    <link rel="stylesheet" type="text/css"  href="<?= base_url('assets/landing/css/jquery.mCustomScrollbar.css');?>">
    <link rel="stylesheet" type="text/css"  href="<?= base_url('assets/landing/css/dropzone.css'); ?>">

    <!-- Custom stylesheet -->
    <link rel="stylesheet" type="text/css" href="<?= base_url('assets/landing/css/style.css');?>">
    <link rel="stylesheet" type="text/css" href="<?= base_url('assets/landing/css/skins/default.css'); ?>">

    <!-- Favicon icon -->
    <link rel="shortcut icon" href="<?= base_url('assets/landing/img/favicon.ico') ?>" type="image/x-icon" >

    <!-- Google fonts -->
    <link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700,800%7CPlayfair+Display:400,700%7CRoboto:100,300,400,400i,500,700">

    <link href="<?= base_url(); ?>assets/app/plugins/sweetalert/sweetalert.css" rel="stylesheet" type="text/css">
    <script src="<?= base_url()?>assets/app/plugins/sweetalert/sweetalert.min.js"></script>
    <script src="<?= base_url()?>assets/app/plugins/sweetalert/jquery.sweet-alert.custom.js"></script>

    <!-- Just for debugging purposes. Don't actually copy these 2 lines! -->
    <!--[if lt IE 9]><script type="text/javascript" src="js/ie8-responsive-file-warning.js"></script><![endif]-->
    <!-- <script type="text/javascript" src="js/ie-emulation-modes-warning.js"></script> -->

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
    <script type="text/javascript" src="js/html5shiv.min.js"></script>
    <script type="text/javascript" src="js/respond.min.js"></script>
    <![endif]-->