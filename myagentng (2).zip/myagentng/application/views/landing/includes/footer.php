<footer class="main-footer clearfix">
    <div class="container">
        <!-- Footer top -->
        <div class="footer-top">
            <div class="row">
                <div class="col-lg-5 col-md-4 col-sm-3 col-xs-12">
                    <div class="logo-2">
                        <a href="index.html">
                            <img src="img/logos/logo.png" alt="footer-logo">
                        </a>
                    </div>
                </div>
                <div class="col-lg-4  col-md-4 col-sm-5 col-xs-12">
                    <form action="#" method="post">
                        <input type="text" class="form-contact" name="email" placeholder="Enter your email">
                        <button type="submit" name="submitNewsletter" class="btn btn-default button-small">
                            <i class="fa fa-paper-plane"></i>
                        </button>
                    </form>
                </div>
                <div class="col-lg-3 col-md-4 col-sm-4 col-xs-12">
                    <ul class="social-list clearfix">
                        <li><a href="#"><i class="fa fa-google-plus"></i></a></li>
                        <li><a href="#"><i class="fa fa-linkedin"></i></a></li>
                        <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                        <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                    </ul>
                </div>
            </div>
        </div>
        <!-- Footer info-->
        <div class="footer-info">
            <div class="row">
                <!-- About us -->
                <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
                    <div class="footer-item">
                        <div class="main-title-2">
                            <h1>Contact Us</h1>
                        </div>
                        <p>
                           We are the foremost real estate agency in the city of Rivers State, Nigeria.
                        </p>
                        <ul class="personal-info">
                            <li>
                                <i class="fa fa-map-marker"></i>
                                <?= lang('contact_address'); ?>
                            </li>
                            <li>
                                <i class="fa fa-envelope"></i>
                                Email:<a href="mailto:<?= lang('site_mail'); ?>"><?= lang('site_mail'); ?></a>, <a href="mailto:<?= lang('contact_mail');?>"><?= lang('contact_mail');?></a>
                                
                            </li>
                            <li>
                                <i class="fa fa-phone"></i>
                                Phone: <a href="tel:+<?= lang('phone1'); ?>">+<?= lang('phone1'); ?></a>
                            </li>
                            <li>
                                <i class="fa fa-phone-square"></i>
                                Mobile: <a href="tel:+<?= lang('phone2'); ?>"><?= lang('phone2'); ?></a>
                            </li>
                        </ul>
                    </div>
                </div>
                <!-- Links -->
                <div class="col-lg-2 col-md-2 col-sm-6 col-xs-12">
                    <div class="footer-item">
                        <div class="main-title-2">
                            <h1>Links</h1>
                        </div>
                        <ul class="links">
                            <li>
                                <a href="<?= base_url();?>">Home</a>
                            </li>
                            <li>
                                <a href="<?= base_url('about'); ?>">About Us</a>
                            </li>
                            <li>
                                <a href="<?= base_url('contact'); ?>">Contact Us</a>
                            </li>
                            <li>
                                <a href="<?= base_url('request'); ?>">Property Request</a>
                            </li>
                        </ul>
                    </div>
                </div>
                <!-- Tags -->
                <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
                    <div class="footer-item tags-box">
                        <div class="main-title-2">
                            <h1>Tags</h1>
                        </div>
                        <ul class="tags">
                            <?php
                                // $sql = "SELECT `property_type` FROM `property` GROUP BY `property_type`";
                                // $tags = $this->db->query($sql)->result_array("");
                                $tags = $this->property_model->run_sql("SELECT `type_of_property` FROM `property` GROUP BY `type_of_property`");
                                foreach( $tags as $tag ) :
                            ?>
                               <li><?php echo anchor('search/?type_of_property='.$tag['type_of_property'], ucwords($tag['type_of_property'])); ?></li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                </div>
                <!-- Recent cars -->
                <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
                    <div class="footer-item popular-posts">
                        <div class="main-title-2">
                            <h1>About Us</h1>
                        </div>
                        <p>
                           <?= lang('about_us'); ?>
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</footer>