<div class="col-lg-4 col-md-4 col-xs-12">
                <!-- Search contents sidebar start -->
                <div class="sidebar-widget">
                    <div class="main-title-2">
                        <h1><span>Search</span></h1>
                    </div>
                    <form method="GET" action="<?= base_url('search'); ?>">
                        <div class="form-group">
                            <select name="lga" class="selectpicker search-fields" data-live-search="true" data-live-search-placeholder="Search value">
                                <option value="">--Choose Location--</option>
                                <?php $types = explode(',', lang('lga')); 
                                    foreach( $types as $type ):
                                ?>
                                <option value="<?= trim($type); ?>"><?= ucwords(trim($type)); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <select name="property_type" required class="selectpicker search-fields" data-live-search="true" data-live-search-placeholder="Search value" >
                                <option value="">-- Type of Property --</option>
                                <option value="">-- Select Property Status --</option>
                                <option value="for sale">For Sale</option>
                                <option value="for rent">For Rent</option>
                                <option value="short let">Short Let</option>
                            </select>
                        </div>

                        <div class="form-group">
                            <select name="type_of_property" class="selectpicker search-fields" data-live-search="true" data-live-search-placeholder="Search value" >
                                <option value="">-- Kind of Property --</option>
                                <?php $types = explode(',', lang('type_of_property')); 
                                    foreach( $types as $type ):
                                ?>
                                <option value="<?= trim($type); ?>"><?= ucwords(trim($type)); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>

                        <div class="range-slider">
                            <label>Price</label>
                            <div data-min="0" data-max="100000000" data-unit="NGN" class="range-slider-ui ui-slider" aria-disabled="false"></div>
                            <div class="clearfix"></div>
                        </div>

                        <div class="form-group">
                            <button type="submit" class="search-button">Search</button>
                        </div>
                    </form>
                </div>
                <!-- Search contents sidebar end -->

                <!-- Popular posts start -->
                <div class="sidebar-widget popular-posts">
                    <div class="main-title-2">
                        <h1><span>Recent</span> Properties</h1>
                    </div>
                    <?php
                        foreach( $recents as $recent ) :
                            // fetch image
                            $property_image = $this->property_model->fetch_featured_image( $recent->pid );
                            $src = !empty($property_image) ? base_url('assets/app/images/thumbnail/').$property_image->img_name : base_url('assets/app/images/thumbnail/myagentng_thumbnail.jpg'); 
                    ?>
                    <div class="media">
                        <div class="media-left">
                            <img class="media-object" src="<?= $src; ?>" alt="small-properties-1">
                        </div>
                        <div class="media-body">
                            <h3 class="media-heading">
                                <a href="<?= base_url( 'property/'. $recent->pid .'/'. url_title(strtolower($recent->title)) ); ?>"><?= word_limiter(ucwords($recent->title), 10, '...'); ?></a>
                            </h3>
                            <p>Posted on: <span><?= date('dS F, Y',strtotime($recent->postdate)); ?></span></p>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
                <!-- Popular posts end -->

                <!-- Helping box Start -->
                <div class="sidebar-widget helping-box clearfix">
                    <div class="main-title-2">
                        <h1><span>Help</span> Center</h1>


                    </div>
                    <div class="helping-center">
                        <div class="icon"><i class="fa fa-map-marker"></i></div>
                        <h4>Address</h4>
                        <span>Somewhere around Ada George, Portharcourt, Rivers State.</span>
                    </div>
                    <div class="helping-center">
                        <div class="icon"><i class="fa fa-phone"></i></div>
                        <h4>Phone</h4>
                        <p><a href="tel:+234 803-634-7071">+234 803-634-7071</a> </p>
                    </div>
                </div>
                <!-- Helping box end -->
            </div>