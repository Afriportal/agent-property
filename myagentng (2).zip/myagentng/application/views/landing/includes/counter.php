<div class="counters">
    <div class="container">
        <div class="row">
            <div class="col-md-3 col-sm-6 bordered-right">
                <div class="counter-box">
                    <i class="flaticon-tag"></i>
                    <h1 class="counter"><?= $this->property_model->fetch_num_rows('property', array('property_type' => 'for sale')); ?></h1>
                    <p>Listings For Sale</p>
                </div>
            </div>
            <div class="col-md-3 col-sm-6 bordered-right">
                <div class="counter-box">
                    <i class="flaticon-symbol-1"></i>
                    <h1 class="counter"><?= $this->property_model->fetch_num_rows('property', array('property_type' => 'for rent')); ?></h1>
                    <p>Listings For Rent</p>
                </div>
            </div>
            <div class="col-md-3 col-sm-6 bordered-right">
                <div class="counter-box">
                    <i class="flaticon-people"></i>
                    <h1 class="counter"><?= $this->user_model->get_users_count(array('user_type' => 'agents')); ?></h1>
                    <p>Agents</p>
                </div>
            </div>
            <div class="col-md-3 col-sm-6">
                <div class="counter-box">
                    <i class="flaticon-people-1"></i>
                    <h1 class="counter"><?= $this->user_model->get_users_count(array('user_type' => 'owners')); ?></h1>
                    <p>House Owners</p>
                </div>
            </div>
        </div>
    </div>
</div>