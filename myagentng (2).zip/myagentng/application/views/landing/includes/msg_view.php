<?php if($this->session->flashdata('success_msg')): ?>
<div style="background-color: #84ad1d; color: #fff; border: 2px solid #84ad1d;" class="notification success closeable">
	<p><?php echo $this->session->flashdata('success_msg'); unset($_SESSION['success_msg']);?></p>
	<a class="close"></a>
</div>
<?php endif; ?>
    
<?php if($this->session->flashdata('error_msg')): ?>
<div style="background-color: #c4761f; color: #fff; border: 2px solid #c4761f;" class="notification error closeable">
	<p><?php echo $this->session->flashdata('error_msg'); unset($_SESSION['error_msg']); ?></p>
	<a class="close"></a>
	<br />
</div>
<?php endif; ?>