<?php $this->load->view('landing/includes/header'); ?>
</head>
<body>
<!-- Top header start -->
<?php $this->load->view('landing/includes/top_head'); ?>
<!-- Main header end -->

<!-- Sub banner start -->
<div class="sub-banner2">
    <div class="overlay">
        <div class="container">
            <div class="breadcrumb-area">
                <h1>Property Details</h1>
                <ul class="breadcrumbs">
                    <li><a href="<?= base_url(); ?>">Home</a></li>
                    <li class="active"><a href="#"><?= $property['title']; ?></a></li>
                </ul>
            </div>
        </div>
    </div>
</div>
<!-- Sub Banner end -->
<!-- Properties details page start -->
<div class="content-area  properties-details-page">
    <div class="container">
        <div class="row">
            <div class="col-lg-8 col-md-8 col-sm-12 col-xs-12">
                    <!-- Header -->
                    <?php if( $property['status'] == 'suspended' ) : ?>
                        <h1 class="text-center">Sorry, this property has been suspended.</h1>
                    <?php else :?>
                        <div class="heading-properties clearfix sidebar-widget">
                            <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                                <div class="pull-left">
                                    <h3><?= ucwords($property['title']); ?></h3>
                                    <p>
                                        <i class="fa fa-map-marker"></i> <?= ucwords($property['address']); ?>
                                    </p>
                                    <span class="label label-info">Views: <?= $property['views']; ?> </span>
                                </div>
                            </div>
                            <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                                <div class="pull-right">
                                    <h3><span><?= ngn($property['price']); ?></span></h3>
                                    <h5>
                                        <?= $property['payment_schedule']; ?>
                                    </h5>
                                </div>
                            </div>
                        </div>
                    
                    <!-- Properties details section start -->
                    <div class="Properties-details-section sidebar-widget">                        
                        <!-- Properties detail slider start -->
                        <div class="properties-detail-slider simple-slider mrg-btm-40 ">
                            
                            <div id="property_carousel" class="carousel slide" data-ride="carousel">
                                <div class="carousel-outer">
                                    <!-- Property Images -->
                                    <?php $slides = $this->property_model->fetch_images($property['pid'])->result_array(); ?>
                                    <div class="carousel-inner">
                                        <?php 
                                            if( !empty($slides) ) :
                                                $x = 1;
                                                foreach( $slides as $slide ) :
                                        ?>
                                                    <div class="item <?php if($x == 1) echo 'active'?>">
                                                        <img src="<?php echo base_url('assets/app/images/'. $slide['img_name']) ?>" class="thumb-preview" class="img" alt="<?php echo $property['title']; ?>">
                                                    </div>
                                        <?php 
                                                    $x++; 
                                                endforeach;
                                            else :
                                        ?>
                                                    <div class="item active">
                                                        <img src="<?php echo base_url('assets/app/images/myagentng.jpg') ?>" class="thumb-preview" class="img" alt="<?php echo $property['title']; ?>">
                                                    </div>
                                        <?php endif; ?>                                        
                                    </div>
                                    <?php if(!empty($slides)): ?>
                                        <!-- Controls -->
                                        <a class="left carousel-control" href="#property_carousel" role="button" data-slide="prev">
                                            <span class="slider-mover-left no-bg" aria-hidden="true">
                                                <i class="fa fa-angle-left"></i>
                                            </span>
                                            <span class="sr-only">Previous</span>
                                        </a>
                                        <a class="right carousel-control" href="#property_carousel" role="button" data-slide="next">
                                            <span class="slider-mover-right no-bg" aria-hidden="true">
                                                <i class="fa fa-angle-right"></i>
                                            </span>
                                            <span class="sr-only">Next</span>
                                        </a>
                                    <?php endif; ?>
                                </div>
                                <!-- Indicators -->
                                <?php if(!empty($slides)) :?>
                                    <ol class="carousel-indicators thumbs visible-lg visible-md">
                                        <?php $x = 0; foreach( $slides as $slide ) :?>
                                            <li data-target="#property_carousel" data-slide-to="<?php echo $x ;?>" class=""><img src="<?php echo base_url('assets/app/images/thumbnail/'. $slide['img_name']) ?>" alt="myagent.ng property listing <?php echo $property['title']; ?>"></li>
                                        <?php $x++; endforeach; ?>
                                    </ol>
                                <?php endif; ?>


                            </div>
                        </div>
                        <!-- Properties detail slider end -->
                
                        <!-- Property description start -->
                        <div class="panel-box properties-panel-box Property-description">
                            <ul class="nav nav-tabs">
                                <li class="active"><a href="#description" data-toggle="tab" aria-expanded="true">Description</a></li>
                                <li class=""><a href="#condition" data-toggle="tab" aria-expanded="false">Condition</a></li>
                            </ul>
                            <div class="panel with-nav-tabs panel-default">
                                <div class="panel-body">
                                    <div class="tab-content">
                                        <div class="tab-pane fade active in" id="description">
                                            <div class="main-title-2">
                                                <h1><span>Description</span></h1>
                                            </div>
                                            <p><?= $property['description']; ?></p>
                                        </div>
                                        <div class="tab-pane fade features" id="condition">
                                            <!-- Properties condition start -->
                                            <div class="properties-condition">
                                                <div class="main-title-2">
                                                    <h1><span>Condition</span></h1>
                                                </div>
                                                <div class="row">
                                                    <?php if(!empty($property['bedrooms'])) : ?>
                                                        <div class="col-md-4 col-sm-4 col-xs-12">
                                                            <ul class="condition">
                                                                <li>
                                                                    <i class="fa fa-check-square"></i><?php echo $property['bedrooms']; ?> Bedroom(s)
                                                                </li>
                                                            </ul>
                                                        </div>
                                                    <?php endif;?>
                                                    <?php if(!empty($property['bathrooms'])) : ?>
                                                    <div class="col-md-4 col-sm-4 col-xs-12">
                                                        <ul class="condition">                                                        
                                                            <li>
                                                                <i class="fa fa-check-square"></i><?php echo $property['bathrooms']; ?> Bathroom(s)
                                                            </li>
                                                        </ul>
                                                    </div>
                                                    <?php endif; ?>
                                                    <?php if(!empty($property['building_age'])) : ?>
                                                    <div class="col-md-4 col-sm-4 col-xs-12">
                                                        <ul class="condition">
                                                            <li>
                                                                <i class="fa fa-check-square"></i>Less than <?php echo $property['building_age']; ?> years(s)
                                                            </li>
                                                        </ul>
                                                    </div>
                                                    <?php endif;?>
                                                    <?php if(!empty($property['toilets'])) : ?>
                                                    <div class="col-md-4 col-sm-4 col-xs-12">
                                                        <ul class="condition">
                                                            <li>
                                                                <i class="fa fa-check-square"></i><?php echo $property['toilets']; ?> Toilet(s)
                                                            </li>
                                                        </ul>
                                                    </div>
                                                    <?php endif;?>
                                                    <?php if(!empty($property['floor_type'])) : ?>
                                                    <div class="col-md-4 col-sm-4 col-xs-12">
                                                        <ul class="condition">
                                                            <li>
                                                                <i class="fa fa-check-square"></i><?php echo ucfirst($property['floor_type']); ?> Floor Type
                                                            </li>
                                                        </ul>
                                                    </div>
                                                    <?php endif;?>
                                                    <?php if(!empty($property['packing'])) : ?>
                                                    <div class="col-md-4 col-sm-4 col-xs-12">
                                                        <ul class="condition">
                                                            <li>
                                                                <i class="fa fa-check-square"></i><?php echo ucfirst($property['packing']); ?> Packing Space
                                                            </li>
                                                        </ul>
                                                    </div>
                                                    <?php endif;?>
                                                    <?php if(!empty($property['landload'])) : ?>
                                                    <div class="col-md-4 col-sm-4 col-xs-12">
                                                        <ul class="condition">
                                                            <li>
                                                                <i class="fa fa-check-square"></i><?php echo ucfirst($property['landload']); ?>, Landloard
                                                            </li>
                                                        </ul>
                                                    </div>
                                                    <?php endif;?>
                                                    <?php if(!empty($property['security_post'])) : ?>
                                                    <div class="col-md-4 col-sm-4 col-xs-12">
                                                        <ul class="condition">
                                                            <li>
                                                                <i class="fa fa-check-square"></i><?php echo ucfirst($property['security_post']); ?>, Security Post
                                                            </li>
                                                        </ul>
                                                    </div>
                                                    <?php endif;?>                                                    
                                                </div>                                                
                                            </div><!-- Properties condition end -->    
                                            <!-- features --> 
                                            <?php if(!empty($property['features'])) :?>
                                            <hr style="width:80%">
                                                <div class="properties-condition">
                                                    <div class="main-title-2">
                                                        <h1><span>More Features</span></h1>
                                                    </div>
                                                    <?php
                                                        $features = array();
                                                        $features = explode(',', $property['features']);
                                                    ?>
                                                    <div class="row">
                                                        <?php 
                                                            foreach ($features as $feature) :
                                                        ?>
                                                            <div class="col-md-4 col-sm-4 col-xs-12">
                                                                <ul class="condition">
                                                                    <li>
                                                                        <i class="fa fa-check-circle"></i><?php echo ucwords($feature); ?>
                                                                    </li>
                                                                </ul>
                                                            </div>
                                                        <?php endforeach; ?>
                                                    </div>
                                                </div>
                                                <?php endif; ?>                                        
                                        </div><!--tab-pane fade features -->
                                    </div>
                                </div> <!-- panel -->
                            </div> <!-- panel with-nav-tabs panel-default -->
                        </div>
                        <!-- Property description end -->
                    </div>                            
                    <!-- Property disclaimer -->
                    <div class="Properties-details-section sidebar-widget">
                            <!-- Main Title 2 -->
                            <div class="main-title-2">
                                <h1>Disclaimer</h1>
                            </div>
                            <p><?= lang('disclaimer'); ?></p>
                    </div>
                    <!-- Properties details section end -->
                    <?php endif;?>
                    
                    <!--Related Properties-->
                    <div class="Properties-details-section">
                         <!-- Main Title 2 -->
                            <div class="main-title-2">
                                <h1>Related Properties</h1>
                            </div>
                        <?php 
                            foreach( $relateds as $related ) :
                                $property_image = $this->property_model->fetch_featured_image( $related->pid );
                                $src = !empty($property_image) ? base_url('assets/app/images/').$property_image->img_name : base_url('assets/app/images/myagentng.jpg'); 
                        ?>
                        <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                            <div class="property">
                                <a href="<?= base_url( 'property/'. $related->pid .'/'. url_title(strtolower($related->title)) ); ?>" class="property-img">
                                    <div class="property-tag button alt featured">Featured</div>
                                    <div class="property-tag button sale"><?= ucwords($related->property_type); ?></div>
                                    <div class="property-price"><span><?= ngn($related->price); ?></span></div>
                                    <img src="<?= $src; ?>" alt="<?= $related->title; ?>" class="img-responsive">
                                </a>
                                <!-- Property content -->
                                <div class="property-content">
                                    <!-- title -->
                                    <h1 class="title">
                                        <a href="<?= base_url( 'property/'. $related->pid .'/'. url_title(strtolower($related->title)) ); ?>"><?= word_limiter(ucwords($related->title), 5, '...'); ?></a>
                                    </h1>
                                    <!-- Property address -->
                                    <h3 class="property-address">
                                        <a href="<?= base_url( 'property/'. $related->pid .'/'. url_title(strtolower($related->title)) ); ?>"><i class="fa fa-map-marker"></i><?= ucwords($related->address); ?></a>
                                    </h3>
                                    <!-- Facilities List -->
                                    <!-- <ul class="facilities-list clearfix">
                                        <li>
                                            <i class="flaticon-bed"></i>
                                            <span>3 Bed(s)</span>
                                        </li>
                                        <li>
                                            <i class="flaticon-holidays"></i>
                                            <span> 2 Bath(s)</span>
                                        </li>
                                        <li>
                                            <i class="flaticon-vehicle"></i>
                                            <span>Parking lot</span>
                                        </li>
                                    </ul> -->
                                    <!-- Property footer -->
                                    <div class="property-footer">
                                        <span class="left"><i class="fa fa-calendar-o icon"></i>&nbsp;<?= ago($related->postdate); ?></span>
                                        <span class="right">
                                            <?php
                                            // echo $property->id;                                                    
                                                if( $this->session->userdata('logged_in') ) {
                                                    if($this->property_model->is_favourited($this->session->userdata('user_id'), $related->id ) ) { 
                                            ?>
                                                        <a href="#" class="fav" data-action="unfavpost" data-pid="<?= $related->id; ?>"><i class="fa fa-heart"></i></a>
                                                    <?php } else { ?>
                                                        <a href="#" class="fav" data-action="favpost" data-pid="<?= $related->id; ?>"><i class="fa fa-heart-o"></i></a>
                                                   <?php }
                                                }else{ ?>
                                                    <a href="#" class="login"><i class="fa fa-heart-o"></i></a>; 
                                                <?php } 
                                            ?>
                                            <a href="#"><i class="fa fa-share-alt"></i></a>                                               
                                        </span>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <?php endforeach; ?>
                        
                    </div>
                    <!--End of related properties -->
                </div>
            <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
                    <!-- Sidebar start -->
                    <div class="sidebar right">
                        
                        <!-- Verified/Unverified Agent -->
                        <div class="sidebar-widget contact-form agent-widget">
                            <div class="row">
                                <div class="col-lg-12">
                                    <label class="button-md button-theme btn-block text-center hidden"><span class="fa fa-check-circle"> </span> Verified Agent</label>
                                    <label class="button-md btn-block text-center"><span class="fa fa-times-circle"> </span> Unverified Agent</label>
                                </div>
                            </div>
                        </div>
                        <!-- Agent widget end -->
                        
                        <!--Contact Agent-->
                        <div class="sidebar-widget contact-form agent-widget">
                            <div class="row">
                                <div class="col-lg-12">
                                    <label class="button-md button-theme btn-block"><span class="fa fa-phone-square"> </span> Contact Agent: 08064075956</label>
                                    <label class="button-md button-theme btn-block hidden"><span class="fa fa-phone-square"> </span> Contact Us: 08159598695</label>
                                </div>
                            </div>
                        </div>
                        
                        <!-- Popular posts start -->
                        <div class="sidebar-widget popular-posts">
                            <div class="main-title-2">
                                <h1><span>Recent</span> Properties</h1>
                            </div>
                            <?php
                                foreach( $recents as $recent ) :
                                    // fetch image
                                    $property_image = $this->property_model->fetch_featured_image( $recent->pid );
                                    $src = !empty($property_image) ? base_url('assets/app/images/thumbnail/').$property_image->img_name : base_url('assets/app/images/thumbnail/myagentng_thumbnail.jpg'); 
                            ?>
                            <div class="media">
                                <div class="media-left">
                                    <img class="media-object" src="<?= $src; ?>" alt="small-properties-1">
                                </div>
                                <div class="media-body">
                                    <h3 class="media-heading">
                                        <a href="<?= base_url( 'property/'. $recent->pid .'/'. url_title(strtolower($recent->title)) ); ?>"><?= word_limiter(ucwords($recent->title), 10, '...'); ?></a>
                                    </h3>
                                    <p>Posted on: <span><?= date('dS F, Y',strtotime($recent->postdate)); ?></span></p>
                                </div>
                            </div>
                            <?php endforeach; ?>
                        </div>
                        <!-- Popular posts end -->

                        <!-- Social media start -->
                        <div class="social-media sidebar-widget clearfix">
                            <!-- Main Title 2 -->
                            <div class="main-title-2">
                                <h1><span>Social</span> Media</h1>
                            </div>
                            <!-- Social list -->
                            <ul class="social-list">
                                <li><a href="<?= lang('facebook_url'); ?>" class="facebook"><i class="fa fa-facebook"></i></a></li>
                                <li><a href="<?= lang('twitter_url'); ?>" class="twitter"><i class="fa fa-twitter"></i></a></li>
                                <li><a href="<?= lang('linkedin_url'); ?>" class="linkedin"><i class="fa fa-linkedin"></i></a></li>
                                <!-- <li><a href="#" class="google"><i class="fa fa-google-plus"></i></a></li>
                                <li><a href="#" class="rss"><i class="fa fa-rss"></i></a></li> -->
                            </ul>
                        </div>
                        <!-- Social media end -->

                    </div>
                    <!-- Sidebar end -->
            </div>
        </div>
    </div>
</div>
<!-- Properties details page end -->

<!-- Testimonial section end -->
<div class="clearfix"></div>

<!-- Counters strat -->
<?php $this->load->view('landing/includes/counter'); ?>
<!-- Counters end -->
<!-- Partners block start -->
<?php $this->load->view('landing/includes/partners'); ?>
<!-- Partners block end -->
<!-- Footer start -->
<?php $this->load->view('landing/includes/footer'); ?>
<!-- Footer end -->
<!-- Copy right start -->
<div class="copy-right">
    <div class="container">
        <?= lang('footer_text'); ?>
    </div>
</div>
<!-- Copy end right-->

<script type="text/javascript" src="<?= base_url('assets/landing/js/jquery-2.2.0.min.js'); ?>"></script>
<script type="text/javascript" src="<?= base_url('assets/landing/js/bootstrap.min.js'); ?>"></script>
<script type="text/javascript" src="<?= base_url('assets/landing/js/bootstrap-submenu.js'); ?>"></script>
<script type="text/javascript" src="<?= base_url('assets/landing/js/rangeslider.js'); ?>"></script>
<script type="text/javascript" src="<?= base_url('assets/landing/js/jquery.mb.YTPlayer.js'); ?>"></script>
<script type="text/javascript" src="<?= base_url('assets/landing/js/wow.min.js'); ?>"></script>
<script type="text/javascript" src="<?= base_url('assets/landing/js/bootstrap-select.min.js'); ?>"></script>
<script type="text/javascript" src="<?= base_url('assets/landing/js/jquery.easing.1.3.js'); ?>"></script>
<script type="text/javascript" src="<?= base_url('assets/landing/js/jquery.scrollUp.js'); ?>"></script>
<script type="text/javascript" src="<?= base_url('assets/landing/js/jquery.mCustomScrollbar.concat.min.js'); ?>"></script>
<script type="text/javascript" src="<?= base_url('assets/landing/js/leaflet.js'); ?>"></script>
<script type="text/javascript" src="<?= base_url('assets/landing/js/leaflet-providers.js'); ?>"></script>
<script type="text/javascript" src="<?= base_url('assets/landing/js/leaflet.markercluster.js'); ?>"></script>
<script type="text/javascript" src="<?= base_url('assets/landing/js/dropzone.js'); ?>"></script>
<script type="text/javascript" src="<?= base_url('assets/landing/js/jquery.filterizr.js'); ?>"></script>
<script type="text/javascript" src="<?= base_url('assets/landing/js/maps.js'); ?>"></script>
<script type="text/javascript" src="<?= base_url('assets/landing/js/app.js'); ?>"></script>
<script>
$(document).ready(function() {
    $('.fav').on('click', function(e) {
            e.preventDefault();
            thisClass = $(this);
            pid = $(this).attr('data-pid');
            action = $(this).attr('data-action');
            $.ajax({
                url: "<?php echo base_url('property/fav'); ?>",
                method: "POST",
                data: {pid:pid, action:action},
                success:function(data) {                    
                    if( data == true ){
                        if( action == 'favpost') {
                            thisClass.find("i").addClass('fa-heart');
                            thisClass.find("i").removeClass('fa-heart-o');
                            thisClass.attr('data-action', 'unfavpost');
                            swal({
                                title: "Success",
                                text: 'The property has been favourited, you can view it later on your dashboard',
                                type: "success"
                            });
                        }else {
                            thisClass.find("i").removeClass('fa-heart');
                            thisClass.find("i").addClass('fa-heart-o');
                            thisClass.attr('data-action', 'favpost');
                            swal({
                                title: "Success",
                                text: 'The property has been un-favourite.',
                                type: "info"
                            });
                        }
                    }else {
                        swal({
                            title: "Error",
                            text: 'Sorry there was an error performing that action, please try again, or refresh your browser.',
                            type: "error"
                        });
                    }
                }// success
            }); // ajax
    });
});
</script>
</body>

</html>