<?php $this->load->view('landing/includes/header'); ?>
<!-- Styles -->
</head>
<body>
<!-- Top header start -->
<?php $this->load->view('landing/includes/top_head'); ?>
<!-- Main header end -->
<!-- Sub banner start -->
<div class="sub-banner2">
    <div class="overlay">
        <div class="container">
            <div class="breadcrumb-area-1">
                <h1>Contact US</h1>
                <ul class="breadcrumbs">
                    <li><a href="<?= base_url(); ?>">Home</a></li>
                    <li class="active">Contact us</li>
                </ul>
            </div>
        </div>
    </div>
</div>
<!-- Sub Banner end -->

 <!-- Contact body start -->
<div class="contact-body content-area">
    <div class="container">
        <div class="row">
            <div class="col-lg-8 col-md-8 col-sm-6 col-xs-12">
                <!-- Contact form start -->
                <div class="contact-form">
                    <div class="main-title-2">
                        <h1><span>Contact</span> US</h1>
                    </div>
                    <form id="contact_form" action="#" method="POST" enctype="multipart/form-data">
                        <div class="row">
                            <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                                <div class="form-group fullname">
                                    <input type="text" name="full-name" class="input-text" placeholder="Full Name">
                                </div>
                            </div>
                            <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                                <div class="form-group enter-email">
                                    <input type="email" name="email" class="input-text" placeholder="Your email">
                                </div>
                            </div>
                            <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                                <div class="form-group subject">
                                    <input type="text" name="subject" class="input-text" placeholder="Subject">
                                </div>
                            </div>
                            <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                                <div class="form-group number">
                                    <input type="text" name="phone" class="input-text" placeholder="Phone Number">
                                </div>
                            </div>
                            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 clearfix">
                                <div class="form-group message">
                                    <textarea class="input-text" name="message" placeholder="Write message"></textarea>
                                </div>
                            </div>
                            <div class="col-lg-12 col-md-6 col-sm-12 col-xs-12">
                                <div class="form-group send-btn">
                                    <button type="submit" class="button-md button-theme">Send Message</button>
                                </div>
                            </div>
                        </div>
                    </form>     
                </div>
                <!-- Contact form end -->
            </div>
            <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
                <!-- Contact details start -->
                <div class="contact-details">
                    <div class="main-title-2">
                        <h1><span>Our</span> address</h1>
                    </div>
                    <div class="media">
                        <div class="media-left">
                            <i class="fa fa-map-marker"></i>
                        </div>
                        <div class="media-body">
                            <h4>Office Address</h4>
                            <?= lang('contact_address'); ?>
                        </div>
                    </div>
                    <div class="media">
                        <div class="media-left">
                            <i class="fa fa-phone"></i>
                        </div>
                        <div class="media-body">
                            <h4>Phone Numbers</h4>
                            <p>
                                Phone: <a href="tel:+<?= lang('phone1'); ?>">+<?= lang('phone1'); ?></a>
                            </p>
                            <p>
                                Phone: <a href="tel:+<?= lang('phone2'); ?>">+<?= lang('phone2'); ?></a>
                            </p>
                        </div>
                    </div>
                    <div class="media mrg-btm-0">
                        <div class="media-left">
                            <i class="fa fa-envelope"></i>
                        </div>
                        <div class="media-body">
                            <h4>Email Address</h4>
                            <p><a href="mailto:<?= lang('site_mail'); ?>"><?= lang('site_mail'); ?></a></p>
                            <p> <a href="mailto:<?= lang('contact_mail');?>"><?= lang('contact_mail');?></a> </p>
                        </div>
                    </div>
                </div>
                <!-- Contact details end -->
            </div>
        </div>
    </div>
</div>
<!-- Contact body end -->   
    
 <!-- Testimonial section end -->
<div class="clearfix"></div>

<!-- Counters strat -->
<?php $this->load->view('landing/includes/counter'); ?>
<!-- Counters end -->

<!-- Partners block start -->
<div class="partners-block">
    <div class="container">
        <h3>Brands & Partners</h3>
        <div class="row">
            <div class="col-md-12">
                <div class="carousel our-partners slide" id="ourPartners">
                    <div class="carousel-inner">
                        <div class="item active">
                            <div class="col-xs-12 col-sm-6 col-md-3">
                                <a href="#">
                                    <img src="img/brand/afri1.png" alt="">
                                </a>
                            </div>
                        </div>
                        <div class="item">
                            <div class="col-xs-12 col-sm-6 col-md-3">
                                <a href="#">
                                    <img src="img/brand/afri1.png" alt="">
                                </a>
                            </div>
                        </div>
                        <div class="item">
                            <div class="col-xs-12 col-sm-6 col-md-3">
                                <a href="#">
                                    <img src="img/brand/tuts.png" alt="">
                                </a>
                            </div>
                        </div>
                        <div class="item">
                            <div class="col-xs-12 col-sm-6 col-md-3">
                                <a href="#">
                                    <img src="img/brand/afri1.png" alt="">
                                </a>
                            </div>
                        </div>
                        <div class="item">
                            <div class="col-xs-12 col-sm-6 col-md-3">
                                <a href="#">
                                    <img src="img/brand/afri1.png" alt="">
                                </a>
                            </div>
                        </div>
                    </div>
                    <a class="left carousel-control" href="#ourPartners" data-slide="prev"><i class="fa fa-chevron-left icon-prev"></i></a>
                    <a class="right carousel-control" href="#ourPartners" data-slide="next"><i class="fa fa-chevron-right icon-next"></i></a>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Partners block end -->

<!-- Footer start -->
<?php $this->load->view('landing/includes/footer'); ?>
<!-- Footer end -->
<!-- Copy right start -->
<div class="copy-right">
    <div class="container">
        &copy;  <?= date('Y'); ?> <a href="http://myagent.ng/" target="_blank"><?= lang('site_name');?></a> | Trademarks and brands are the property of their respective owners.
    </div>
</div>
<!-- Copy end right-->

<script type="text/javascript" src="<?= base_url('assets/landing/js/jquery-2.2.0.min.js'); ?>"></script>
<script type="text/javascript" src="<?= base_url('assets/landing/js/bootstrap.min.js'); ?>"></script>
<script type="text/javascript" src="<?= base_url('assets/landing/js/bootstrap-submenu.js'); ?>"></script>
<script type="text/javascript" src="<?= base_url('assets/landing/js/rangeslider.js'); ?>"></script>
<script type="text/javascript" src="<?= base_url('assets/landing/js/jquery.mb.YTPlayer.js'); ?>"></script>
<script type="text/javascript" src="<?= base_url('assets/landing/js/wow.min.js'); ?>"></script>
<script type="text/javascript" src="<?= base_url('assets/landing/js/bootstrap-select.min.js'); ?>"></script>
<script type="text/javascript" src="<?= base_url('assets/landing/js/jquery.easing.1.3.js'); ?>"></script>
<script type="text/javascript" src="<?= base_url('assets/landing/js/jquery.scrollUp.js'); ?>"></script>
<script type="text/javascript" src="<?= base_url('assets/landing/js/jquery.mCustomScrollbar.concat.min.js'); ?>"></script>
<script type="text/javascript" src="<?= base_url('assets/landing/js/leaflet.js'); ?>"></script>
<script type="text/javascript" src="<?= base_url('assets/landing/js/leaflet-providers.js'); ?>"></script>
<script type="text/javascript" src="<?= base_url('assets/landing/js/leaflet.markercluster.js'); ?>"></script>
<script type="text/javascript" src="<?= base_url('assets/landing/js/dropzone.js'); ?>"></script>
<script type="text/javascript" src="<?= base_url('assets/landing/js/jquery.filterizr.js'); ?>"></script>
<script type="text/javascript" src="<?= base_url('assets/landing/js/maps.js'); ?>"></script>
<script type="text/javascript" src="<?= base_url('assets/landing/js/app.js'); ?>"></script>

<!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
<script type="text/javascript" src="<?= base_url('js/ie10-viewport-bug-workaround.js'); ?>"></script>
</body>

</html>