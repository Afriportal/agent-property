<?php $this->load->view('landing/includes/header'); ?>
<!-- Styles -->
</head>
<body>
<!-- Top header start -->
<?php $this->load->view('landing/includes/top_head'); ?>
<!-- Main header end -->

<!-- Banner start -->
<div class="banner">
    <div id="carousel-example-generic" class="carousel slide" data-ride="carousel">
        <!-- Wrapper for slides -->
        <div class="carousel-inner" role="listbox">
            <div class="item active">
                <img src="<?= base_url('assets/landing/img/banner/banner-slider-1.jpg')?>" alt="banner-slider-1">
                <div class="carousel-caption banner-slider-inner banner-top-align">
                    <div class="text-center">
                        <h1 data-animation="animated fadeInDown delay-05s"><span>Welcome to </span> MyAgent.ng</h1>
                        <p class="hidden-xs">Rent a house Anywhere in Portharcourt or its Environs</p>
                        <a href="#" class="btn button-md button-theme" data-animation="animated fadeInUp delay-05s">Get Started Now</a>
                    </div>
                </div>
            </div>
            <div class="item">
                <img src="<?= base_url('assets/landing/img/banner/banner-slider-2.jpg'); ?> " alt="banner-slider-2">
                <div class="carousel-caption banner-slider-inner banner-top-align">
                    <div class="text-right">
                        <h1 data-animation="animated fadeInDown delay-05s"><span>Renting a house</span> <br>can be simple</h1>
                        <a href="#" class="btn button-md button-theme" data-animation="animated fadeInUp delay-05s">See How</a>
                    </div>
                </div>
            </div>
            <div class="item">
                <img src="<?= base_url('assets/landing/img/banner/banner-slider-3.jpg') ?>" alt="banner-slider-3">
                <div class="carousel-caption banner-slider-inner banner-top-align">
                    <div class="text-left">
                        <h1 data-animation="animated fadeInDown delay-05s"><span>Find your</span><br> Dream House</h1>
                        <a href="#" class="btn button-md button-theme" data-animation="animated fadeInUp delay-05s">Get Started Now</a>
                    </div>
                </div>
            </div>
        </div>

        <!-- Controls -->
        <a class="left carousel-control" href="#carousel-example-generic" role="button" data-slide="prev">
            <span class="slider-mover-left" aria-hidden="true">
                <i class="fa fa-angle-left"></i>
            </span>
            <span class="sr-only">Previous</span>
        </a>
        <a class="right carousel-control" href="#carousel-example-generic" role="button" data-slide="next">
            <span class="slider-mover-right" aria-hidden="true">
                <i class="fa fa-angle-right"></i>
            </span>
            <span class="sr-only">Next</span>
        </a>
    </div>
</div>
<!-- Banner end -->

<!-- Search area start -->
<div class="search-area">
    <div class="container">
        <div class="search-area-inner">
            <div class="search-contents ">
                <div class="row">
                    <div class="col-lg-4 col-md-4 col-sm-6 col-xs-6">
                        <div class="form-group">
                            <select name="property_type" required class="selectpicker search-fields" data-live-search="true" data-live-search-placeholder="Search value">
                                <option value="">-- Select Property Status --</option>
                                <option value="for sale">For Sale</option>
                                <option value="for rent">For Rent</option>
                                <option value="short let">Short Let</option>
                            </select>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-4 col-sm-6 col-xs-6">
                        <div class="form-group">
                            <select name="lga" class="selectpicker search-fields" data-live-search="true" data-live-search-placeholder="Search value">
                                <option value="">--Choose Location--</option>
                                <?php $types = explode(',', lang('lga')); 
                                    foreach( $types as $type ):
                                ?>
                                <option value="<?= trim($type); ?>"><?= ucwords(trim($type)); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
                        <div class="form-group">
                            <select name="type_of_property" class="selectpicker search-fields" data-live-search="true" data-live-search-placeholder="Search value">
                                <option>-- Select Property Type --</option>
                                <?php $types = explode(',', lang('type_of_property')); 
                                    foreach( $types as $type ):
                                ?>
                                <option value="<?= trim($type); ?>"><?= ucwords(trim($type)); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-3 col-md-3 col-sm-6 col-xs-6">
                        <div class="form-group">
                            <select name="bedrooms" class="selectpicker search-fields" data-live-search="true" data-live-search-placeholder="Search value" >
                                <option>-- No. of Bedrooms (Optional) --</option>
                                <?php $types = explode(',', lang('numbers')); 
                                    foreach( $types as $type ):
                                ?>
                                <option value="<?= trim($type); ?>"><?= trim($type); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-3 col-sm-6 col-xs-6">
                        <div class="form-group">
                            <select name="bathrooms" class="selectpicker search-fields" data-live-search="true" data-live-search-placeholder="Search value" >
                                <option>-- No. of Bathrooms (Optional) --</option>
                                <?php $types = explode(',', lang('numbers')); 
                                    foreach( $types as $type ):
                                ?>
                                <option value="<?= trim($type); ?>"><?= trim($type); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-4 col-sm-6 col-xs-6 hidden-xs">
                        <div class="form-group">
                            <div class="range-slider">
                                <div data-min="10000" data-max="100000000" data-unit="NGN" class="range-slider-ui ui-slider" aria-disabled="false"></div>
                                <div class="clearfix"></div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-2 col-md-2 col-sm-6 col-xs-6 ">
                        <div class="form-group">
                            <button type="submit" class="search-button">Search</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
                    <div class="hidden-sm hidden-xs">
                            <a class="show-more-options" data-toggle="collapse" data-target="#options-content">
                        <i class="fa fa-plus-circle"></i> Advanced Search Options
                    </a>
            
                <!--Advanced Search Options-->
                    <div id="options-content" class="collapse">
                        <div class="row">
                            <div class="col-lg-3 col-md-3 col-sm-6 col-xs-6">
                                <div class="form-group">
                                    <select class="selectpicker search-fields">
                                        <option>-- Type of Property --</option>
                                        <option>Detached Building</option>
                                        <option>Block of Flats</option>
                                        <option>High Rise Building</option>
                                        <option>Ground floor</option>
                                        <option>Apartment Building</option>
                                        <option>Bungalow</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-lg-3 col-md-3 col-sm-6 col-xs-6">
                                <div class="form-group">
                                    <select class="selectpicker search-fields">
                                        <option>-- How many Storey Building --</option>
                                        <option>1</option>
                                        <option>2</option>
                                        <option>3</option>
                                        <option>4</option>
                                        <option>5</option>
                                        <option>6</option>
                                        <option>7</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-lg-3 col-md-3 col-sm-6 col-xs-6">
                                <div class="form-group">
                                    <select class="selectpicker search-fields">
                                        <option>-- Number of Toilets --</option>
                                        <option>1</option>
                                        <option>2</option>
                                        <option>3</option>
                                        <option>4</option>
                                        <option>5</option>
                                        <option>6</option>
                                        <option>7</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-lg-3 col-md-3 col-sm-6 col-xs-6">
                                <div class="form-group">
                                    <select class="selectpicker search-fields">
                                        <option>-- Floor Type --</option>
                                        <option>Marble</option>
                                        <option>Terazzo</option>
                                        <option>Tiles</option>
                                        <option>Others</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                        
                        <!--Row 2-->
                        <div class="row">
                            <div class="col-lg-3 col-md-3 col-sm-6 col-xs-6">
                                <div class="form-group">
                                    <select class="selectpicker search-fields">
                                        <option>-- Minimum Payment Period --</option>
                                        <option>Less than One Year</option>
                                        <option>One Year</option>
                                        <option>Above One Year</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-lg-3 col-md-3 col-sm-6 col-xs-6">
                                <div class="form-group">
                                    <select class="selectpicker search-fields">
                                        <option>-- Landlord Living in Premises --</option>
                                        <option>Yes</option>
                                        <option>No</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-lg-3 col-md-3 col-sm-6 col-xs-6">
                                <div class="form-group">
                                    <select class="selectpicker search-fields">
                                        <option>-- State of Building --</option>
                                        <option>Newly Built</option>
                                        <option>Renovated</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-lg-3 col-md-3 col-sm-6 col-xs-6">
                                <div class="form-group">
                                    <select class="selectpicker search-fields">
                                        <option>-- Security Post --</option>
                                        <option>Yes</option>
                                        <option>No</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                            <label class="margin-t-10"></label>
                            <div class="col-lg-3">
                                <div class="checkbox checkbox-theme checkbox-circle">
                                    <input id="checkbox1" type="checkbox">
                                    <label for="checkbox1">
                                        Veranda
                                    </label>
                                </div>
                                <div class="checkbox checkbox-theme checkbox-circle">
                                    <input id="checkbox2" type="checkbox">
                                    <label for="checkbox2">
                                        Balcony
                                    </label>
                                </div>
                                <div class="checkbox checkbox-theme checkbox-circle">
                                    <input id="checkbox3" type="checkbox">
                                    <label for="checkbox3">
                                        Store
                                    </label>
                                </div>
                            </div>
                        
                            <div class="col-lg-3">
                                <div class="checkbox checkbox-theme checkbox-circle">
                                    <input id="checkbox4" type="checkbox">
                                    <label for="checkbox4">
                                        Double Window
                                    </label>
                                </div>
                                <div class="checkbox checkbox-theme checkbox-circle">
                                    <input id="checkbox5" type="checkbox">
                                    <label for="checkbox5">
                                        Single Window
                                    </label>
                                </div>
                                <div class="checkbox checkbox-theme checkbox-circle">
                                    <input id="checkbox6" type="checkbox">
                                    <label for="checkbox6">
                                       Packing Space
                                    </label>
                                </div>
                            </div>
                            <div class="col-lg-3">
                                <div class="checkbox checkbox-theme checkbox-circle">
                                    <input id="checkbox7" type="checkbox">
                                    <label for="checkbox7">
                                        Negotiable
                                    </label>
                                </div>
                                <div class="checkbox checkbox-theme checkbox-circle">
                                    <input id="checkbox8" type="checkbox">
                                    <label for="checkbox8">
                                        Nearness to IOC
                                    </label>
                                </div>
                                <div class="checkbox checkbox-theme checkbox-circle">
                                    <input id="checkbox8" type="checkbox">
                                    <label for="checkbox8">
                                        Nearness to Police Station
                                    </label>
                                </div>
                           </div>
                           <div class="col-lg-3">
                                <div class="checkbox checkbox-theme checkbox-circle">
                                    <input id="checkbox7" type="checkbox">
                                    <label for="checkbox7">
                                        Nearness to Water Body
                                    </label>
                                </div>
                                <div class="checkbox checkbox-theme checkbox-circle">
                                    <input id="checkbox8" type="checkbox">
                                    <label for="checkbox8">
                                        Nearness to Market
                                    </label>
                                </div>
                                <div class="checkbox checkbox-theme checkbox-circle">
                                    <input id="checkbox8" type="checkbox">
                                    <label for="checkbox8">
                                        Nearness to Bus Stop
                                    </label>
                                </div>
                           </div>
                     </div>
                        <!--End of Advanced Search Options-->
                 </div>
    </div>
</div>
    <!-- Search area start -->

<!-- Featured properties start -->
<div class="content-area featured-properties">
    <div class="container">
        <!-- Main title -->
        <div class="main-title">
            <h1><span>Featured</span> Properties</h1>
        </div>
        <div class="row">
            <div class="filtr-container">
                <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12  filtr-item" data-category="1, 2, 3">
                    <div class="property">
                        <!-- Property img -->
                        <a href="properties-details.php" class="property-img">
                            <div class="property-tag button alt featured">Featured</div>
                            <div class="property-tag button sale">For Sale</div>
                            <div class="property-price"><span>&#x20A6;</span>150,000</div>
                            <img src="<?= base_url('assets/landing/img/properties/properties-1.jpg') ?> " alt="properties-1" class="img-responsive">
                        </a>
                        <!-- Property content -->
                        <div class="property-content">
                            <!-- title -->
                            <h1 class="title">
                                <a href="properties-details.php">Beautiful Single Home</a>
                            </h1>
                            <!-- Property address -->
                            <h3 class="property-address">
                                <a href="properties-details.php">
                                    <i class="fa fa-map-marker"></i>No. 5 Emene road, off Oleguchi street.
                                </a>
                            </h3>
                            <!-- Facilities List -->
                            <ul class="facilities-list clearfix">
                                <li>
                                    <i class="flaticon-bed"></i>
                                    <span>3 Bed(s)</span>
                                </li>
                                <li>
                                    <i class="flaticon-holidays"></i>
                                    <span> 2 Bath(s)</span>
                                </li>
                                <li>
                                    <i class="flaticon-vehicle"></i>
                                    <span>Parking lot</span>
                                </li>
                            </ul>
                            <!-- Property footer -->
                            <div class="property-footer">
                                <span class="left"><i class="fa fa-calendar-o icon"></i> 1 days ago</span>
                                <span class="right">
                                    <a href="#"><i class="fa fa-heart-o icon"></i></a>
                                    <a href="#"><i class="fa fa-share-alt"></i></a>
                                </span>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12  filtr-item" data-category="1">
                    <div class="property">
                        <!-- Property img -->
                        <a href="properties-details.php" class="property-img">
                            <div class="property-tag button alt featured">Featured</div>
                            <div class="property-tag button sale">For Rent</div>
                            <div class="property-price"><span>&#x20A6;</span>1,500,000</div>
                            <img src="<?= base_url('assets/landing/img/properties/properties-3.jpg') ?> " alt="properties-3" class="img-responsive">
                        </a>
                        <!-- Property content -->
                        <div class="property-content">
                            <!-- title -->
                            <h1 class="title">
                                <a href="properties-details.php">Modern Family Home</a>
                            </h1>
                            <!-- Property address -->
                            <h3 class="property-address">
                                <a href="properties-details.php">
                                    <i class="fa fa-map-marker"></i>No. 5 Emene road, off Oleguchi street.
                                </a>
                            </h3>
                            <!-- Facilities List -->
                           <ul class="facilities-list clearfix">
                                <li>
                                    <i class="flaticon-bed"></i>
                                    <span>3 Bed(s)</span>
                                </li>
                                <li>
                                    <i class="flaticon-holidays"></i>
                                    <span> 2 Bath(s)</span>
                                </li>
                                <li>
                                    <i class="flaticon-vehicle"></i>
                                    <span>Parking lot</span>
                                </li>
                            </ul>
                            <!-- Property footer -->
                            <div class="property-footer">
                                <span class="left"><i class="fa fa-calendar-o icon"></i> 1 days ago</span>
                                <span class="right">
                                    <a href="#"><i class="fa fa-heart-o icon"></i></a>
                                    <a href="#"><i class="fa fa-share-alt"></i></a>
                                </span>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12  filtr-item" data-category="2, 3">
                    <div class="property">
                        <!-- Property img -->
                        <a href="properties-details.php" class="property-img">
                            <div class="property-tag button alt featured">Featured</div>
                            <div class="property-tag button sale">For Sale</div>
                            <div class="property-price"><span>&#x20A6;</span>550,000</div>
                            <img src="<?= base_url('assets/landing/img/properties/properties-4.jpg') ?>" alt="properties-4" class="img-responsive">
                        </a>
                        <!-- Property content -->
                        <div class="property-content">
                            <!-- title -->
                            <h1 class="title">
                                <a href="properties-details.php">Sweet Family Home</a>
                            </h1>
                            <!-- Property address -->
                            <h3 class="property-address">
                                <a href="properties-details.php">
                                    <i class="fa fa-map-marker"></i>No. 5 Emene road, off Oleguchi street.
                                </a>
                            </h3>
                            <!-- Facilities List -->
                            <ul class="facilities-list clearfix">
                                <li>
                                    <i class="flaticon-bed"></i>
                                    <span>3 Bed(s)</span>
                                </li>
                                <li>
                                    <i class="flaticon-holidays"></i>
                                    <span> 2 Bath(s)</span>
                                </li>
                                <li>
                                    <i class="flaticon-vehicle"></i>
                                    <span>Parking lot</span>
                                </li>
                            </ul>
                            <!-- Property footer -->
                            <div class="property-footer">
                                <span class="left"><i class="fa fa-calendar-o icon"></i> 2 days ago</span>
                                <span class="right">
                                    <a href="#"><i class="fa fa-heart-o icon"></i></a>
                                    <a href="#"><i class="fa fa-share-alt"></i></a>
                                </span>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12  filtr-item" data-category="3, 4">
                    <div class="property">
                        <!-- Property img -->
                        <a href="properties-details.php" class="property-img">
                            <div class="property-tag button alt featured">Featured</div>
                            <div class="property-tag button sale">For Sale</div>
                            <div class="property-price"><span>&#x20A6;</span>350,000</div>
                            <img src="<?= base_url('assets/landing/img/properties/properties-8.jpg') ?> " alt="properties-8" class="img-responsive">
                        </a>
                        <!-- Property content -->
                        <div class="property-content">
                            <!-- title -->
                            <h1 class="title">
                                <a href="properties-details.php">Big Head House</a>
                            </h1>
                            <!-- Property address -->
                            <h3 class="property-address">
                                <a href="properties-details.php">
                                    <i class="fa fa-map-marker"></i>No. 5 Emene road, off Oleguchi street.
                                </a>
                            </h3>
                            <!-- Facilities List -->
                            <ul class="facilities-list clearfix">
                                <li>
                                    <i class="flaticon-bed"></i>
                                    <span>3 Bed(s)</span>
                                </li>
                                <li>
                                    <i class="flaticon-holidays"></i>
                                    <span> 2 Bath(s)</span>
                                </li>
                                <li>
                                    <i class="flaticon-vehicle"></i>
                                    <span>Parking lot</span>
                                </li>
                            </ul>
                            <!-- Property footer -->
                            <div class="property-footer">
                                <span class="left"><i class="fa fa-calendar-o icon"></i> 4 days ago</span>
                                <span class="right">
                                    <a href="#"><i class="fa fa-heart-o icon"></i></a>
                                    <a href="#"><i class="fa fa-share-alt"></i></a>
                                </span>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12  filtr-item" data-category="4">
                    <div class="property">
                        <!-- Property img -->
                        <a href="properties-details.php" class="property-img">
                            <div class="property-tag button alt featured">Featured</div>
                            <div class="property-tag button sale">For Rent</div>
                            <div class="property-price"><span>&#x20A6;</span>480,000</div>
                            <img src="<?= base_url('assets/landing/img/properties/properties-7.jpg') ?>" alt="properties-7" class="img-responsive">
                        </a>
                        <!-- Property content -->
                        <div class="property-content">
                            <!-- title -->
                            <h1 class="title">
                                <a href="properties-details.php">3 bedroom duplex for rent urgently</a>
                            </h1>
                            <!-- Property address -->
                            <h3 class="property-address">
                                <a href="properties-details.php">
                                    <i class="fa fa-map-marker"></i>No. 5 Emene road, off Oleguchi street.
                                </a>
                            </h3>
                            <!-- Facilities List -->
                            <ul class="facilities-list clearfix">
                                <li>
                                    <i class="flaticon-bed"></i>
                                    <span>3 Bed(s)</span>
                                </li>
                                <li>
                                    <i class="flaticon-holidays"></i>
                                    <span> 2 Bath(s)</span>
                                </li>
                                <li>
                                    <i class="flaticon-vehicle"></i>
                                    <span>Parking lot</span>
                                </li>
                            </ul>
                            <!-- Property footer -->
                            <div class="property-footer">
                                <span class="left"><i class="fa fa-calendar-o icon"></i> 5 days ago</span>
                                <span class="right">
                                    <a href="#"><i class="fa fa-heart-o icon"></i></a>
                                    <a href="#"><i class="fa fa-share-alt"></i></a>
                                </span>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12  filtr-item" data-category="1">
                    <div class="property">
                        <!-- Property img -->
                        <a href="properties-details.php" class="property-img">
                            <div class="property-tag button alt featured">Featured</div>
                            <div class="property-tag button sale">For Sale</div>
                            <div class="property-price"><span>&#x20A6;</span>550,000</div>
                            <img src="<?= base_url('assets/landing/img/properties/properties-5.jpg'); ?> " alt="properties-5" class="img-responsive">
                        </a>
                        <!-- Property content -->
                        <div class="property-content">
                            <!-- title -->
                            <h1 class="title">
                                <a href="properties-details.php">Masons Villas</a>
                            </h1>
                            <!-- Property address -->
                            <h3 class="property-address">
                                <a href="properties-details.php">
                                    <i class="fa fa-map-marker"></i>No. 5 Emene road, off Oleguchi street.
                                </a>
                            </h3>
                            <!-- Facilities List -->
                            <ul class="facilities-list clearfix">
                                <li>
                                    <i class="flaticon-bed"></i>
                                    <span>3 Bed(s)</span>
                                </li>
                                <li>
                                    <i class="flaticon-holidays"></i>
                                    <span> 2 Bath(s)</span>
                                </li>
                                <li>
                                    <i class="flaticon-vehicle"></i>
                                    <span>Parking lot</span>
                                </li>
                            </ul>
                            <!-- Property footer -->
                            <div class="property-footer">
                                <span class="left"><i class="fa fa-calendar-o icon"></i> 5 days ago</span>
                                <span class="right">
                                    <a href="#"><i class="fa fa-heart-o icon"></i></a>
                                    <a href="#"><i class="fa fa-share-alt"></i></a>
                                </span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Featured properties end -->

<!-- Our service start -->
<div class="mrg-btm-100 our-service">
    <div class="container">
        <!-- Main title -->
        <div class="main-title">
            <h1><span>What are you</span> looking for?</h1>
        </div>

        <div class="row mgn-btm wow">
            <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12 wow fadeInLeft delay-04s">
                <div class="content">
                    <i class="flaticon-apartment"></i>
                    <h4>Apartments</h4>
                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam</p>
                </div>
            </div>
            <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12 wow fadeInLeft delay-04s">
                <div class="content">
                    <i class="flaticon-internet"></i>
                    <h4>Houses</h4>
                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam</p>
                </div>
            </div>
            <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12 wow fadeInRight delay-04s">
                <div class="content">
                    <i class="flaticon-symbol"></i>
                    <h4>Commercial</h4>
                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam</p>
                </div>
            </div>
        </div>
        <a href="#" class="btn button-md button-theme">Read More</a>
    </div>
</div>
<!-- Our service end -->

<!-- Recently properties start -->
<div class="mrg-btm-70 recently-properties chevron-icon">
    <div class="container">
        <!-- Main title -->
        <div class="main-title">
            <h1><span>Recent</span> Properties</h1>
        </div>
        <div class="row">

            <div class="carousel our-partners slide" id="recent_properties">
                <div class="col-lg-12 mrg-btm-30">
                    <a class="right carousel-control" href="#recent_properties" data-slide="prev"><i class="fa fa-chevron-left icon-prev"></i></a>
                    <a class="right carousel-control" href="#recent_properties" data-slide="next"><i class="fa fa-chevron-right icon-next"></i></a>
                </div>
                <div class="carousel-inner">
                    <?php  $x = 0;  foreach( $properties as $property ) : ?>
                        <div class="item <?php if($x == 0) echo 'active' ?>">
                            <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
                                <!-- Property start -->
                                <div class="property">
                                    <!-- Property img -->
                                    <?php 
                                        $property_image = $this->property_model->fetch_featured_image( $property->pid );
                                        $src = !empty($property_image) ? base_url('assets/app/images/').$property_image->img_name : base_url('assets/app/images/my-properties-2.jpg'); 
                                    ?>
                                    <a href="<?= base_url( 'property/'. $property->pid .'/'. url_title(strtolower($property->title)) ); ?>" class="property-img">
                                        <img src="<?= $src; ?>" alt="<?= $property->title; ?>" class="img-responsive">
                                    </a>
                                    <!-- Property content -->
                                    <div class="property-content">
                                        <!-- title -->
                                        <h1 class="title">
                                            <a href="<?= base_url( 'property/'. $property->pid .'/'. url_title(strtolower($property->title)) ); ?>"><?= word_limiter(ucwords($property->title), 4, '...'); ?></a>
                                        </h1>
                                        <!-- Property address -->
                                        <h3 class="property-address">
                                            <a href="properties-details.php">
                                                <i class="fa fa-map-marker"></i><?= $property->address; ?>
                                            </a>
                                        </h3>
                                        <!-- Facilities List -->
                                        <ul class="facilities-list clearfix">
                                            <?php if(!empty($property->bedrooms) ) : ?>
                                            <li>
                                                <i class="flaticon-bed"></i>
                                                <span><?= $property->bedrooms; ?> Bed(s)</span>
                                            </li>
                                            <?php endif;  ?>
                                            <?php if(!empty($property->bathrooms) ) : ?>
                                            <li>
                                                <i class="flaticon-holidays"></i>
                                                <span><?= $property->bathrooms; ?> Bed(s)</span>
                                            </li>
                                            <?php endif;  ?>
                                            <!-- <?php if(!empty($property->bathrooms) ) : ?>
                                            <li>
                                                <i class="flaticon-vehicle"></i>
                                                <span>Parking lot (Yes)</span>
                                            </li>
                                            <?php endif;  ?> -->
                                        </ul>
                                        <!-- Property footer -->
                                        <div class="property-footer">
                                            <span class="left"><i class="fa fa-calendar-o icon"></i>&nbsp;<?= ago($property->postdate); ?></span>
                                            <span class="right">
                                                <?php
                                                // echo $property->id;                                                    
                                                    if( $this->session->userdata('logged_in') ) {
                                                        if($this->property_model->is_favourited($this->session->userdata('user_id'), $property->id ) ) { 
                                                ?>
                                                            <a href="#" class="fav" data-action="unfavpost" data-pid="<?= $property->id; ?>"><i class="fa fa-heart"></i></a>
                                                        <?php } else { ?>
                                                            <a href="#" class="fav" data-action="favpost" data-pid="<?= $property->id; ?>"><i class="fa fa-heart-o"></i></a>
                                                       <?php }
                                                    }else{ ?>
                                                        <a href="#" class="login"><i class="fa fa-heart-o"></i></a>
                                                    <?php } 
                                                ?>
                                                <a href="#"><i class="fa fa-share-alt"></i></a>                                               
                                            </span>
                                        </div>
                                    </div>
                                </div>
                                <!-- Property end -->
                            </div>
                        </div>

                    <?php $x++; endforeach; ?>
                </div> <!-- carousel inner -->
            </div><!-- carousel -->

        </div><!-- row -->
    </div>
</div>
<!-- Partners block end -->

<div class="clearfix"></div>
<!-- Categories strat -->
<div class="categories">
    <div class="container">
        <!-- Main title -->
        <div class="main-title">
            <h1><span>Popular</span> Places</h1>
        </div>
        <div class="clearfix"></div>
        <div class="row wow">
            <div class="col-lg-7 col-md-7 col-sm-12">
                <div class="row">
                    <div class="col-sm-6 col-pad wow fadeInLeft delay-04s">
                        <div class="category">
                            <div class="category_bg_box cat-1-bg">
                                <div class="category-overlay">
                                    <span class="category-content">
                                        <span class="category-title">Rumuokoro</span>
                                        <br>
                                        <span class="category-subtitle">140 Properties</span>
                                        <br>
                                        <a href="#" class="btn button-sm button-theme">View All</a>
                                    </span><!-- /.category-content -->
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-sm-6 col-pad wow fadeInLeft delay-04s">
                        <div class="category">
                            <div class="category_bg_box cat-2-bg">
                                <div class="category-overlay">
                                    <span class="category-content">
                                        <span class="category-title">Agip</span>
                                        <br>
                                        <span class="category-subtitle">19 Properties</span>
                                        <br>
                                         <a href="#" class="btn button-sm button-theme ">View All</a>
                                    </span>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-sm-12 col-pad wow fadeInUp delay-04s">
                        <div class="category">
                            <div class="category_bg_box cat-3-bg">
                                <div class="category-overlay">
                                    <span class="category-content">
                                        <span class="category-title">Rumuola</span>
                                        <br>
                                        <span class="category-subtitle">27 Properties</span>
                                        <br>
                                        <a href="#" class="btn button-sm button-theme ">View All</a>
                                    </span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-lg-5 col-md-5 col-sm-12 col-pad wow fadeInRight delay-04s">
                <div class="category">
                    <div class="category_bg_box category_long_bg cat-4-bg">
                        <div class="category-overlay">
                            <span class="category-content">
                                <span class="category-title">Choba</span>
                                <br>
                                <span class="category-subtitle">10 Properties</span>
                                <br>
                                 <a href="#" class="btn button-sm button-theme ">View All</a>
                            </span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Categories end-->



<!-- Testimonial section start-->
<div class="testimonial-section testimonial-2 testimonial-3">
    <div class="testimonial-section-inner">
        <div class="container">
            <div class="main-title">
                <h1>Testimonials</h1>
            </div>
            <div class="row">
                <div class="col-lg-12">
                    <div class="testimonials">
                        <div id="carouse3-example-generic" class="carousel slide" data-ride="carousel">
                            <!-- Indicators -->
                            <!-- Wrapper for slides -->
                            <div class="carousel-inner" role="listbox">
                                <div class="item content clearfix active">
                                    <div class="row">
                                        <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
                                            <div class="avatar">
                                                <img src="<?= base_url('assets/landing/img/avatar/avatar-1.png'); ?>" alt="avatar-1" class="img-responsive">
                                            </div>
                                        </div>
                                        <div class="col-lg-9 col-md-9 col-sm-9 col-xs-12">
                                            <div class="testimonials-info">
                                                <div class="text">
                                                    <sup>
                                                        <i class="fa fa-quote-left"></i>
                                                    </sup>
                                                    Aliquam dictum elit vitae mauris facilisis, at dictum urna dignissim. Donec vel lectus vel felis lacinia luctus vitae iaculis arcu. Mauris mattis, massa eu porta ultricies.
                                                    <sub>
                                                        <i class="fa fa-quote-right"></i>
                                                    </sub>
                                                </div>
                                                <div class="author-name">
                                                    John Antony
                                                </div>
                                                <ul class="rating">
                                                    <li>
                                                        <i class="fa fa-star"></i>
                                                    </li>
                                                    <li>
                                                        <i class="fa fa-star"></i>
                                                    </li>
                                                    <li>
                                                        <i class="fa fa-star"></i>
                                                    </li>
                                                    <li>
                                                        <i class="fa fa-star"></i>
                                                    </li>
                                                    <li>
                                                        <i class="fa fa-star-half-full"></i>
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="item content clearfix">
                                    <div class="row">
                                        <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
                                            <div class="avatar">
                                                <img src="<?= base_url('assets/landing/img/avatar/avatar-2.png'); ?>" alt="avatar-2" class="img-responsive">
                                            </div>
                                        </div>
                                        <div class="col-lg-9 col-md-9 col-sm-9 col-xs-12">
                                            <div class="testimonials-info">
                                                <div class="text">
                                                    <sup>
                                                        <i class="fa fa-quote-left"></i>
                                                    </sup>
                                                    Aliquam dictum elit vitae mauris facilisis, at dictum urna dignissim. Donec vel lectus vel felis lacinia luctus vitae iaculis arcu. Mauris mattis, massa eu porta ultricies.
                                                    <sub>
                                                        <i class="fa fa-quote-right"></i>
                                                    </sub>
                                                </div>
                                                <div class="author-name">
                                                    John Mery
                                                </div>
                                                <ul class="rating">
                                                    <li>
                                                        <i class="fa fa-star"></i>
                                                    </li>
                                                    <li>
                                                        <i class="fa fa-star"></i>
                                                    </li>
                                                    <li>
                                                        <i class="fa fa-star"></i>
                                                    </li>
                                                    <li>
                                                        <i class="fa fa-star"></i>
                                                    </li>
                                                    <li>
                                                        <i class="fa fa-star-half-full"></i>
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="item content clearfix">
                                    <div class="row">
                                        <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
                                            <div class="avatar">
                                                <img src="<?= base_url('assets/landing/img/avatar/avatar-4.png'); ?>" alt="avatar-4" class="img-responsive">
                                            </div>
                                        </div>
                                        <div class="col-lg-9 col-md-9 col-sm-9 col-xs-12">
                                            <div class="testimonials-info">
                                                <div class="text">
                                                    <sup>
                                                        <i class="fa fa-quote-left"></i>
                                                    </sup>
                                                    Aliquam dictum elit vitae mauris facilisis, at dictum urna dignissim. Donec vel lectus vel felis lacinia luctus vitae iaculis arcu. Mauris mattis, massa eu porta ultricies.
                                                    <sub>
                                                        <i class="fa fa-quote-right"></i>
                                                    </sub>
                                                </div>
                                                <div class="author-name">
                                                    John DOe
                                                </div>
                                                <ul class="rating">
                                                    <li>
                                                        <i class="fa fa-star"></i>
                                                    </li>
                                                    <li>
                                                        <i class="fa fa-star"></i>
                                                    </li>
                                                    <li>
                                                        <i class="fa fa-star"></i>
                                                    </li>
                                                    <li>
                                                        <i class="fa fa-star"></i>
                                                    </li>
                                                    <li>
                                                        <i class="fa fa-star-half-full"></i>
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="item content clearfix">
                                    <div class="row">
                                        <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
                                            <div class="avatar">
                                                <img src="<?= base_url('assets/landing/img/avatar/avatar-3.png') ?>" alt="avatar-3" class="img-responsive">
                                            </div>
                                        </div>
                                        <div class="col-lg-9 col-md-9 col-sm-9 col-xs-12 ">
                                            <div class="testimonials-info">
                                                <div class="text">
                                                    <sup>
                                                        <i class="fa fa-quote-left"></i>
                                                    </sup>
                                                    Aliquam dictum elit vitae mauris facilisis, at dictum urna dignissim. Donec vel lectus vel felis lacinia luctus vitae iaculis arcu. Mauris mattis, massa eu porta ultricies.
                                                    <sup>
                                                        <i class="fa fa-quote-right"></i>
                                                    </sup>

                                                </div>
                                                <div class="author-name">
                                                    Okoro Julius
                                                </div>
                                                <ul class="rating">
                                                    <li>
                                                        <i class="fa fa-star"></i>
                                                    </li>
                                                    <li>
                                                        <i class="fa fa-star"></i>
                                                    </li>
                                                    <li>
                                                        <i class="fa fa-star"></i>
                                                    </li>
                                                    <li>
                                                        <i class="fa fa-star"></i>
                                                    </li>
                                                    <li>
                                                        <i class="fa fa-star-half-full"></i>
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!-- Controls -->
                            <a class="left carousel-control" href="#carouse3-example-generic" role="button" data-slide="prev">
                                <span class="slider-mover-left" aria-hidden="true">
                                    <i class="fa fa-angle-left"></i>
                                </span>
                                <span class="sr-only">Previous</span>
                            </a>
                            <a class="right carousel-control" href="#carouse3-example-generic" role="button" data-slide="next">
                                 <span class="slider-mover-right" aria-hidden="true">
                                      <i class="fa fa-angle-right"></i>
                                 </span>
                                <span class="sr-only">Next</span>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Testimonial section end -->
<div class="clearfix"></div>

<!-- Counters strat -->
<?php $this->load->view('landing/includes/counter'); ?>
<!-- Counters end -->

<div class="partners-block">
    <div class="container">
        <h3>Brands & Partners</h3>
        <div class="row">
            <div class="col-md-12">
                <div class="carousel our-partners slide" id="ourPartners">
                    <div class="carousel-inner">
                        <div class="item active">
                            <div class="col-xs-12 col-sm-6 col-md-3">
                                <a href="#">
                                    <img src="<?= base_url('assets/landing/img/brand/afri1.png'); ?>" alt="">
                                </a>
                            </div>
                        </div>
                        <div class="item">
                            <div class="col-xs-12 col-sm-6 col-md-3">
                                <a href="#">
                                    <img src="<?= base_url('assets/landing/img/brand/afri1.png'); ?>" alt="">
                                </a>
                            </div>
                        </div>
                        <div class="item">
                            <div class="col-xs-12 col-sm-6 col-md-3">
                                <a href="#">
                                    <img src="<?= base_url('assets/landing/img/brand/tuts.png'); ?>" alt="">
                                </a>
                            </div>
                        </div>
                        <div class="item">
                            <div class="col-xs-12 col-sm-6 col-md-3">
                                <a href="#">
                                    <img src="<?= base_url('assets/landing/img/brand/afri1.png'); ?>" alt="">
                                </a>
                            </div>
                        </div>
                        <div class="item">
                            <div class="col-xs-12 col-sm-6 col-md-3">
                                <a href="#">
                                    <img src="<?= base_url('assets/landing/img/brand/afri1.png'); ?>" alt="">
                                </a>
                            </div>
                        </div>
                    </div>
                    <a class="left carousel-control" href="#ourPartners" data-slide="prev"><i class="fa fa-chevron-left icon-prev"></i></a>
                    <a class="right carousel-control" href="#ourPartners" data-slide="next"><i class="fa fa-chevron-right icon-next"></i></a>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Footer start -->
<?php $this->load->view('landing/includes/footer'); ?>
<!-- Footer end -->
<!-- Copy right start -->
<div class="copy-right">
    <div class="container">
        <?= lang('footer_text'); ?>
    </div>
</div>
<!-- Copy end right-->

<script type="text/javascript" src="<?= base_url('assets/landing/js/jquery-2.2.0.min.js'); ?>"></script>
<script type="text/javascript" src="<?= base_url('assets/landing/js/bootstrap.min.js'); ?>"></script>
<script type="text/javascript" src="<?= base_url('assets/landing/js/bootstrap-submenu.js'); ?>"></script>
<script type="text/javascript" src="<?= base_url('assets/landing/js/rangeslider.js'); ?>"></script>
<script type="text/javascript" src="<?= base_url('assets/landing/js/jquery.mb.YTPlayer.js'); ?>"></script>
<script type="text/javascript" src="<?= base_url('assets/landing/js/wow.min.js'); ?>"></script>
<script type="text/javascript" src="<?= base_url('assets/landing/js/bootstrap-select.min.js'); ?>"></script>
<script type="text/javascript" src="<?= base_url('assets/landing/js/jquery.easing.1.3.js'); ?>"></script>
<script type="text/javascript" src="<?= base_url('assets/landing/js/jquery.scrollUp.js'); ?>"></script>
<script type="text/javascript" src="<?= base_url('assets/landing/js/jquery.mCustomScrollbar.concat.min.js'); ?>"></script>
<script type="text/javascript" src="<?= base_url('assets/landing/js/leaflet.js'); ?>"></script>
<script type="text/javascript" src="<?= base_url('assets/landing/js/leaflet-providers.js'); ?>"></script>
<script type="text/javascript" src="<?= base_url('assets/landing/js/leaflet.markercluster.js'); ?>"></script>
<script type="text/javascript" src="<?= base_url('assets/landing/js/jquery.filterizr.js'); ?>"></script>
<script type="text/javascript" src="<?= base_url('assets/landing/js/maps.js'); ?>"></script>
<script type="text/javascript" src="<?= base_url('assets/landing/js/app.js'); ?>"></script>


<script type="text/javascript">
    $(document).ready(function() {
        $('.login').on('click', function(){
            swal({
                title: "Login",
                text: 'You need to login before favouriting',
                type: "info"
            }, function(isConfirm){
                window.location.href = "<?= base_url('login'); ?>";
            });
        });

        $('.fav').on('click', function(e) {
            e.preventDefault();
            thisClass = $(this);
            pid = $(this).attr('data-pid');
            action = $(this).attr('data-action');
            $.ajax({
                url: "<?php echo base_url('property/fav'); ?>",
                method: "POST",
                data: {pid:pid, action:action},
                success:function(data) {                    
                    if( data == true ){
                        if( action == 'favpost') {
                            thisClass.find("i").addClass('fa-heart');
                            thisClass.find("i").removeClass('fa-heart-o');
                            thisClass.attr('data-action', 'unfavpost');
                            swal({
                                title: "Success",
                                text: 'The post has been favourited, you can view it later on your dashboard',
                                type: "success"
                            });
                        }else {
                            thisClass.find("i").removeClass('fa-heart');
                            thisClass.find("i").addClass('fa-heart-o');
                            thisClass.attr('data-action', 'favpost');
                            swal({
                                title: "Success",
                                text: 'The post has been un-favourite.',
                                type: "info"
                            });
                        }
                    }else {
                        swal({
                            title: "Error",
                            text: 'Sorry there was an error performing that action, please try again, or refresh your browser.',
                            type: "error"
                        });
                    }
                }// success
            }); // ajax
        });

    });
</script>
</body>

</html>