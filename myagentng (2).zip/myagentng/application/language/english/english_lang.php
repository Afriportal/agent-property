<?php
// Website Config
$lang['site_name'] = 'Myagent.ng';

$lang['about_description'] = '';

$lang['site_keywords'] = 'Post events, promote events, sponsor event, broadcast event, events in nigeria, sell tickets, event nigeria, sell tickets in nigeria, Fashion Shows, Theatres, Comedy Shows, Clubs and Events in Lagos, Abuja, Port Harcourt and More. Buy and Sell Tickets Online and at our Various Outlets. Promote Your Events with Us. Find Out What\'s On In Lagos and What\'s Happening in Nigeria. Create and manage free and paid events. Find events around you, register for free, buy and sell tickets with ease and receive daily payouts. seminar, events, event software, online registration, festival ticketing, free event management, email invitations, event registration software, online event, closest event, buy ticket online, sell tickets, sell tickets online, online event ticketing, ticket management system, nigeria event ticket, payout, nigeria event';

$lang['site_description'] = 'Post events in Nigeria, free and paid events. Find events around you, register for free event, buy tickets, sell tickets online and promote your event in Nigeria.';

$lang['contact_address'] = 'Address: 70 Ada George Road, Port Harcourt, Rivers State.';

$lang['phone1'] = '2348059903903';

$lang['phone2'] = '2348169254598';

$lang['contact_email'] = 'sales@myagent.ng';

$lang['site_mail'] = 'info@myagent.ng';

$lang['about_us'] = "As Nigeria’s premier property portal, we're passionate about helping people find their desired homes. In addition, we provide Nigeria’s Real Estate Industry with a reliable transactional and marketing platform where home owners/ agents connect with home-buyers and renters searching for property online.";
$lang['disclaimer'] = "Nam mattis lobortis felis eu blandit. Morbi tellus ligula, interdum sit amet ipsum et, viverra hendrerit lectus. Nunc efficitur sem vel est laoreet, sed bibendum eros viverra. Vestibulum finibus, ligula sed euismod tincidunt, lacus libero lobortis ligula, sit amet molestie ipsum purus ut tortor. Nunc varius, dui et sollicitudin facilisis, erat felis imperdiet felis, et iaculis dui magna vitae diam. Donec mattis diam nisl, quis ullamcorper enim malesuada non. Curabitur lobortis eu mauris nec vestibulum. Nam efficitur, ex ac semper malesuada nisi odio consequat dui, hendrerit vulputate odio dui vitae massa. Aliquam tortor urna, tincidunt";

$lang['hear_about_us'] = 'Google search, Facebook, Twitter, Instagram, Friends, Posters & Handbills, Others';

$lang['footer_text'] = ' © ' . date('Y') . ' myAgent.ng | Trademarks and brands are the property of their respective owners. ';



$lang['special_urls'] = 'about, account, booking, contact, coupon, create, dashboard, event, events, faq, index, invite, listings, logins, logout, my, payout, pricing, print, home, privacy, recover, retrieve, lost, attendance, register, search, terms, thanks, thng, admin, administrator, cpanel, webmail, welcome, assets, css, javascript, php, abouts, accounts, bookings, contacts, coupons, creates, dashboards, events, eventss, faqs, indexs, invites, listingss, loginss, logouts, mys, payouts, pricings, prints, homes, privacys, recovers, registers, searchs, termss, thankss, thngs, admins, administrators, cpanels, webmails, welcomes, assetss, csss, javascripts, phps, ticket, tickethub, tickethubng, nigeria, earth, google, microsoft, facebook, page, pages, fuck, pussy, dick, cunt, sex, access, account, accounts, add, address, adm, admin, administration, adult, advertising, affiliate, affiliates, ajax, analytics, android, anon, anonymous, api, app, apps, archive, atom, auth, authentication, avatar, backup, banner, banners, bin, billing, blog, blogs, board, bot, bots, business, chat, cache, cadastro, calendar, campaign, careers, cgi, client, cliente, code, comercial, compare, config, connect, contact, contest, create, code, compras, css, dashboard, data, db, design, delete, demo, design, designer, dev, devel, dir, directory, doc, docs, domain, download, downloads, edit, editor, email, ecommerce, forum, forums, faq, favorite, feed, feedback, flog, follow, file, files, free, ftp, gadget, gadgets, games, guest, group, groups, help, home, homepage, host, hosting, hostname, html, http, httpd, https, hpg, info, information, image, img, images, imap, index, invite, intranet, indice, ipad, iphone, irc, java, javascript, job, jobs, js, knowledgebase, log, login, logs, logout, list, lists, mail, mail1, mail2, mail3, mail4, mail5, mailer, mailing, mx, manager, marketing, master, me, media, message, microblog, microblogs, mine, mp3, msg, msn, mysql, messenger, mob, mobile, movie, movies, music, musicas, my, name, named, net, network, new, news, newsletter, nick, nickname, notes, noticias, ns, ns1, ns2, ns3, ns4, old, online, operator, order, orders, page, pager, pages, panel, password, perl, pic, face, dick, pics, photo, photos, photoalbum, php, plugin, plugins, pop, pop3, post, postmaster, postfix, posts, profile, project, projects, promo, pub, public, python, random, register, registration, root, ruby, rss, sale, sales, sample, samples, script, scripts, secure, send, service, shop, sql, signup, signin, search, security, settings, setting, setup, site, sites, sitemap, smtp, soporte, ssh, stage, staging, start, subscribe, subdomain, suporte, support, stat, static, stats, status, store, stores, system, tablet, tablets, tech, telnet, test, test1, test2, test3, teste, tests, theme, themes, tmp, todo, task, tasks, tools, tv, talk, update, upload, url, user, username, usuario, usage, vendas, video, videos, visitor, win, ww, www, www1, www2, www3, www4, www5, www6, www7, wwww, wws, wwws, web, webmail, website, websites, webmaster, workshop, xxx, xpg, you, yourname, yourusername, yoursite, yourdomain, supportdetails, support-details, stacks, imulus, github, twitter, facebook, google, apple, about, account, activate, add, admin, administrator, api, app, apps, archive, archives, auth, blog, cache, cancel, careers, cart, changelog, checkout, codereview, compare, config, configuration, connect, contact, create, delete, direct_messages, documentation, download, downloads, edit, email, employment, enterprise, faq, favorites, feed, feedback, feeds, fleet, fleets, follow, followers, following, friend, friends, gist, group, groups, help, home, hosting, hostmaster, idea, ideas, index, info, invitations, invite, is, it, job, jobs, json, language, languages, lists, login, logout, logs, mail, map, maps, mine, mis, news, oauth, oauth_clients, offers, openid, order, orders, organizations, plans, popular, post, postmaster, privacy, projects, put, recruitment, register, remove, replies, root, rss, sales, save, search, security, sessions, settings, shop, signup, sitemap, ssl, ssladmin, ssladministrator, sslwebmaster, status, stories, styleguide, subscribe, subscriptions, support, sysadmin, sysadministrator, terms, tour, translations, trends, unfollow, unsubscribe, update, url, user, weather, webmaster, widget, widgets, wiki, ww, www, wwww, xfn, xml, xmpp, yaml, yml, chinese, mandarin, spanish, english, bengali, hindi, portuguese, russian, japanese, german, wu, javanese, korean, french, vietnamese, telugu, chinese, marathi, tamil, turkish, urdu, min-nan, jinyu, gujarati, polish, arabic, ukrainian, italian, xiang, malayalam, hakka, kannada, oriya, panjabi, sunda, panjabi, romanian, bhojpuri, azerbaijani, farsi, maithili, hausa, arabic, burmese, serbo-croatian, gan, awadhi, thai, dutch, yoruba, sindhi';



// URL
$lang['facebook_url'] = 'https://facebook.com/myagent';

$lang['twitter_url'] = 'https://twitter.com/myagent';

$lang['google-plus_url'] = '#';

$lang['instagram_url'] = 'https://instagram.com/myagent';

$lang['linkedin_url'] = '#';

$lang['address'] = '1 Adekunle Owobiyi Close, Ogba, Ikeja Lagos, Nigeria';
// Helper

$lang['ngn'] ='₦';

// Third Party Details

$lang['livecchat'] = 'liveperson';

$lang['pricing_display'] = '3.5% + N200';

$lang['pricing_percent'] = '3.5';

$lang['pricing_comm'] = '200';

$lang['pricing_limit'] = '4000';

$lang['payout_fee'] = '52.5';



$lang['banks'] = 'Access Bank Plc, Citibank Nigeria Limited, Diamond Bank Plc, Ecobank Nigeria Plc, Enterprise Bank , Fidelity Bank Plc, FIRST BANK NIGERIA LIMITED, First City Monument Bank Plc, Guaranty Trust Bank Plc, Heritage Banking Company Ltd, Key Stone Bank, MainStreet Bank, Skye Bank Plc, Stanbic IBTC Bank Ltd, Standard Chartered Bank Nigeria Ltd, Sterling Bank Plc, SunTrust Bank Nigeria Limited, Union Bank of Nigeria Plc, United Bank For Africa Plc, Unity Bank Plc, Wema Bank Plc, Zenith Bank Plc';

$lang['event_categories'] = 'Arts And Entertainment, Business And Networking, Charities And Non-profit, Education And Student Groups, Family or School Reunions, Health And Wellness, Museums And Cultural, Music, Outdoor And Recreational, Public Action And Political, Religion And Spirituality, Social Events And Clubs, Sports And Fitness';

$lang['type_of_property'] = 'Halls, Office space, Shops, Warehouses, Farm tanks, Workshops, Barges, Land, Apartment, House, Commercial, Detached building, Block of flats, High rice building, Ground floor, Apartment building, Bungalow, Others';


$lang['states'] = 'river state';

$lang['lga'] = 'Abua / Odual L.G.A, Ahoada East L.G.A, Ahoada West L.G.A, Akuku Toru L.G.A, Andoni L.G.A, Asari-Toru L.G.A, Bonny L.G.A, Degema L.G.A , Emohua L.G.A, Eleme L.G.A, Etche L.G.A, Gokona L.G.A, Ikwerre L.G.A, Khana L.G.A, Obia / Akpor L.G.A, Ogba / Egbema / Ndoni L.G.A, Ogu / Bolo L.G.A, Okrika L.G.A, Omumma L.G.A, Opobo / Nkoro L.G.A, Oyigbo L.G.A, Port-Harcourt L.G.A, Tai L.G.A';

$lang['payment_schedule'] = 'Monthly, Yearly, One-time';

$lang['numbers'] = '1, 2, 3, 4, 5, 6, 7, 8, 9, 10, More';

$lang['property_features'] = 'Packing Space, Veranda, Balcony, Store, Double Window, Single Window, Security Post, Nearness to IOC, Nearness to Police Station, Nearness to Water Body, Nearness to Market, Nearness to Bus Stop';

$lang['floor_type'] = 'Marble, Terazzo, Tiles, Others';

$lang['payment_period'] = 'Less than one year, one year, above one year';

$lang['landlord'] = 'yes, no';

$lang['state_of_building'] = 'newly built, renovated';

$lang['plan1'] = 'partnership, 2%, partnership fee, per property posted, post unlimited per month, contact details hidden, 2% partnership fee';
$lang['plan2'] = 'standard, 5000, per property, monthly, post one property per month, contact details hidden (by default), clients can request contact details';
$lang['plan3'] = 'premium, 20000, ---, 3 months, post unlimited property, contact details visible, property featured on home page';

?>