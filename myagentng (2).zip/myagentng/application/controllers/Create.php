<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Create extends CI_Controller {

	public function __construct(){
        parent::__construct();
        if($this->session->userdata('logged_in')) {
        	$dataProfile = $this->user_model->get_single($this->session->userdata('user_id'));
        	if ($dataProfile->user_active === 'pending') {
				$this->session->set_flashdata('error_msg','An activation link has been sent to your email! Please check and click on the link to activate your account');
				$this->session->set_userdata('referred_from', current_url());
				redirect('login');
			}			
		}else{
			redirect('login');
		} 
    }

	
	public function index(){

		$page_data['profile'] = $this->user_model->get_single($this->session->userdata('user_id'));
		if( $this->input->post() ) {
			// if(!empty($_FILES['property_image_upload']['name'])) {
			// 	echo count($_FILES['property_image_upload']['name']);
			// }else {
			// 	echo 'Not posted';
			// }
   //      	exit;
   //      	exit;
			
			$this->form_validation->set_rules('title','Property Title', 'trim|required|min_length[3]');
			$this->form_validation->set_rules('property_type','Property Type', 'trim|required');
			$this->form_validation->set_rules('price','Property Price', 'trim|is_numeric');
			$this->form_validation->set_rules('type_of_property', 'Type of property', 'trim|required');
			$this->form_validation->set_rules('payment_schedule', 'Payment Schedule', 'trim|required');
			$this->form_validation->set_rules('address', 'Property Address', 'trim|required');

			if( $this->form_validation->run() == FALSE ) {
				$this->session->set_flashdata('error_msg', validation_errors());
				redirect('create');
			}else {
				$pid = generate_code(); 
				$data = array(
					'uid' => $this->session->userdata('user_id'),
					'pid'	=> $pid,
					'title' => $this->input->post('title'),
					'property_type' => $this->input->post('property_type'),
					'price'	=> $this->input->post('price'),
					'type_of_property' => $this->input->post('type_of_property'),
					'payment_schedule' => $this->input->post('payment_schedule'),
					'bedrooms' => $this->input->post('no_of_bedrooms'),
					'bathrooms' => $this->input->post('no_of_bathrooms'),
					'description' => $this->input->post('property_description'),
					'building_age' => $this->input->post('building_age'),
					'toilets'	=> $this->input->post('no_of_toilets'),
					'storey_building' => $this->input->post('no_of_storey'),
					'floor_type' => $this->input->post('floor_type'),
					'payment_period' => $this->input->post('payment_period'),
					'landlord' => $this->input->post('landlord'),
					'state_of_building' => $this->input->post('state_of_building'),
					'address' => $this->input->post('address'),
					'landmark' => $this->input->post('landmark'),
					'state' => $this->input->post('state'),
					'lga' => $this->input->post('lga'),
					'status' => 'pending'
				);

				if( !empty($this->input->post('property_features')) ) $data['features'] = implode(',', $this->input->post('property_features'));
				// Loop through the images	        		        

		        if( $this->property_model->insert_data('property', $data) ) {	

		        	if( isset($_FILES) ) {
		        		$counts = sizeof($_FILES['property_image_upload']['tmp_name']);	
			        	// exit;
			        	// die($counts);
						$image_data = array( 
							'uid' => $this->session->userdata('user_id'),
							'pid' => $pid,
							'primary_image' => 'false'
						);
						$files = $_FILES;
						for( $x = 0 ; $x < $counts; $x++) {
							$_FILES['property_image_upload']['name']= $files['property_image_upload']['name'][$x];
					        $_FILES['property_image_upload']['type']= $files['property_image_upload']['type'][$x];
					        $_FILES['property_image_upload']['tmp_name']= $files['property_image_upload']['tmp_name'][$x];
					        $_FILES['property_image_upload']['error']= $files['property_image_upload']['error'][$x];
					        $_FILES['property_image_upload']['size']= $files['property_image_upload']['size'][$x]; 
							$filename = $this->do_upload('property_image_upload');
							if ($filename) {
				            	$image_data['img_name'] = $filename['file_name'];
				            	$this->load->library('image_moo');
				            	$this->image_moo
									->load('./assets/app/images/'.$filename['file_name'])
						    		->make_watermark_text("myagent.ng", "./system/fonts/texb.ttf", 60, "#ff5a19")
						    		->resize(294)
						    		->watermark(3)
						    		->set_watermark_transparency(80)
						    		->save('./assets/app/images/'.$filename['file_name'], TRUE);
						    		// Thumbnail
						    		$this->image_moo
									->load('./assets/app/images/'.$filename['file_name'])
						    		->resize(90)
						    		->save('./assets/app/images/thumbnail/'.$filename['file_name'], TRUE);
								$this->property_model->insert_data('property_images', $image_data);
				            }
						}
						$this->session->set_flashdata('success_msg', 'Property posted successfully, awaiting admin approval.');

		        	}else{
						$this->session->set_flashdata('success_msg', 'Property posted successfully, awaiting admin approval. Add a featured image to this property to attract more audience.');
		        	}
		        	
		        }else {
		        	$this->session->set_flashdata('success_msg', 'There was an error posting your event, please try again, if error persist contact support!');
		        }
		        redirect('create');				
			}
		}else {
			$this->load->view('app/create', $page_data);
		}
		
	}

	public function do_upload($file ){
		// die('You came here' . $file);
        $config['upload_path']          = './assets/app/images/';
        $config['allowed_types']        = 'gif|jpg|png|JPEG|jpeg|bmp';
        $config['max_size']             = 10048;
        $config['max_width']            = 5600;
        $config['max_height']           = 5600;
        $config['overwrite']			= true;
        $config['encrypt_name'] 		= TRUE;			
		
        $this->load->library('upload', $config);
        if ( ! $this->upload->do_upload( $file )){
            $error = array('error_msg' => $this->upload->display_errors());
            $this->session->set_flashdata($error);
            return false;
        }
        else{
            return $this->upload->data();
        }
    }

}
