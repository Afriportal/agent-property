<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Forgot extends CI_Controller {
	public function __construct(){
        parent::__construct();
        if($this->session->userdata('logged_in')) {
        	$dataProfile = $this->user_model->get_single($this->session->userdata('user_id'));
        	if ($dataProfile->user_active === 'pending') {
				$this->session->set_flashdata('error_msg','An activation link has been sent to your email! Please check and click on the link to activate your account');
				$this->session->set_userdata('referred_from', current_url());
				redirect('login');
			}
		}
    }

	public function index() {
		$page_data['page_title'] = 'Recover Page';
		$page_data['pg_name'] = 'forgot';

		$page_data['meta_title'] = 'Recover Your Myagent.ng Password';
		$page_data['meta_description'] = 'Forgetten your password? No problem... Recover your password within minutes on Myagent.ng';
		$page_data['meta_keywords'] = lang('site_keywords');
		$page_data['meta_image'] = base_url('assets/notice.png');

		$this->load->view('landing/forgot-password', $page_data);
	}

	public function reset() {
		$page_data['page_title'] = 'Create New Password';
		$page_data['pg_name'] = 'forgot';

		$page_data['meta_title'] = 'Recover Your Tickethub.ng Password';
		$page_data['meta_description'] = '';
		$page_data['meta_keywords'] = lang('site_keywords');
		$page_data['meta_image'] = base_url('assets/notice.png');

		if (!$this->session->userdata('email')) redirect('forgot');

		if ($this->input->post()) {
			// svdvsd/
			$this->form_validation->set_rules('password','New Password', 'trim|required|min_length[3]');
			$this->form_validation->set_rules('password2','Confirm Password', 'trim|required|min_length[3]|matches[password]');

			if ($this->form_validation->run() == FALSE) {
				$this->session->set_flashdata('error_msg', validation_errors());
			} else {
				$password = $this->input->post('password');
				$email = $this->session->userdata('email');
				$where = array('email'=> $email);
				$user = $this->event_model->get_by_email('users', $where)->row();

				if ($this->user_model->change_password($password, $user->id)) {
					$user_id = $this->user_model->login_user($email, $password);

					if ($user_id) {
						$user_data = array(
							'user_type' => $user->user_type,
							'user_id' => $user_id,
							'email' => $email,
							'logged_in' => true
						);

						$this->session->set_userdata($user_data);

						$this->user_model->last_login();
						$this->session->set_flashdata('success_msg','You are now logged in! Welcome to your dashboard');
						if ($this->session->userdata('referred_from')) {
							$referred_from = $this->session->userdata('referred_from');
							redirect($referred_from);
						} else {
							// direct to user_type
							redirect('dashboard');
						}
					} else {
						$this->session->set_flashdata('error_msg','Incorrect Details! Try Again');
						redirect('login');
					}
				} else {
					$this->session->set_flashdata('error_msg','Sorry! The password update failed');
				}			
			}

			redirect('forgot/reset');
		}

		$this->load->view('landing/forgot-password', $page_data);
	}

	public function a()	{
		if (isset($_GET['t']) && !empty($_GET['t']) && isset($_GET['e']) && !empty($_GET['e'])) {
			$activation_token = cleanit($_GET['t']);
			$email = cleanit($_GET['e']);
			if ($this->user_model->activate_account($activation_token, $email)){
				$this->session->set_userdata('email',$email);
				$this->session->set_flashdata('success_msg', 'Activation confirmed! Now set a new password');
				redirect('forgot/reset/');
			}else {
				$this->session->set_flashdata('error_msg', 'Incorrect activation link, please contact our support team for more assistance.');
			}
		}
		redirect('forgot');
	}

	public function process(){
		$this->form_validation->set_rules('email','Email Address', 'trim|required|min_length[3]|valid_email');
		$email = cleanit($this->input->post('email'));

		if ($this->form_validation->run() == FALSE) {
			$dataMsg = array(
				'error_msg' => validation_errors()
			);
			$this->session->set_flashdata($dataMsg);
			redirect('forgot');

		} else {
			$activation_token = generate_token(25);
			$where = array('email'=>$email);
			$user_valid = $this->user_model->get_by_email('users', $where);
			$data = array(
				'activation_token' => $activation_token
			);
			$update_token = $this->user_model->update_data('users', $data, $where);

			if ($user_valid->num_rows() > 0 && $update_token) {
				$activation_link = base_url().'forgot/a?t='.$activation_token.'&e='.$email;
				$subject = 'Recovery mail for your myagent account';
				$message = "Hello " . $user_valid->row()->name . ", \n\r We got your request about changing your password. Please <a href='". $activation_link. "'>Click here to verify</a>\n\rIf you did not make this request, kindly ignore this mail, your account is safe.\n\r Regards, \n\rMyagent.ng Team.";

				if ($this->email_model->welcome_email($email, $subject, $message)) 
					$this->session->set_flashdata('success_msg','A recovery link has been sent to your email... Please check your email for the recovery link to complete the process!');
				redirect('forgot');	
			} else {
				$this->session->set_flashdata('error_msg','Email doest not exist in our records');
				redirect('forgot');
			}
		}

	}

	// Auto login te user
	public function autoLogin($email = '')
	{
		$user = $this->user_model->get_email(urldecode($email));

		if ($user) {
			$user_data = array(
				'user_id' => $user->id,
				'email' => $user->email,
				'logged_in' => true
			);

			$this->session->set_userdata($user_data);

			$this->user_model->last_login();
			$this->session->set_flashdata('success_msg','Congrats! Your account has been activated, welcome to your dashboard');
			redirect('dashboard');
		} else {
			$this->session->set_flashdata('error_msg', 'Incorrect activation link, please contact our support team for more assistance.');
			redirect('register');
		}
	}
}
