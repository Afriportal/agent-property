<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class About extends CI_Controller {

	public function index(){
		$page_data['page_title'] = 'Myagent.ng';
		$page_data['pg_name'] = 'about';

		$page_data['meta_title'] = 'Welcome to myagent.ng';
		$page_data['meta_description'] = 'Join myAgent.ng to post your properties for free in Nigeria';
		$page_data['meta_keywords'] = lang('site_keywords').$page_data['meta_description'];
		$page_data['meta_image'] = base_url('assets/notice.png');
		$page_data['profile'] = $this->user_model->get_single($this->session->userdata('user_id'));
		$this->load->view('landing/about', $page_data);
	}

}
