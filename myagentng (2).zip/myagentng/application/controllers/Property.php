<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Property extends CI_Controller {

	public function index(){
		$page_data['page_title'] = 'Myagent.ng';
		$page_data['pg_name'] = 'about';

		$page_data['meta_title'] = 'Welcome to myagent.ng';
		$page_data['meta_description'] = 'Join myAgent.ng to post your properties for free in Nigeria';
		$page_data['meta_keywords'] = lang('site_keywords').$page_data['meta_description'];
		$page_data['meta_image'] = base_url('assets/notice.png');
		$page_data['profile'] = $this->user_model->get_single($this->session->userdata('user_id'));

		$property_id = xss_clean($this->uri->segment(2));
		$property_id = preg_replace('#[^0-9]#i','',$property_id);
		// some check 
		$page_data['property'] = $this->property_model->single_property( $property_id );
		if( $page_data['property'] ) {
			$page_data['relateds'] = $this->property_model->related_property( $property_id, array(
				'property_type' => $page_data['property']['property_type'],
				'type_of_property' => $page_data['property']['type_of_property'],
				'description' => $page_data['property']['description']
			) );
			$page_data['recents'] = $this->property_model->recent_property( $property_id );
			$this->add_count( $property_id );
			$this->load->view('landing/property_details', $page_data);
		}else {
			redirect(base_url());
		}
	}

	function add_count($id){
		// load cookie helper
		$this->load->helper('cookie');
		// this line will return the cookie which has id name
		$check_visitor = $this->input->cookie(urldecode($id), FALSE);
		// get the visitor Ip address
		$ip = $this->input->ip_address();
	    if ($check_visitor == false) { // the visitor does not exist
	        $cookie = array(
	            "name"   => urldecode($id),
	            "value"  => "$ip",
	            "expire" =>  time() + 7200,
	            "secure" => false
	        );
	        $this->input->set_cookie($cookie);
	        $this->property_model->add_count($id);            
	    }
	}

	public function fav() {
		if( $this->input->post()) {
			// $action = ($this->input->post('action') == 'favpost')
			if( $this->property_model->favourite( $this->input->post('pid'), $this->input->post('action'))) {
				echo true;
			}else {
				echo false;
			}
		}else{
			redirect(base_url());
		}
	}

}
