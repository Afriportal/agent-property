<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Register extends CI_Controller {
	public function __construct(){
        parent::__construct();
        if($this->session->userdata('logged_in')) {
        	$dataProfile = $this->user_model->get_single($this->session->userdata('user_id'));
        	if ($dataProfile->user_active === 'pending') {
				$this->session->set_flashdata('error_msg','An activation link has been sent to your email! Please check and click on the link to activate your account');
				$this->session->set_userdata('referred_from', current_url());
				redirect('login');
			}
			if( $dataProfile->user_active === 'active' ){
				redirect(base_url());
			}
		} 
    }

	public function index() {
		$page_data['page_title'] = 'Create an account';
		$page_data['pg_name'] = 'register';

		$page_data['meta_title'] = 'Register on Tickethub.ng';
		$page_data['meta_description'] = 'Join myAgent.ng to post your properties for free in Nigeria';
		$page_data['meta_keywords'] = lang('site_keywords').$page_data['meta_description'];
		$page_data['meta_image'] = base_url('assets/notice.png');

		$this->load->view('landing/signup', $page_data);
	}

	public function a()	{
		if (isset($_GET['t']) && !empty($_GET['t']) && isset($_GET['e']) && !empty($_GET['e'])) {
			$activation_token = cleanit($_GET['t']);
			$email = cleanit($_GET['e']);
			if ($this->user_model->activate_account($activation_token, $email)){
				// redirect('register/autoLogin/'.urlencode($email));
				$user = $this->user_model->get_email($email);
				$user_data = array(
					'user_id' => $user->id,
					'email' => $user->email,
					'logged_in' => true
				);

				$this->session->set_userdata($user_data);

				$this->user_model->last_login();
				$this->session->set_flashdata('success_msg','You are now logged in! Welcome to your dashboard');
				if ($this->session->userdata('referred_from')) {
					$referred_from = $this->session->userdata('referred_from');
					redirect($referred_from);
				} else {
					redirect('dashboard');
				}
			}else {
				$this->session->set_flashdata('error_msg', 'Incorrect activation link, please contact our support team for more assistance.');
			}
		}
		redirect('register');
	}

	public function process(){
		$this->form_validation->set_rules('user_type','User type', 'trim|required|min_length[3]');
		$this->form_validation->set_rules('email','Email Address', 'trim|required|min_length[3]|valid_email|is_unique[users.email]',array('is_unique' => 'Sorry! This %s has already been registered! Please login on that account'));
		$this->form_validation->set_rules('password','Password', 'trim|required|min_length[3]');
		$this->form_validation->set_rules('confirm_Password','Repeat Password', 'trim|required|min_length[3]|matches[password]');

		$usname = cleanit($this->input->post('username'));

		if ($this->form_validation->run() == FALSE) {
			$dataMsg = array(
				'error_msg' => validation_errors()
			);
			$this->session->set_flashdata($dataMsg);

		} else {
			$activation_token = generate_token(25);
			$data = array(
				'email'	=> cleanit($this->input->post('email')),
				'pwd' => cleanit($this->input->post('password')),
				'source' => cleanit($this->input->post('source')),
				'activation_token' => $activation_token,
				'user_active' => 'pending',
				'user_type' => $this->input->post('user_type'),
				'date_registered' => get_now()
			);
			$return = $this->user_model->register_user($data);
			if( $return != false ){
				$session_data = array('user_id' => $return );
				$this->session->set_userdata($session_data);
				$this->user_model->last_login();
				$token = generate_token(25);
				$activation_link = base_url().'register/a?t='.$token.'&e='.$this->input->post('email');
				$message = "Hi, \n\r Welcome to Myagent.ng, we are glad to have you.\n\r Please verify your account to get started. <a href='".$activation_link."'>Verify Account</a>\n\r Regards,\n\rMyagent Team.";
				if ($this->email_model->welcome_email($this->input->post('email'), 'Verify your myagent.ng account', $message)) 
					$this->session->set_flashdata('success_msg','Congrats! Your registration was successful. Please check your email for an activation link to complete your registration!');				
				// $this->autoLogin($this->input->post('username'), $this->input->post('password'));
					redirect(base_url().'login');				
			}else {
				$this->session->set_flashdata('error_msg','Sorry! An error occured with your registration');
			}
		}
		redirect(base_url().'register');

	}

	// Auto login te user
	// public function autoLogin($email = '')
	// {
	// 	$user = $this->user_model->get_email(urldecode($email));

	// 	if ($user) {
	// 		$user_data = array(
	// 			'user_id' => $user->id,
	// 			'email' => $user->email,
	// 			'logged_in' => true
	// 		);

	// 		$this->session->set_userdata($user_data);

	// 		$this->user_model->last_login();
	// 		$this->session->set_flashdata('success_msg','Congrats! Your account has been activated, welcome to your dashboard');
	// 		redirect('dashboard');
	// 	} else {
	// 		$this->session->set_flashdata('error_msg', 'Incorrect activation link, please contact our support team for more assistance.');
	// 		redirect('register');
	// 	}
	// }
}
