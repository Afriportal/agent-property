<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login extends CI_Controller {
	public function __construct(){
        parent::__construct();
        if($this->session->userdata('logged_in')) {
        	$dataProfile = $this->user_model->get_single($this->session->userdata('user_id'));
        	if ($dataProfile->user_active === 'pending') {
				$this->session->set_flashdata('error_msg','An activation link has been sent to your email! Please check and click on the link to activate your account');
				$this->session->set_userdata('referred_from', current_url());
				redirect('login');
			}
			if( $dataProfile->user_active === 'active' ){
				redirect(base_url());
			}
		}
    }

	public function index() {
		$page_data['page_title'] = 'Login Page';
		$page_data['pg_name'] = 'login';

		$page_data['meta_title'] = 'Login Myagent.ng';
		$page_data['meta_description'] = 'Login to your account to manage your property listed, and post new property for free.';
		$page_data['meta_keywords'] = lang('site_keywords');
		$page_data['meta_image'] = base_url('assets/notice.png');

		$this->load->view('landing/login', $page_data);
	}

	public function process(){
		$this->form_validation->set_rules('email','Email Address', 'trim|required');
		$this->form_validation->set_rules('password','Password', 'trim|required');

		if ($this->form_validation->run() == FALSE) {
			$dataMsg = array(
				'error_msg' => validation_errors()
			);
			$this->session->set_flashdata($dataMsg);
			redirect('login');

		} else {

			$email = $this->input->post('email');
			$password = $this->input->post('password');

			$user_id = $this->user_model->login_user($email, $password);
			$profile = $this->user_model->get_single($user_id);
			if ($user_id) {
				$user_data = array(
					'user_id' => $user_id,
					'email' => $email,
					'logged_in' => true,
					'user_type' => $profile->user_type
				);

				$this->session->set_userdata($user_data);
				$this->user_model->last_login();
				$this->session->set_flashdata('success_msg','You are now logged in! Welcome to your dashboard');
				if ($this->session->userdata('referred_from')) {
					$referred_from = $this->session->userdata('referred_from');
					redirect($referred_from);
				} else {
					if( $profile->user_type === 'admin' ) {
						redirect('admin');
					}else {
						redirect($profile->user_type);
					}
				}
			} else {
				$this->session->set_flashdata('error_msg','Incorrect Details! Try Again');
				redirect('login');
			}

		}
	}
}
