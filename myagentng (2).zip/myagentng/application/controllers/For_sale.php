<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class For_sale extends CI_Controller {

	public function index() {
		$page_data['page_title'] = 'Myagent.ng';
		$page_data['pg_name'] = 'for_sale';
		$sort = '';

		$page_data['meta_title'] = 'Welcome to myagent.ng';
		$page_data['meta_description'] = 'Join myAgent.ng to post your properties for free in Nigeria';
		$page_data['meta_keywords'] = lang('site_keywords').$page_data['meta_description'];
		$page_data['meta_image'] = base_url('assets/notice.png');
		$page_data['profile'] = $this->user_model->get_single($this->session->userdata('user_id'));
		$page_data['recents'] = $this->property_model->recent_property();
		$num_rows = $this->property_model->fetch_num_rows( 'property', array('property_type' => 'for sale') );
		$this->config->load('pagination');
        $config = $this->config->item('pagination');
        $config['base_url'] = current_url() ;
        $config['total_rows'] = $num_rows;
        $config['per_page'] = 10;    
        $config["num_links"] = $config["total_rows"]; 

        $this->pagination->initialize($config); 
        $page = isset($_GET['page']) ?  xss_clean($_GET['page']) : 0;
		$page_data['properties'] = $this->property_model->fetch_properties_by_type('for sale', $config['per_page'], $page, $sort);

        $page_data['pagination'] = $this->pagination->create_links();
		$this->load->view('landing/for_rent', $page_data);
	}

}
