<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Search extends CI_Controller {

	public function index(){
		$page_data['page_title'] = 'Myagent.ng';
		$page_data['pg_name'] = 'search';

		$page_data['meta_title'] = 'Welcome to myagent.ng';
		$page_data['meta_description'] = 'Join myAgent.ng to post your properties for free in Nigeria';
		$page_data['meta_keywords'] = lang('site_keywords').$page_data['meta_description'];
		$page_data['meta_image'] = base_url('assets/notice.png');
		$page_data['recents'] = $this->property_model->recent_property();
		$page_data['profile'] = $this->user_model->get_single($this->session->userdata('user_id'));

		$sort = '' ;
		//Get method
		$data = array();
		if( $this->input->get_post('lga',TRUE) ) $data['lga'] = cleanit($this->input->get_post('lga'));
		if( $this->input->get_post('property_type', TRUE) ) $data['property_type'] = cleanit($this->input->get_post('property_type'));
		if( $this->input->get_post('type_of_property', TRUE) ) $data['type_of_property'] = cleanit($this->input->get_post('type_of_property'));
		

		$num_rows = $this->property_model->search_properties_rows( $data );
		// var_dump( $data );
		$this->config->load('pagination');
        $config = $this->config->item('pagination');
        $config['base_url'] = current_url() ;
        $config['total_rows'] = $num_rows;
        $config['per_page'] = 10;    
        $config["num_links"] = $config["total_rows"]; 

        $this->pagination->initialize($config); 
        $page = isset($_GET['page']) ?  xss_clean($_GET['page']) : 0;
        $page_data['searchs'] = $this->property_model->search_properties( $data, $config['per_page'], $page, $sort );
        // var_dump($searchs)
        $page_data['pagination'] = $this->pagination->create_links();

		$this->load->view('landing/search_results', $page_data);
	}

}
