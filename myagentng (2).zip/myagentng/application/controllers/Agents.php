<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Agents extends CI_Controller {

    protected $dataProfile = '';
	public function __construct(){
        parent::__construct();
        if($this->session->userdata('logged_in')) {
        	$dataProfile = $this->user_model->get_single($this->session->userdata('user_id'));
        	if ($dataProfile->user_active === 'pending') {
				$this->session->set_flashdata('error_msg','An activation link has been sent to your email! Please check and click on the link to activate your account');
				$this->session->set_userdata('referred_from', current_url());
				redirect('login');
			}			
		}else{
			redirect(base_url());
		} 
    }

	public function index(){
		$page_data['page_title'] = 'Myagent.ng';
		$page_data['pg_name'] = 'dashboard';

		$page_data['meta_title'] = 'Welcome to myagent.ng';
		$page_data['meta_description'] = 'Join myAgent.ng to post your properties for free in Nigeria';
		$page_data['meta_keywords'] = lang('site_keywords').$page_data['meta_description'];
		$page_data['meta_image'] = base_url('assets/notice.png');
		$page_data['profile'] = $this->user_model->get_single($this->session->userdata('user_id'));
		$this->load->view('app/properties', $page_data);		
	}

	public function profile(){
		$page_data['page_title'] = 'Myagent.ng';
		$page_data['pg_name'] = 'profile';

		$page_data['meta_title'] = 'Welcome to myagent.ng';
		$page_data['meta_description'] = 'Join myAgent.ng to post your properties for free in Nigeria';
		$page_data['meta_keywords'] = lang('site_keywords').$page_data['meta_description'];
		$page_data['meta_image'] = base_url('assets/notice.png');
		$page_data['profile'] = $this->user_model->get_single($this->session->userdata('user_id'));
		$this->form_validation->set_rules('name','Name', 'trim|required|min_length[3]');
		$this->form_validation->set_rules('phone','Phone number', 'trim|required|is_numeric');
		$this->form_validation->set_rules('about','About', 'trim|min_length[10]');
		$this->form_validation->set_rules('office_address', 'Office Address', 'trim|min_length[10]|required');
		$this->form_validation->set_rules('company_name', 'Company name', 'trim|required|min_length[5]');

		if( $this->form_validation->run() == FALSE ) {
			$this->session->set_flashdata('error_msg', validation_errors());
			$this->load->view('app/profile', $page_data);
		}else {
			$data = array(
				'name' => $this->input->post('name'),
				'phone' => $this->input->post('phone'),
				'about'	=> cleanit($this->input->post('about')),
				'office_address' => $this->input->post('office_address'),
				'company_name' => $this->input->post('company_name'),
			);


			$file1 = base_url('assets/app/images/'. $page_data['profile']->avatar);
			if (!empty($_FILES['profile_image']['name'])) {
				// die('yes');

				$dataupd['profile_image'] = $this->do_upload(true);
	            if ($dataupd['profile_image']) {
	            	$this->load->library('image_moo');
	            	$data['avatar'] = $dataupd['profile_image'];

	            	$file2 = base_url('assets/app/images/'.$data['avatar']);
	            	if (md5_file($file1) === md5_file($file2)) {
		            	// skip
	            	} else {
	            		// unset file1
	            		// unlink($file1);
		            	$this->load->library('image_moo');
		            	$this->image_moo
							->load('./assets/app/images/'.$data['avatar'])
				    		->make_watermark_text("myagent.ng", "./system/fonts/texb.ttf", 55, "#ff5a19")
				    		->watermark(3)
				    		->set_watermark_transparency(80)
				    		->save('./assets/app/images/'.$data['avatar'], TRUE);
					}

	            } else {
	            	redirect( $page_data['profile']->user_type .'/profile' );
	            }
	        }

	        if (!empty($_FILES['license_file']['name'])) {
				$dataupd['license_file'] = $this->do_upload(false);
	            if ($dataupd['license_file']) {
	            	$data['license_file'] = $dataupd['license_file'];
	            } else {
	            	redirect( $page_data['profile']->user_type .'/profile' );
	            }
	        }

	        if( $this->user_model->update_data('users', $data , array('id' => $this->input->post('uid'))) ) {
	        	// Updated successfully
	        	$this->session->set_flashdata('success_msg', 'Your profile has been updated successfully!');
	        }else {
	        	$this->session->set_flashdata('error_msg', 'There was an error updating your profile!');
	        }
	        redirect(current_url());
		}// else		
	}

	
	public function favourited(){
		$page_data['page_title'] = 'Myagent.ng';
		$page_data['pg_name'] = 'favourited';

		$page_data['meta_title'] = 'Welcome to myagent.ng';
		$page_data['meta_description'] = 'Join myAgent.ng to post your properties for free in Nigeria';
		$page_data['meta_keywords'] = lang('site_keywords').$page_data['meta_description'];
		$page_data['meta_image'] = base_url('assets/notice.png');
		$page_data['profile'] = $this->user_model->get_single($this->session->userdata('user_id'));
		$page_data['favourite'] = $this->user_model->get_user_favourited($this->session->userdata('user_id'));
		$this->load->view('app/favourited', $page_data);
	}

	public function notifications(){
		$page_data['page_title'] = 'Myagent.ng';
		$page_data['pg_name'] = 'notifications';
		$page_data['meta_title'] = 'Welcome to myagent.ng';
		$page_data['meta_description'] = 'Join myAgent.ng to post your properties for free in Nigeria';
		$page_data['meta_keywords'] = lang('site_keywords').$page_data['meta_description'];
		$page_data['meta_image'] = base_url('assets/notice.png');
		$page_data['notifications'] = $this->user_model->get_notifications( $this->session->userdata('user_id') );
		$page_data['profile'] = $this->user_model->get_single($this->session->userdata('user_id'));
		$this->load->view('app/notification', $page_data);
	}

	public function pricing(){
		$page_data['page_title'] = 'Myagent.ng';
		$page_data['pg_name'] = 'pricing';

		$page_data['meta_title'] = 'Welcome to myagent.ng';
		$page_data['meta_description'] = 'Join myAgent.ng to post your properties for free in Nigeria';
		$page_data['meta_keywords'] = lang('site_keywords').$page_data['meta_description'];
		$page_data['meta_image'] = base_url('assets/notice.png');
		$page_data['profile'] = $this->user_model->get_single($this->session->userdata('user_id'));
		$this->load->view('app/pricing', $page_data);
	}

	public function change_password(){
		$page_data['page_title'] = 'Myagent.ng';
		$page_data['pg_name'] = 'change_password';

		$page_data['meta_title'] = 'Welcome to myagent.ng';
		$page_data['meta_description'] = 'Join myAgent.ng to post your properties for free in Nigeria';
		$page_data['meta_keywords'] = lang('site_keywords').$page_data['meta_description'];
		$page_data['meta_image'] = base_url('assets/notice.png');
		$page_data['profile'] = $this->user_model->get_single($this->session->userdata('user_id'));

		$this->form_validation->set_rules('current_password','Current Password', 'trim|required');
		$this->form_validation->set_rules('new_password','Password', 'trim|required');
		$this->form_validation->set_rules('password_confirm','Password Confirm', 'trim|matches[new_password]|required');
		if( $this->form_validation->run() == false ) {
			$this->session->set_flashdata('error_msg', validation_errors());
			$this->load->view('app/change-password', $page_data);
		}else{
			$password = $this->input->post('current_password');
			$email = $this->session->userdata('email');
			$where = array('email'=> $email);
			// $user = $this->event_model->get_by_email('users', $where)->row();
			$user_id = $this->user_model->login_user($email, $password);

			if($user_id != false){
				if ($this->user_model->change_password($password, $user_id)) {
					$this->session->set_flashdata('success_msg','Your password has been re-setted successefully!');
					redirect($page_data['profile']->user_type .'/change_password' );
				} else {
					$this->session->set_flashdata('error_msg','Paassword update failed, please try again later.');
					redirect($page_data['profile']->user_type .'/change_password' );
				}
			}else {
				$this->session->set_flashdata('error_msg','Incorrect Details! Try Again');
				redirect($page_data['profile']->user_type .'/change_password' );
			}
		}
	}


	public function do_upload($is_image = true ){
		if( !$is_image ) {
			$config['upload_path']          = './assets/app/files/';
	        $config['allowed_types']        = 'pdf|doc|docx';
	        $config['max_size']             = 10048;
	        $config['overwrite']			= true;
	        $config['encrypt_name'] 		= TRUE;


		}else {
	        $config['upload_path']          = './assets/app/images/';
	        $config['allowed_types']        = 'gif|jpg|png|JPEG|jpeg|bmp';
	        $config['max_size']             = 10048;
	        $config['max_width']            = 5600;
	        $config['max_height']           = 5600;
	        $config['overwrite']			= true;
	        $config['encrypt_name'] 		= TRUE;			
		}
        $this->load->library('upload', $config);
        if( $is_image ){
        	if ( ! $this->upload->do_upload('profile_image')){
                $error = array('error_msg' => $this->upload->display_errors());
                $this->session->set_flashdata($error);
                return false;
	        }else{
	            $data = array('upload_data' => $this->upload->data());
	            return $this->upload->data('file_name');
	            // return $this->upload->data();
	        }
        }else {
        	if ( ! $this->upload->do_upload('license_file')){
                $error = array('error_msg' => $this->upload->display_errors());
                $this->session->set_flashdata($error);
                return false;
	        }else{
	            $data = array('upload_data' => $this->upload->data());
	            return $this->upload->data('file_name');
	            // return $this->upload->data();
	        }
        }
    }


	public function logout(){
		$this->session->sess_destroy();
		redirect('login');
	}


}
