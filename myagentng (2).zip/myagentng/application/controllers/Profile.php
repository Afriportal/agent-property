<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Profile extends CI_Controller {

    protected $dataProfile = '';
	public function __construct(){
        parent::__construct();
        if($this->session->userdata('logged_in')) {
        	$dataProfile = $this->user_model->get_single($this->session->userdata('user_id'));
        	if ($dataProfile->user_active === 'pending') {
				$this->session->set_flashdata('error_msg','An activation link has been sent to your email! Please check and click on the link to activate your account');
				$this->session->set_userdata('referred_from', current_url());
				redirect('login');
			}			
		}else{
			redirect(base_url());
		} 
    }

	public function index(){

		$this->form_validation->set_rules('name','Name', 'trim|required|min_length[5]');
		$this->form_validation->set_rules('Phone','Phone number', 'trim|required|is_numeric');
		$this->form_validation->set_rules('about','About', 'trim|min_length[10]');
		$this->form_validation->set_rules('office_address', 'Office Address', 'trim|min_length[10]');
		$this->dorm_validation->set_rules('company_name', 'Company name', 'trim|required');
	}

}
