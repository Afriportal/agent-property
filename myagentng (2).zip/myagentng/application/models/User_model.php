<?php



class User_model extends CI_Model {

	public function change_password($password, $uid = ''){
		if($uid == '' || !$this->get_single($uid)) $uid = $this->session->userdata('user_id');
		$salt = salt(50);
		$password = shaPassword($password, $salt);// $uid = $this->session->userdata('user_id');
		$data = array(
			'pwd' => $password,
			'salt' => $salt
		);
		$this->db->where(['id'=> $uid]);
		$this->db->update('users', $data);
		return true;
	}


	public function get_by_email($table = null, $where = null ) {
		if( $where != null ) $this->db->where($where);
		return $this->db->get($table);
	}

	public function update_data( $table, $data, $where ) {
		$this->db->where($where);
		if( $this->db->update( $table, $data )) {
			return true;
		}else{
			return false;
		}
	}

	
	public function r_password($uid, $password){

		$salt = salt(50);

		$password = shaPassword($password, $salt);

		$data = array(

			'pwd' => $password,

			'salt' => $salt

		);



		$this->db->where(['id'=> $uid]);

		$this->db->update('users', $data);

		return true;

	}







	public function cur_pass_match($password = null, $uid = ''){



		if ($password) {

			if($uid == '' || !$this->get_single($uid)) $uid = $this->session->userdata('user_id');

			$this->db->where('id', $uid);

			$salt = $this->db->get('users')->row()->salt;

			$this->db->where('id', $uid);

			$curpassword = $this->db->get('users')->row()->pwd;

			$password = shaPassword($password, $salt);

			if ($password === $curpassword) {

				return true;

			} else {

				return false;

			}



		}



	}


	public function login_user($email, $password){
		if($email && $password) {
			$email = cleanit($email);
			$this->db->where(['email' => $email]);
			if ($this->db->get('users')->row()) {
				$this->db->where(['email' => $email]);
				$salt = $this->db->get('users')->row()->salt;
				if ($salt) {
					$password = shaPassword($password, $salt);
					$this->db->where('email', $email);
					$this->db->where('pwd', $password);
					$result = $this->db->get('users');
					if ($result->num_rows() == 1) {
						return $result->row(0)->id;
					} else {
						return false;
					}
				}
			}
		}
	}







    public function activate_account( $token, $email ){
    	$this->db->where('email =', $email );
    	$this->db->where('activation_token =', $token );
    	$result = $this->db->get('users');
    	if($result->num_rows() == 1){
    		$this->db->set('user_active', 'active');
    		$this->db->set('activation_token', '');
    		$this->db->where('email',$email)->update('users');
    		return true;
    	}
    	return false;
    }

	public function recover_user($email){

		if($email) {

			$email = htmlentities($email);



			$this->db->where('email', $email);

			$result = $this->db->get('users');

			if ($result->num_rows() == 1) {

				return $result->row(0)->id;

			} else {

				return false;

			}



		}

	}



	public function last_login(){
		if ($this->session->userdata('user_id')) {
			$array = array(
		        'last_login' => get_now(),
		        'last_ip' => $_SERVER['REMOTE_ADDR']
			);

			$this->db->set($array);
			$this->db->where('id',$this->session->userdata('user_id'));
			$this->db->update('users');
		}
	}







	public function phoneclean($num) {



    	$num = preg_replace('/\D/', '', $num);



    	$len = strlen($num);



    	$accurate = $len - 10;



    	$realNUM = substr($num,$accurate);



    	return '0'.$realNUM;



    }







    public function do_upload($mid){







        $config['upload_path']          = './data/pictures/';



        $config['allowed_types']        = 'gif|jpg|png|JPEG|bmp';



        $config['max_size']             = 4048;



        $config['max_width']            = 5600;



        $config['max_height']           = 5600;



        $config['overwrite']			= true;



        $config['file_name']			= 'dp'.$mid;



        $config['encrypt_name'] 		= FALSE;







        $this->load->library('upload', $config);







        if ( ! $this->upload->do_upload('avatar'))



        {



                $error = array('avatar_msg' => $this->upload->display_errors());



                $this->session->set_flashdata($error);



                return false;



        }



        else



        {



                $data = array('upload_data' => $this->upload->data());







                return $this->upload->data('file_name');



        }



    }







	public function register_user($register_data = null){

		if($register_data) {

			$register_data['salt'] = salt(50);
			$register_data['pwd'] = shaPassword($register_data['pwd'], $register_data['salt']);
			if($this->db->insert('users', $register_data)) {
				return $this->db->insert_id();
			}else {
				return false;
			}
			
		}
	}







	public function insert_data($table = null,$data = null){



		if(!empty($table) && !empty($data)) {



			$this->db->insert($table, $data);



			return $this->db->insert_id();



		}



	}







	public function get_users($status = '') {



		if ($status != '') $this->db->where('status',$status);		



		$this->db->order_by('date_registered');



		return $this->db->get('users')->result();



	}







	public function search($src)



	{



		$where = "`name` LIKE '%".$src."%' ESCAPE '!' OR `email` LIKE '%".$src."%' ESCAPE '!')";



    	$this->db->order_by('id','DESC');



		return $this->db->limit(100)->where($where)->get("users");



	}







	public function get_users_count($user_type, $status = 'active') {
		$this->db->where($user_type);
		if($status != '') $this->db->where('user_active',$status);
		return $this->db->get('users')->num_rows();	

	}





	public function update_users($data, $id) {

		$this->db->where('id',$id);

		if ($this->db->get('users')) {

			$this->db->where(['id'=> $id]);

			$this->db->update('users', $data);

			return true;

		}



	}







	public function get_single($uid){

		$this->db->where('id',$uid);

		if ($this->db->get('users')) {

			$this->db->where('id',$uid);

			return $this->db->get('users')->row();

		}



	}







	public function delete_account($table, $id){



		$this->db->where('id', $id);



		$this->db->delete($table);



		return true;



	} 







	public function get_email($email){



		$this->db->where('email',$email);



		if($this->db->get('users')) {



			$this->db->where('email',$email);



			return $this->db->get('users')->row();



		} else {



			return false;



		}



	}







	// Get users by its status, type


	public function get_user_by_type($type = '', $id = '' ) {
		//if ($status != '') $this->db->where('status',$status);
		if( $type != '' ) $this->db->where('user_type', $type);
		if ($id != '') $this->db->where('id',$id);	
		if( $id == '') $this->db->order_by('date_registered');
		return $this->db->get('users')->result();

	}



	// Get sum of something  for user

	public function get_sum( $table, $column , $where = '' , $or_where = ''){

		if( $where != '' ) $this->db->where($where); 

		if( $or_where != '') $this->db->or_where($or_where);

		$this->db->select_sum($column);

		return $this->db->get($table)->row();

	}



	// Get sum of something  for user

	public function count_results( $table, $where = '' , $or_where = ''){

		if( $where != '' ) $this->db->where($where); 

		if( $or_where != '') $this->db->or_where($or_where);

		return $this->db->count_all_results($table);

	}



	// get all payouts info

	// Would use this function also on Thng

	public function get_payouts($id = '') {

		if( $id != '') $this->db->where('user_id', $id);

		$this->db->order_by('date_requested', 'DESC');

		return $this->db->get('payouts')->result();

	}



	// Token exists

	public function token_exists( $table, $token, $set = '' , $delete_token = false ){

    	$this->db->where('token =', $token );

    	$result = $this->db->get($table);

    	if($result->num_rows() >= 1){

    		if($set != '' ) $this->db->set( $set );

    		if( $delete_token ) {

    			$this->db->set('token', '' );

    			$this->db->where('token',$token)->update($table);

    		}

    		return $result->row();

    	}

    	return false;

    }

    public function get_user_favourited( $id ){
    	$this->db->where('favourited_by', $id);
    	$this->db->order_by('datetime', 'ASC');
    	return $this->db->get('favourited')->result();
    }

    public function get_notifications( $id ) {
    	$this->db->where('receiver', $id );
    	$this->db->order_by('datetime', 'ASC');
    	return $this->db->get('notifications')->result();
    }

    public function notification_read( $id ){
    	$this->db->where('receiver', $id );
    	return $this->db->set('read','TRUE');
    }


    public function get_rows($table, $where, $or_where ='') {
		$this->db->where($where);
		if( $or_where != '') $this->db->or_where($where);
		return $this->db->get($table)->num_rows();	
	}

	public function get_subscription( $pid = '', $uid = '') {
		if( $pid != '' ) $this->db->where('property_id', $pid);
		$this->db->where('user_id', $uid);
		return $this->db->get('subscriptions')->row_array();
	}
	public function fetch_messages( $receiver, $sender ) {
		$this->db->where('receiver', $receiver );
		$this->db->where('sender', $sender );
		$this->db->order_by('datetime', 'DESC');
		return $this->db->get('notifications')->result();
	}

}



?>