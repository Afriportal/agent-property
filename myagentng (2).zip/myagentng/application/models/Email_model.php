<?php

/**

* Chris Tizy

* Email Model v1.0

*/

if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Email_model extends CI_Model {

	function __construct()

    {

        parent::__construct();

    }



    

	function admin_welcome_email($email = '' , $name = '', $pwd = '', $token = '')

	{		

		$activation_link = base_url().'recover/a?t='.$token.'&e='.$email;

		$post = array(

			'subject' => 'Verify your tickethub.ng account',

			'to' => $email,

			'template' => 'AdminWelcomeEmail',

			'merge_name' => $name,

			'merge_pwd' => $pwd,

			'merge_activation_link' => $activation_link,

			'isTransactional' => false

		);



		return $this->send_now($post);

	}

	function recover_email($email = '' , $name = '' , $token = ''){	
		$activation_link = base_url().'recover/a?t='.$token.'&e='.$email;
		$post = array(
			'subject' => 'You requested a password reset',

			'to' => $email,

			'template' => 'RecoverEmail',

			'merge_email' => $email,

			'merge_name' => $name,

			'merge_activation_link' => $activation_link,

			'isTransactional' => false

		);
		return $this->send_now($post);
	}



	function new_event_email($name = '', $email = '' , $title = '', $event_date = '', $event_url = '')

	{		

		$post = array(

			'subject' => 'Congratulation! Your new event is ready',

			'to' => $email,

			'template' => 'NewEventEmail',

			'merge_name' => $name,

			'merge_title' => $title,

			'merge_event_date' => $event_date,

			'merge_event_url' => $event_url,

			'isTransactional' => false

		);



		return $this->send_now($post);

	}



	function send_now($post)

	{		

		$url = 'https://api.elasticemail.com/v2/email/send';



		try{

			$post['from'] = 'hello@tickethub.ng';

			$post['fromName'] = 'Tickethub.ng';

			$post['apikey'] = '7abcf4f5-39f0-4041-8654-7f9ef104658c';

				

			$ch = curl_init();

			curl_setopt_array($ch, array(

	            CURLOPT_URL => $url,

				CURLOPT_POST => true,

				CURLOPT_POSTFIELDS => $post,

	            CURLOPT_RETURNTRANSFER => true,

	            CURLOPT_HEADER => false,

				CURLOPT_SSL_VERIFYPEER => false

	        ));

			

	        $result=curl_exec ($ch);

	        curl_close ($ch);

			

	        return $result;	

		}

		catch(Exception $ex){

			$this->session->set_flashdata('error_msg',$ex->getMessage());

			return false;

		}

	}


function welcome_email($email = '', $subject = '', $message = ''){

		$email_msg = '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd"><html xmlns="http://www.w3.org/1999/xhtml"><head><meta name="viewport" content="width=device-width" /><meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />

		<title>'.lang('app_name').' Welcome Email</title>

		</head><style type="text/css">/*-------------------------------------GLOBALAverybasicCSSreset-------------------------------------*/*{margin:0;padding:0;font-family:"HelveticaNeue","Helvetica",Helvetica,Arial,sans-serif;box-sizing:border-box;font-size:14px;}img{max-width:100%;}body{-webkit-font-smoothing:antialiased;-webkit-text-size-adjust:none;width:100%!important;height:100%;line-height:1.6;}tabletd{vertical-align:top;}/*-------------------------------------BODY&CONTAINER-------------------------------------*/body{background-color:#f6f6f6;}.body-wrap{background-color:#f6f6f6;width:100%;}.container{display:block!important;max-width:600px!important;margin:0auto!important;/*makesitcentered*/clear:both!important;}.content{max-width:600px;margin:0auto;display:block;padding:20px;}/*-------------------------------------HEADER,FOOTER,MAIN-------------------------------------*/.main{background:#fff;border:1pxsolid#e9e9e9;border-radius:3px;}.content-wrap{padding:20px;}.content-block{padding:0020px;}.header{width:100%;margin-bottom:20px;}.footer{width:100%;clear:both;color:#999;padding:20px;}.footera{color:#999;}.footerp,.footera,.footerunsubscribe,.footertd{font-size:12px;}/*-------------------------------------TYPOGRAPHY-------------------------------------*/h1,h2,h3{font-family:"HelveticaNeue",Helvetica,Arial,"LucidaGrande",sans-serif;color:#000;margin:40px00;line-height:1.2;font-weight:400;}h1{font-size:32px;font-weight:500;}h2{font-size:24px;}h3{font-size:18px;}h4{font-size:14px;font-weight:600;}p,ul,ol{margin-bottom:10px;font-weight:normal;}pli,ulli,olli{margin-left:5px;list-style-position:inside;}/*-------------------------------------LINKS&BUTTONS-------------------------------------*/a{color:#1ab394;text-decoration:underline;}.btn-primary{text-decoration:none;color:#FFF;background-color:#1ab394;border:solid#1ab394;border-width:5px10px;line-height:2;font-weight:bold;text-align:center;cursor:pointer;display:inline-block;border-radius:5px;text-transform:capitalize;}/*-------------------------------------OTHERSTYLESTHATMIGHTBEUSEFUL-------------------------------------*/.last{margin-bottom:0;}.first{margin-top:0;}.aligncenter{text-align:center;}.alignright{text-align:right;}.alignleft{text-align:left;}.clear{clear:both;}/*-------------------------------------ALERTSChangetheclassdependingonwarningemail,goodemailorbademail-------------------------------------*/.alert{font-size:16px;color:#fff;font-weight:500;padding:20px;text-align:center;border-radius:3px3px00;}.alerta{color:#fff;text-decoration:none;font-weight:500;font-size:16px;}.alert.alert-warning{background:#f8ac59;}.alert.alert-bad{background:#ed5565;}.alert.alert-good{background:#1ab394;}/*-------------------------------------INVOICEStylesforthebillingtable-------------------------------------*/.invoice{margin:40pxauto;text-align:left;width:80%;}.invoicetd{padding:5px0;}.invoice.invoice-items{width:100%;}.invoice.invoice-itemstd{border-top:#eee1pxsolid;}.invoice.invoice-items.totaltd{border-top:2pxsolid#333;border-bottom:2pxsolid#333;font-weight:700;}/*-------------------------------------RESPONSIVEANDMOBILEFRIENDLYSTYLES-------------------------------------*/@mediaonlyscreenand(max-width:640px){h1,h2,h3,h4{font-weight:600!important;margin:20px05px!important;}h1{font-size:22px!important;}h2{font-size:18px!important;}h3{font-size:16px!important;}.container{width:100%!important;}.content,.content-wrap{padding:10px!important;}.invoice{width:100%!important;}}</style><body><table class="body-wrap"><tr><td></td><td class="container" width="600"><div class="content"><table class="main" width="100%" cellpadding="0" cellspacing="0"><tr><td class="content-wrap"><table  cellpadding="0" cellspacing="0"><tr><td>

		<h2>'.ucwords(lang('app_name')).'</h2>

        </td></tr><tr><td class="content-block">

		<h3>'.$subject.'</h3>

		</td></tr><tr><td class="content-block">

		'.$message.'

		</td></tr><tr><td class="content-block aligncenter"><a href="'.base_url().'" class="btn-primary">Visit Website</a></td></tr></table></td></tr></table><div class="footer"><table width="100%"><tr><td class="aligncenter content-block">'.lang('footer_text').'</td></tr></table></div></div></td><td></td></tr></table></body></html>';	

		return $this->do_email($email_msg , $subject , $email, lang('app_email'));

	}	

	/***custom email sender****/

	function do_email($msg=NULL, $sub=NULL, $to=NULL, $from=NULL){		

		$config = array();
        $config['useragent']	= "CodeIgniter";
        $config['mailpath']		= "/usr/bin/sendmail"; // or "/usr/sbin/sendmail"
        $config['protocol']		= "smtp";
        $config['smtp_host']	= "localhost";
        $config['smtp_port']	= "25";
        $config['mailtype']		= 'html';
        $config['charset']		= 'utf-8';
        $config['newline']		= "\r\n";
        $config['wordwrap']		= TRUE;
        $this->load->library('email');
        $this->email->initialize($config);
		$system_name	=	lang('app_name');
		if($from == NULL)
			$from		=	lang('notify_email');
		$this->email->from($from, $system_name);
		$this->email->to($to);
		$this->email->subject($sub);		
		$this->email->message($msg);		
		$this->email->send();
		return true;
	}


	function payment_request($email = '', $name = '', $token_link = '' ){		

		$post = array(

			'subject' => 'Payment Request!',

			'to' => $email,

			'template' => 'RequestPayout',

			'merge_payment_token' => $token_link,

			'merge_name' => $name,

			'isTransactional' => false

		);

		return $this->send_now($post);

	}



	// $this->email_model->email_invitation($name[$x], $email[$x], $event , $token_link );

	// $return_event['title'] = $ev->event_title;

	// 		$return_event['event_start_date'] = date('Y m d H:i A', strtotime($ev->start_date));

	// 		$return_event['event_end_date'] = date('Y m d H:i A', strtotime($ev->end_date));

	// 		$return_event['event_address'] = $ev->event_address;

	// 		$return_event['organizer_name'



	function email_invitation($name = '', $email = '', $event = array(), $event_url = ''){		

		$post = array(

			'subject' => $event['subject'] ,

			'to' => $email,

			'template' => 'EmailInvitation',

			'merge_name' => $name,

			'merge_organizer_name' => $event['organizer_name'],

			'merge_event_title' => $event['title'],

			'merge_start_date' => $event['event_start_date'],

			'merge_end_date' => $event['event_end_date'],

			'merge_event_address' => $event['event_address'],

			'merge_subject' => $event['subject'],

			'merge_message' => $event['message'],

			'merge_event_url' => $event_url,

			'isTransactional' => false

		);



		return $this->send_now($post);

	}

	function contributor_email($name = '', $email = '', $event_title = ''){		

		$post = array(

			'subject' => 'Contributor Invitation' ,

			'to' => $email,

			'template' => 'ContributorInvitation',

			'merge_organizer_name' => $name,

			'merge_event_title' => $event_title,

			'isTransactional' => false

		);



		return $this->send_now($post);

	}



}



?>