<?php
class Property_model extends CI_Model {

	public function update_data( $table, $data, $where ) {
		$this->db->where($where);
		if( $this->db->update( $table, $data )) {
			return true;
		}else{
			return false;
		}
	}


	public function insert_data($table = null,$data = null){
		if(!empty($table) && !empty($data)) {
			$this->db->insert($table, $data);
			return $this->db->insert_id();
		}
	}

	public function fetch_properties( $limit = 6){
		$this->db->where('status =', 'active');
		$this->db->order_by('postdate','DESC');
		$this->db->limit(5);
		return $this->db->get('property')->result();
	}

	public function fetch_properties_by_type( $type = '', $limit = '' , $offset = '', $sort = '' ){
		if( $type != '' ) $this->db->where('property_type' ,  $type);
		$this->db->where('status =', 'active');
		if( $sort != '' ) $this->db->order_by($sort);
		if( $limit != '' ) $this->db->limit($limit);
		if( $offset != '' ) $this->db->offset($offset);
		return $this->db->get('property')->result();
	}

	public function fetch_featured_image( $id ) {
		$this->db->where('pid', $id );
		$this->db->limit(1);
		return $this->db->get('property_images')->row();
	}

	public function fetch_images( $id ){
		$this->db->where('pid', $id );
		return $this->db->get('property_images');
	}

	public function fetch_num_rows( $table, $where ) {
		$this->db->where($where);
		$this->db->where('status', 'active');
		return $this->db->get($table)->num_rows();
	}

	public function add_count( $id ) {
		$this->db->set('views', 'views+ 1', false);
        $this->db->where('pid', $id);
        return $this->db->update('property');

	}

	public function is_favourited( $uid, $pid = ''){
		$this->db->where('favourited_by', $uid );
		$this->db->where('property_id', $pid );
		if( $this->db->get('favourited')->num_rows() ) {
			return true;
		}else {
			return false; 
		}
	}

	public function single_property( $id ){
		$this->db->where('pid', $id );
		$this->db->or_where('id', $id);
		return $this->db->get('property')->row_array();
	}

	public function related_property( $id, $related = array() ) {
		$this->db->where('status', 'active');
		$this->db->where('pid !=', $id );
		$this->db->like('property_type' , $related['property_type']);
		$this->db->or_like('type_of_property', $related['type_of_property']);
		$this->db->or_like('description', $related['description']);
		$this->db->limit(2);
		return $this->db->get('property')->result();
	}

	public function recent_property( $id = ''){
		$this->db->where('status', 'active');
		if($id != '') $this->db->where('pid !=', $id );
		$this->db->order_by('postdate', 'DESC');
		$this->db->limit(3);
		return $this->db->get('property')->result();
	}


	public function favourite( $id, $action ) {
		// Check the action
		if( $action == 'favpost' ) {
			$data = array(
				'favourited_by' => $this->session->userdata('user_id'),
				'property_id'	=> $id,
				'datetime'		=> get_now()
			);
			if( $this->insert_data( 'favourited', $data ) ) return true;
				return false;
		}else {
			$this->db->where('property_id', $id );
			$this->db->where('favourited_by', $this->session->userdata('user_id'));
			if($this->db->delete('favourited')) return true;
				return false;

		}
	}


	public function search_properties_rows( $data ) {
		$this->db->like( $data );
		$this->db->where('status','active');
		return $this->db->get('property')->num_rows();
	}

	public function search_properties( $data , $limit = '', $offset= '', $sort = '' ) {
		if( $sort != '' ) $this->db->where($sort);
		$this->db->like( $data );
		$this->db->where('status =', 'active');
		if( $limit != '' ) $this->db->limit($limit);
		if( $offset != '' ) $this->db->offset($offset);
		return $this->db->get('property')->result();
	}

	public function run_sql( $sql ) {
		return $this->db->query($sql)->result_array();
	}

}



?>